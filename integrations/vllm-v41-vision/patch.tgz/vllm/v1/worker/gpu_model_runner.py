# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM project

import functools
import gc
import itertools
import json
import os
import threading
import time
from collections import defaultdict
from collections.abc import Callable, Iterable, Iterator, Mapping, Sequence
from contextlib import contextmanager
from copy import copy, deepcopy
from dataclasses import dataclass, replace
from functools import reduce
from typing import TYPE_CHECKING, Any, NamedTuple, TypeAlias, TypedDict, cast

import numpy as np
import torch
import torch.distributed
import torch.nn as nn
from tqdm import tqdm

import vllm.envs as envs
from vllm.compilation.breakable_cudagraph import (
    BreakableCUDAGraphWrapper,
    is_breakable_cudagraph_enabled,
)
from vllm.compilation.counter import compilation_counter
from vllm.compilation.cuda_graph import (
    CUDAGraphStat,
    CUDAGraphWrapper,
)
from vllm.compilation.monitor import set_cudagraph_capturing_enabled
from vllm.config import (
    CompilationMode,
    CUDAGraphMode,
    VllmConfig,
    get_layers_from_vllm_config,
    set_current_vllm_config,
    update_config,
)
from vllm.config.cache import CacheConfig
from vllm.config.execution_policy import graph_policy
from vllm.config.sm70_runtime import RuntimeTraceConfig, capture_runtime_trace
from vllm.diagnostics import bind_diagnostics, diagnostic_channel, flush_runner_graphs
from vllm.distributed.ec_transfer import get_ec_transfer, has_ec_transfer
from vllm.distributed.eplb.eplb_state import EplbState
from vllm.distributed.kv_transfer import get_kv_transfer_group, has_kv_transfer_group
from vllm.distributed.kv_transfer.kv_connector.utils import copy_kv_blocks
from vllm.distributed.parallel_state import (
    get_dcp_group,
    get_pp_group,
    get_tp_group,
    graph_capture,
    is_global_first_rank,
    prepare_communication_buffer_for_model,
)
from vllm.forward_context import (
    BatchDescriptor,
    set_forward_context,
)
from vllm.logger import init_logger
from vllm.lora.layers import LoRAMapping, LoRAMappingType
from vllm.model_executor.layers.attention import Attention, MLAAttention
from vllm.model_executor.layers.attention_layer_base import AttentionLayerBase
from vllm.model_executor.layers.fused_moe.routed_experts_capturer import (
    RoutedExpertsCapturer,
)
from vllm.model_executor.layers.mamba.ops.ssu_dispatch import (
    initialize_mamba_ssu_backend,
)
from vllm.model_executor.layers.rotary_embedding import (
    MRotaryEmbedding,
    XDRotaryEmbedding,
)
from vllm.model_executor.model_loader import get_model_loader
from vllm.model_executor.model_loader.reload import (
    finalize_layerwise_reload,
    initialize_layerwise_reload,
)
from vllm.model_executor.models.interfaces import (
    MixtureOfExperts,
    MultiModalEmbeddings,
    SupportsMRoPE,
    SupportsMultiModal,
    SupportsXDRoPE,
    is_mixture_of_experts,
    supports_eagle3,
    supports_mrope,
    supports_multimodal_pruning,
    supports_realtime,
    supports_transcription,
    supports_xdrope,
)
from vllm.model_executor.models.interfaces_base import (
    VllmModelForPooling,
    is_pooling_model,
    is_text_generation_model,
)
from vllm.model_executor.offloader import (
    create_offloader,
    get_offloader,
    set_offloader,
)
from vllm.multimodal import MULTIMODAL_REGISTRY
from vllm.multimodal.encoder_budget import MultiModalBudget
from vllm.multimodal.inputs import (
    BatchedTensorInputs,
    MultiModalKwargsItem,
    PlaceholderRange,
)
from vllm.multimodal.utils import group_and_batch_mm_kwargs
from vllm.platforms import current_platform
from vllm.platforms.sm70.runner_hooks import create_input_transfer
from vllm.pooling_params import PoolingParams
from vllm.sampling_params import SamplingType
from vllm.sequence import IntermediateTensors
from vllm.sm70_decode_trace import (
    sm70_trace_event_sync,
)
from vllm.tasks import GenerationTask, PoolingTask, SupportedTask
from vllm.tracing import instrument
from vllm.utils import length_from_prompt_token_ids_or_embeds
from vllm.utils.math_utils import cdiv, round_up
from vllm.utils.mem_utils import DeviceMemoryProfiler, format_gib
from vllm.utils.nvtx_pytorch_hooks import PytHooks
from vllm.utils.platform_utils import is_pin_memory_available, num_compute_units
from vllm.utils.torch_utils import (
    get_dtype_size,
    is_quantized_kv_cache,
    kv_cache_dtype_str_to_dtype,
)
from vllm.v1.attention.backend import (
    AttentionBackend,
    AttentionCGSupport,
    AttentionMetadata,
    AttentionMetadataBuilder,
    AttentionType,
    CommonAttentionMetadata,
)
from vllm.v1.attention.backends.flash_v100 import FlashAttnV100MetadataBuilder
from vllm.v1.attention.backends.flex_attention import FlexAttentionMetadataBuilder
from vllm.v1.attention.backends.gdn_attn import GDNAttentionMetadataBuilder
from vllm.v1.attention.backends.mamba2_attn import Mamba2AttentionMetadataBuilder
from vllm.v1.attention.backends.utils import (
    NULL_BLOCK_ID,
    PAD_SLOT_ID,
    create_fast_prefill_custom_backend,
    get_dcp_local_seq_lens,
    reorder_batch_to_split_decodes_and_prefills,
)
from vllm.v1.core.sched.output import NewRequestData
from vllm.v1.cudagraph_dispatcher import CudagraphDispatcher
from vllm.v1.kv_cache_interface import (
    AttentionSpec,
    ChunkedLocalAttentionSpec,
    CircularBufferSpec,
    CrossAttentionSpec,
    EncoderOnlyAttentionSpec,
    FullAttentionSpec,
    KVCacheConfig,
    KVCacheGroupSpec,
    KVCacheSpec,
    MambaSpec,
    SlidingWindowSpec,
    UniformTypeKVCacheSpecs,
)
from vllm.v1.outputs import (
    EMPTY_MODEL_RUNNER_OUTPUT,
    AsyncModelRunnerOutput,
    DraftTokenIds,
    ECConnectorOutput,
    KVConnectorOutput,
    LogprobsLists,
    LogprobsTensors,
    ModelRunnerOutput,
    PoolerOutput,
    RoutedExpertsLists,
    RoutedExpertsTensors,
    SamplerOutput,
    make_empty_encoder_model_runner_output,
)
from vllm.v1.pool.metadata import PoolingMetadata, PoolingStates
from vllm.v1.sample.logits_processor import LogitsProcessors, build_logitsprocs
from vllm.v1.sample.logits_processor.interface import LogitsProcessor
from vllm.v1.sample.metadata import SamplingMetadata
from vllm.v1.sample.rejection_sampler import GREEDY_TEMPERATURE, RejectionSampler
from vllm.v1.sample.sampler import Sampler
from vllm.v1.spec_decode.custom_class_proposer import create_custom_proposer
from vllm.v1.spec_decode.ddtree_parent_metadata import (
    DDTreeParentMetadata,
    build_padded_parent_ids,
)
from vllm.v1.spec_decode.ddtree_payload import DDTreeDraftPayload
from vllm.v1.spec_decode.ddtree_sampler import (
    DDTreeGreedySamplerResult,
    greedy_sample_ddtree_payloads,
    greedy_sample_ddtree_payloads_from_top_tokens,
    greedy_sample_ddtree_payloads_from_top_tokens_gpu,
    stochastic_sample_ddtree_payloads,
    stochastic_sample_ddtree_payloads_from_topk,
    warmup_ddtree_single_top_token_sampler,
)
from vllm.v1.spec_decode.dflash import DFlashProposer
from vllm.v1.spec_decode.draft_model import DraftModelProposer
from vllm.v1.spec_decode.draft_prob_alignment import (
    clone_draft_prob_token_ids,
    get_aligned_draft_probs,
    get_aligned_draft_scalar_values,
)
from vllm.v1.spec_decode.dspark import DSparkProposer
from vllm.v1.spec_decode.eagle import EagleProposer
from vllm.v1.spec_decode.extract_hidden_states import ExtractHiddenStatesProposer
from vllm.v1.spec_decode.gemma4 import Gemma4Proposer
from vllm.v1.spec_decode.medusa import MedusaProposer
from vllm.v1.spec_decode.metadata import SpecDecodeMetadata
from vllm.v1.spec_decode.ngram_proposer_gpu import (
    NgramProposerGPU,
    copy_num_valid_draft_tokens,
    update_ngram_gpu_tensors_incremental,
    update_scheduler_for_invalid_drafts,
)
from vllm.v1.spec_decode.qwen4_exp import Qwen4ExpMTPProposer
from vllm.v1.spec_decode.static_draft_vocab import (
    DynamicDraftVocabPrefillBootstrapState,
    resolve_mtp_draft_vocab_config,
    validate_dynamic_draft_vocab_prefill_topk,
)
from vllm.v1.spec_decode.step3p5 import Step3p5MTPProposer
from vllm.v1.spec_decode.suffix_decoding import SuffixDecodingProposer
from vllm.v1.spec_decode.utils import update_num_computed_tokens_for_batch_change
from vllm.v1.structured_output.utils import apply_grammar_bitmask
from vllm.v1.utils import CpuGpuBuffer, record_function_or_nullcontext
from vllm.v1.worker import mamba_utils
from vllm.v1.worker.cp_utils import check_attention_cp_compatibility
from vllm.v1.worker.dp_utils import coordinate_batch_across_dp
from vllm.v1.worker.ec_connector_model_runner_mixin import ECConnectorModelRunnerMixin
from vllm.v1.worker.gpu.pool.late_interaction_runner import LateInteractionRunner
from vllm.v1.worker.gpu_input_batch import CachedRequestState, InputBatch
from vllm.v1.worker.gpu_ubatch_wrapper import UBatchWrapper
from vllm.v1.worker.kv_connector_model_runner_mixin import KVConnectorModelRunnerMixin
from vllm.v1.worker.lora_model_runner_mixin import LoRAModelRunnerMixin
from vllm.v1.worker.ubatch_utils import (
    UBatchSlices,
    check_ubatch_thresholds,
    maybe_create_ubatch_slices,
    split_attn_metadata,
)
from vllm.v1.worker.utils import (
    allocate_host_kv_cache_pool,
    is_residual_scattered_for_sp,
)
from vllm.v1.worker.workspace import lock_workspace

from .utils import (
    AttentionGroup,
    KVBlockZeroer,
    add_kv_sharing_layers_to_kv_cache_groups,
    bind_kv_cache,
    compressed_kernel_block_size,
    prepare_kernel_block_sizes,
    sanity_check_mm_encoder_outputs,
)

if TYPE_CHECKING:
    from vllm.v1.core.sched.output import GrammarOutput, SchedulerOutput
    from vllm.v1.spec_decode.ngram_proposer import NgramProposer
    from vllm.v1.worker.encoder_cudagraph import EncoderCudaGraphManager

from vllm.model_executor.warmup.plan import (
    run_warmup_tasks,
    warmup_boolean,
    warmup_unconditional,
)
from vllm.model_executor.warmup.sm70_runtime import (
    auxiliary_warmup_enabled,
    model_convolution_warmup_task,
    proposer_warmup_tasks,
)
from vllm.v1.spec_decode.profiling import create_step_profiler

logger = init_logger(__name__)


def _unwrap_pipeline_intermediate_hidden_states(
    output: torch.Tensor | IntermediateTensors,
) -> torch.Tensor:
    if not isinstance(output, IntermediateTensors):
        return output
    # DeepSeek-V4.1 PP2 hands off {"hidden", "pre"} (FP32 HC residual plus the
    # last stage-1 FFN collapse weights); other models use "hidden_states".
    for key in ("hidden_states", "hidden"):
        if key in output.tensors:
            return output.tensors[key]
    raise RuntimeError(
        "Pipeline intermediate output must contain a 'hidden_states' or "
        f"'hidden' tensor (got {sorted(output.tensors)})."
    )


def _dflash_ddtree_debug_enabled() -> bool:
    return os.getenv("VLLM_DFLASH_DDTREE_DEBUG", "0") == "1"


def _dflash_ddtree_debug_log(message: str, *args: object) -> None:
    if _dflash_ddtree_debug_enabled():
        formatted = message % args if args else message
        logger.info("DFlash DDTree runner debug: %s", formatted)


def _dflash_ddtree_trace_path() -> str | None:
    return os.getenv("VLLM_DFLASH_DDTREE_TRACE_JSONL")


def _dflash_ddtree_trace_enabled() -> bool:
    return _dflash_ddtree_trace_path() is not None and is_global_first_rank()


def _dflash_ddtree_verify_row_trace_enabled() -> bool:
    return os.getenv("VLLM_DFLASH_DDTREE_VERIFY_ROW_TRACE", "0") == "1"


def _dflash_ddtree_verify_row_trace_context_limit() -> int:
    raw = os.getenv("VLLM_DFLASH_DDTREE_VERIFY_ROW_TRACE_CONTEXT", "128")
    try:
        return int(raw)
    except ValueError:
        return 128


def _dflash_ddtree_trace_event(
    event: str,
    payload: Mapping[str, object],
) -> None:
    trace_path = _dflash_ddtree_trace_path()
    if not trace_path or not is_global_first_rank():
        return
    record = {
        "event": event,
        "pid": os.getpid(),
        **payload,
    }
    try:
        with open(trace_path, "a", encoding="utf-8") as trace_file:
            json.dump(record, trace_file, ensure_ascii=True, sort_keys=True)
            trace_file.write("\n")
    except OSError:
        logger.exception("Failed to write DDTree trace event to %s", trace_path)


def _clip_stateful_sample_limits(
    output_token_ids, req_ids, requests, output_budget=None
):
    """Keep stop/length clipping on device before a private-state commit.

    The normal CPU output processor also applies these limits. Models with
    prefix snapshots need the same boundary before an asynchronous next step
    consumes the sampled-count selector. Other models retain their old path.
    """
    for row, req_id in enumerate(req_ids[: output_token_ids.shape[0]]):
        request = requests.get(req_id)
        params = None if request is None else request.sampling_params
        if params is None:
            continue
        if params.max_tokens is not None:
            if output_budget is not None:
                positions = torch.arange(
                    output_token_ids.shape[1], device=output_token_ids.device
                )
                output_token_ids[row].masked_fill_(positions >= output_budget[row], -1)
            else:
                remaining = max(0, params.max_tokens - len(request.output_token_ids))
                output_token_ids[row, remaining:].fill_(-1)
        if output_token_ids.shape[1] <= 1:
            continue
        stops = set(params.stop_token_ids or ())
        if not params.ignore_eos and params.eos_token_id is not None:
            stops.add(params.eos_token_id)
        if stops:
            values = output_token_ids[row]
            stop = torch.zeros_like(values, dtype=torch.bool)
            for token_id in stops:
                stop |= values == token_id
            # Include the first stop itself, excluding every later candidate.
            after = stop.to(torch.int32).cumsum(0) - stop.to(torch.int32) > 0
            values.masked_fill_(after, -1)


def _count_contiguous_spec_tokens(output_token_ids: torch.Tensor) -> torch.Tensor:
    valid_token_mask = output_token_ids != -1
    token_offsets = torch.arange(
        output_token_ids.shape[1],
        device=output_token_ids.device,
        dtype=torch.int32,
    )
    first_invalid = (
        torch.where(
            valid_token_mask,
            output_token_ids.shape[1],
            token_offsets,
        )
        .min(dim=1)
        .values
    )
    return first_invalid.to(torch.int32)


def _async_spec_decode_participating_prev_positions(
    prev_positions: np.ndarray,
    prev_num_draft_tokens: np.ndarray,
) -> np.ndarray:
    valid_positions = prev_positions[prev_positions >= 0]
    if valid_positions.size == 0:
        return valid_positions
    if int(valid_positions.max()) >= len(prev_num_draft_tokens):
        raise RuntimeError(
            "Async speculative decode previous-request index exceeds the "
            "draft-count buffer."
        )
    return valid_positions[prev_num_draft_tokens[valid_positions] > 0]


def _sm70_cuda_graph_capture_active() -> bool:
    if not torch.cuda.is_available():
        return False
    is_capturing = getattr(torch.cuda, "is_current_stream_capturing", None)
    if is_capturing is None:
        return False
    try:
        return bool(is_capturing())
    except RuntimeError:
        return False


def _dflash_ddtree_profile_enabled() -> bool:
    return os.getenv("VLLM_DFLASH_DDTREE_PROFILE", "0") == "1"


def _dflash_ddtree_worker_profile_enabled() -> bool:
    return os.getenv("VLLM_DFLASH_DDTREE_WORKER_PROFILE", "0") == "1"


def _dflash_ddtree_metadata_profile_enabled() -> bool:
    return os.getenv("VLLM_DFLASH_DDTREE_METADATA_PROFILE", "0") == "1"


def _dflash_ddtree_target_forward_nvtx_enabled(trace: RuntimeTraceConfig) -> bool:
    return trace.value("spec_target_nvtx")


def _dflash_ddtree_target_forward_profiler_step(trace: RuntimeTraceConfig) -> int:
    # Compatibility name; initialized engines borrow their diagnostic policy.
    return trace.value("spec_target_profiler_step")


def _maybe_dump_sm70_mtp_step(
    phase: str, payload: dict[str, object], *, diagnostics=None
) -> None:
    channel = diagnostic_channel("mtp_step", owner=diagnostics)
    policy = channel.policy
    dump_dir = policy.directory
    if not dump_dir:
        return

    step = channel.advance("steps", start=1)
    target_steps = policy.filters["steps"]
    if target_steps is not None:
        if step not in target_steps:
            return
    else:
        max_steps = policy.value("max_dumps")
        if max_steps > 0 and step > max_steps:
            return

    def _to_cpu(value: object) -> object:
        if isinstance(value, torch.Tensor):
            tensor = value.detach()
            max_elems = policy.value("max_elements")
            if max_elems > 0 and tensor.numel() > max_elems:
                flat = tensor.reshape(-1)
                return {
                    "shape": tuple(tensor.shape),
                    "dtype": str(tensor.dtype),
                    "device": str(tensor.device),
                    "head": flat[:max_elems].cpu(),
                    "tail": flat[-max_elems:].cpu(),
                }
            return tensor.cpu()
        if isinstance(value, np.ndarray):
            max_elems = policy.value("max_elements")
            if max_elems > 0 and value.size > max_elems:
                flat = value.reshape(-1)
                return {
                    "shape": tuple(value.shape),
                    "dtype": str(value.dtype),
                    "head": flat[:max_elems].copy(),
                    "tail": flat[-max_elems:].copy(),
                }
            return value.copy()
        if isinstance(value, dict):
            return {str(key): _to_cpu(val) for key, val in value.items()}
        if isinstance(value, (list, tuple)):
            return type(value)(_to_cpu(item) for item in value)
        return value

    rank = get_tp_group().rank_in_group if torch.distributed.is_initialized() else 0
    channel.write(
        f"mtp_step_pid{os.getpid()}_rank{rank}_{step:06d}_{phase}.pt",
        {
            "phase": phase,
            "step": step,
            **{key: _to_cpu(value) for key, value in payload.items()},
        },
    )


def _sm70_parse_step_filter(raw_steps: str | None) -> set[int] | None:
    from vllm.config.diagnostic_dump import parse_int_filter

    try:
        result = parse_int_filter(raw_steps, strict=True)
    except ValueError:
        return set()
    return None if result is None else set(result)


def _maybe_sync_sm70_sample_tensors(
    sample_hidden_states: torch.Tensor, *, diagnostics=None
) -> None:
    channel = diagnostic_channel("sample_sync", owner=diagnostics)
    target_steps = channel.policy.filters["steps"]
    if target_steps is None:
        return
    if _sm70_cuda_graph_capture_active():
        return

    step = channel.advance("steps", start=1)
    if step not in target_steps:
        return

    mode = channel.policy.mode
    assert mode is not None
    mode = mode.strip().lower()
    if mode == "d2h":
        _ = sample_hidden_states.detach().cpu()
    elif mode == "device" and sample_hidden_states.is_cuda:
        torch.accelerator.synchronize(sample_hidden_states.device)
    elif sample_hidden_states.is_cuda:
        torch.cuda.current_stream(sample_hidden_states.device).synchronize()


def _maybe_dump_sm70_sample_tensors(
    sample_hidden_states: torch.Tensor,
    logits: torch.Tensor | None,
    stage: str,
    metadata: dict[str, Any] | None = None,
    *,
    diagnostics=None,
) -> None:
    channel = diagnostic_channel("sample", owner=diagnostics)
    policy = channel.policy
    dump_dir = policy.directory
    if not dump_dir:
        return
    enable_file = policy.enable_file
    if enable_file and not os.path.exists(enable_file):
        return
    if _sm70_cuda_graph_capture_active():
        return

    step = channel.advance("steps", start=1)
    target_steps = policy.filters["steps"]
    if target_steps is not None and step not in target_steps:
        return

    max_steps = policy.value("max_dumps")
    if max_steps > 0 and max_steps < step:
        return

    channel.write(
        f"sample_tensors_pid{os.getpid()}_step{step:04d}.pt",
        {
            "stage": stage,
            "step": step,
            "pid": os.getpid(),
            "sample_hidden_states": sample_hidden_states.detach().cpu(),
            "logits": None if logits is None else logits.detach().cpu(),
            "hidden_shape": tuple(sample_hidden_states.shape),
            "hidden_dtype": str(sample_hidden_states.dtype),
            "logits_shape": None if logits is None else tuple(logits.shape),
            "logits_dtype": None if logits is None else str(logits.dtype),
            "metadata": metadata or {},
        },
    )


def _maybe_dump_sm70_qwen_layer_graph_buffers(stage: str, *, diagnostics=None) -> None:
    flush_runner_graphs(stage, owner=diagnostics)


def _should_record_sm70_sample_hidden_ready_event(
    sample_hidden_states: torch.Tensor,
    cudagraph_mode: CUDAGraphMode,
) -> bool:
    return (
        sample_hidden_states.is_cuda
        and cudagraph_mode == CUDAGraphMode.FULL
        and bool(graph_policy().compile_graph)
        and current_platform.is_device_capability(70)
    )


def _record_sm70_sample_hidden_ready_event(
    sample_hidden_states: torch.Tensor,
    cudagraph_mode: CUDAGraphMode,
) -> torch.cuda.Event | None:
    if not _should_record_sm70_sample_hidden_ready_event(
        sample_hidden_states, cudagraph_mode
    ):
        return None
    event = torch.cuda.Event()
    event.record(torch.cuda.current_stream(sample_hidden_states.device))
    return event


def _wait_sm70_sample_hidden_ready_event(
    sample_hidden_states: torch.Tensor,
    event: torch.cuda.Event | None,
) -> None:
    if event is None:
        return
    torch.cuda.current_stream(sample_hidden_states.device).wait_event(event)


def _sync_sm70_before_compile_graph_forward(
    cudagraph_mode: CUDAGraphMode,
    *,
    diagnostics=None,
) -> None:
    trace = diagnostics.trace if diagnostics is not None else capture_runtime_trace()
    if (
        trace.sync_before_compile
        and cudagraph_mode != CUDAGraphMode.NONE
        and bool(graph_policy().compile_graph)
        and current_platform.is_device_capability(70)
    ):
        torch.accelerator.synchronize()


def _sync_sm70_before_compile_graph_capture(
    cudagraph_mode: CUDAGraphMode,
) -> None:
    if (
        cudagraph_mode != CUDAGraphMode.NONE
        and bool(graph_policy().compile_graph)
        and current_platform.is_device_capability(70)
    ):
        logger.info_once(
            "Synchronizing before SM70 Flash-V100 compile CUDA graph capture."
        )
        torch.accelerator.synchronize()


def _select_dummy_sample_hidden_states(
    hidden_states: torch.Tensor | IntermediateTensors,
    num_scheduled_tokens: np.ndarray,
    device: torch.device,
) -> torch.Tensor | None:
    if isinstance(hidden_states, IntermediateTensors):
        return None
    logit_indices = np.cumsum(num_scheduled_tokens) - 1
    logit_indices_device = torch.from_numpy(logit_indices).to(device, non_blocking=True)
    return hidden_states[logit_indices_device]


def _sm70_profile_trace(message: str, *args: object) -> None:
    if capture_runtime_trace().profile_trace:
        if args:
            message = message % args
        logger.info("SM70 profile trace: %s", message)


def _maybe_log_sm70_decode_event_trace_config(
    *,
    use_async_scheduling: bool,
    greedy_token_fastpath: bool,
    num_spec_tokens: int,
    diagnostics=None,
) -> None:
    diagnostics = bind_diagnostics() if diagnostics is None else diagnostics
    if not diagnostics.trace.events:
        return
    if diagnostics.counters.get("event_trace_config_logged"):
        return
    diagnostics.counters["event_trace_config_logged"] = 1
    logger.warning(
        "SM70 decode event trace enabled: async_scheduling=%s "
        "greedy_token_fastpath=%s num_spec_tokens=%s threshold_ms=%s every=%s",
        use_async_scheduling,
        greedy_token_fastpath,
        num_spec_tokens,
        diagnostics.trace.event_threshold_ms,
        diagnostics.trace.event_every,
    )


def _sm70_parse_dump_steps(raw: str | None) -> set[int] | None:
    from vllm.config.diagnostic_dump import parse_int_filter

    result = parse_int_filter(raw, reverse=False)
    return None if result is None else set(result)


def _sm70_to_cpu_for_dump(value: Any) -> Any:
    if isinstance(value, torch.Tensor):
        return value.detach().cpu()
    if isinstance(value, np.ndarray):
        return value.copy()
    return value


def _sm70_dump_compile_graph_inputs(
    *,
    input_ids: torch.Tensor | None,
    positions: torch.Tensor | None,
    logits_indices: torch.Tensor | None,
    attn_metadata: Any,
    cudagraph_mode: CUDAGraphMode,
    batch_desc: BatchDescriptor,
    num_reqs: int,
    num_reqs_padded: int,
    num_tokens_unpadded: int,
    num_tokens_padded: int,
    num_scheduled_tokens_np: np.ndarray,
    req_ids: Sequence[str],
    query_start_loc: CpuGpuBuffer,
    seq_lens: torch.Tensor,
    num_computed_tokens: torch.Tensor,
    input_batch: InputBatch,
    diagnostics=None,
) -> None:
    channel = diagnostic_channel("compile_inputs", owner=diagnostics)
    policy = channel.policy
    dump_dir = policy.directory
    if not dump_dir:
        return

    step = channel.advance("steps", start=1)

    if "steps" in policy.filter_errors:
        raise ValueError(policy.filter_errors["steps"])
    target_steps = policy.filters["steps"]
    if target_steps is not None and step not in target_steps:
        return

    gdn_metadata: dict[str, Any] = {}
    metadata_dict: dict[str, Any] | None = None
    if isinstance(attn_metadata, dict):
        metadata_dict = attn_metadata
    elif isinstance(attn_metadata, list) and attn_metadata:
        metadata_dict = attn_metadata[0]
    if metadata_dict is not None:
        for layer_name, metadata in metadata_dict.items():
            if hasattr(metadata, "non_spec_state_indices_tensor"):
                gdn_metadata[str(layer_name)] = {
                    "num_prefills": getattr(metadata, "num_prefills", None),
                    "num_decodes": getattr(metadata, "num_decodes", None),
                    "num_decode_tokens": getattr(metadata, "num_decode_tokens", None),
                    "num_spec_decodes": getattr(metadata, "num_spec_decodes", None),
                    "num_spec_decode_tokens": getattr(
                        metadata, "num_spec_decode_tokens", None
                    ),
                    "num_actual_tokens": getattr(metadata, "num_actual_tokens", None),
                    "non_spec_query_start_loc": _sm70_to_cpu_for_dump(
                        getattr(metadata, "non_spec_query_start_loc", None)
                    ),
                    "non_spec_state_indices_tensor": _sm70_to_cpu_for_dump(
                        getattr(metadata, "non_spec_state_indices_tensor", None)
                    ),
                    "spec_query_start_loc": _sm70_to_cpu_for_dump(
                        getattr(metadata, "spec_query_start_loc", None)
                    ),
                    "spec_state_indices_tensor": _sm70_to_cpu_for_dump(
                        getattr(metadata, "spec_state_indices_tensor", None)
                    ),
                    "spec_sequence_masks": _sm70_to_cpu_for_dump(
                        getattr(metadata, "spec_sequence_masks", None)
                    ),
                    "spec_token_indx": _sm70_to_cpu_for_dump(
                        getattr(metadata, "spec_token_indx", None)
                    ),
                    "non_spec_token_indx": _sm70_to_cpu_for_dump(
                        getattr(metadata, "non_spec_token_indx", None)
                    ),
                    "num_accepted_tokens": _sm70_to_cpu_for_dump(
                        getattr(metadata, "num_accepted_tokens", None)
                    ),
                }
                break

    channel.write(
        f"pid{os.getpid()}_step{step:04d}.pt",
        {
            "pid": os.getpid(),
            "step": step,
            "cudagraph_mode": str(cudagraph_mode),
            "batch_desc": repr(batch_desc),
            "num_reqs": num_reqs,
            "num_reqs_padded": num_reqs_padded,
            "num_tokens_unpadded": num_tokens_unpadded,
            "num_tokens_padded": num_tokens_padded,
            "req_ids": list(req_ids[:num_reqs]),
            "num_scheduled_tokens": num_scheduled_tokens_np.copy(),
            "input_ids": _sm70_to_cpu_for_dump(
                None if input_ids is None else input_ids[:num_tokens_padded]
            ),
            "positions": _sm70_to_cpu_for_dump(
                None if positions is None else positions[:num_tokens_padded]
            ),
            "logits_indices": _sm70_to_cpu_for_dump(logits_indices),
            "query_start_loc_cpu": query_start_loc.cpu[: num_reqs_padded + 1].clone(),
            "query_start_loc_gpu": query_start_loc.gpu[: num_reqs_padded + 1]
            .detach()
            .cpu(),
            "seq_lens": seq_lens[:num_reqs_padded].detach().cpu(),
            "num_computed_tokens": num_computed_tokens[:num_reqs_padded].detach().cpu(),
            "idx_mapping": _sm70_to_cpu_for_dump(
                getattr(input_batch, "idx_mapping", None)
            ),
            "req_id_to_index": dict(input_batch.req_id_to_index),
            "gdn_metadata": gdn_metadata,
        },
    )


AttnMetadataDict: TypeAlias = dict[str, AttentionMetadata]
# list when ubatching is enabled
PerLayerAttnMetadata: TypeAlias = list[AttnMetadataDict] | AttnMetadataDict


# Wrapper for ModelRunnerOutput to support overlapped execution.
class AsyncGPUModelRunnerOutput(AsyncModelRunnerOutput):
    def __init__(
        self,
        model_runner_output: ModelRunnerOutput,
        sampled_token_ids: torch.Tensor,
        logprobs_tensors: LogprobsTensors | None,
        invalid_req_indices: list[int],
        async_output_copy_stream: torch.cuda.Stream,
        vocab_size: int,
        routed_experts: RoutedExpertsTensors | None = None,
        synchronize=None,
    ):
        self._synchronize = synchronize or sm70_trace_event_sync
        self._model_runner_output = model_runner_output
        self._invalid_req_indices = invalid_req_indices

        # Event on the copy stream so we can synchronize the non-blocking copy.
        self.async_copy_ready_event = torch.Event()

        # Keep a reference to the device tensor to avoid it being
        # deallocated until we finish copying it to the host.
        self._sampled_token_ids = sampled_token_ids
        self.vocab_size = vocab_size
        self._logprobs_tensors = logprobs_tensors
        self._routed_experts = routed_experts

        # Initiate the copy on a separate stream, but do not synchronize it.
        default_stream = torch.cuda.current_stream()
        with torch.cuda.stream(async_output_copy_stream):
            async_output_copy_stream.wait_stream(default_stream)
            self.sampled_token_ids_cpu = self._sampled_token_ids.to(
                "cpu", non_blocking=True
            )
            self._logprobs_tensors_cpu = (
                self._logprobs_tensors.to_cpu_nonblocking()
                if self._logprobs_tensors
                else None
            )
            self._routed_experts_cpu = (
                self._routed_experts.to_cpu_nonblocking()
                if self._routed_experts is not None
                else None
            )
            self.async_copy_ready_event.record()

    def get_output(self) -> ModelRunnerOutput:
        """Copy the device tensors to the host and return a ModelRunnerOutput.

        This function blocks until the copy is finished.
        """
        max_gen_len = self.sampled_token_ids_cpu.shape[-1]
        self._synchronize(
            self.async_copy_ready_event,
            "AsyncGPUModelRunnerOutput.async_copy_ready_event.synchronize",
        )

        # Release the device tensors once the copy has completed.
        del self._logprobs_tensors
        del self._sampled_token_ids
        if max_gen_len == 1:
            valid_sampled_token_ids = self.sampled_token_ids_cpu.tolist()
            for i in self._invalid_req_indices:
                valid_sampled_token_ids[i].clear()
            logprobs_lists = None
            if self._logprobs_tensors_cpu is not None:
                logprobs_lists = self._logprobs_tensors_cpu.tolists()
        else:
            valid_sampled_token_ids, logprobs_lists = RejectionSampler.parse_output(
                self.sampled_token_ids_cpu,
                self.vocab_size,
                self._invalid_req_indices,
                logprobs_tensors=self._logprobs_tensors_cpu,
            )

        output = self._model_runner_output
        output.sampled_token_ids = valid_sampled_token_ids
        output.logprobs = logprobs_lists

        if self._routed_experts_cpu is not None:
            output.routed_experts = self._routed_experts_cpu.tolists()
        del self._routed_experts

        return output


def _copy_pooler_output_to_cpu(
    raw_pooler_output: PoolerOutput, finished_mask: list[bool]
) -> list[torch.Tensor | None]:
    num_reqs = len(finished_mask)

    if isinstance(raw_pooler_output, torch.Tensor):
        if raw_pooler_output.shape[0] != num_reqs:
            raise ValueError(
                "Pooler output batch size does not match finished mask size: "
                f"{raw_pooler_output.shape[0]} != {num_reqs}."
            )

        num_finished = sum(finished_mask)
        if num_finished == 0:
            return [None] * num_reqs
        if num_finished == num_reqs:
            return list(raw_pooler_output.to("cpu", non_blocking=True))

        # partial finished
        finished_indices = [i for i, include in enumerate(finished_mask) if include]
        index_tensor = torch.tensor(
            finished_indices, device=raw_pooler_output.device, dtype=torch.long
        )
        finished_outputs = raw_pooler_output.index_select(0, index_tensor).to(
            "cpu", non_blocking=True
        )
        partial_pooler_output: list[torch.Tensor | None] = [None] * num_reqs
        for i, out in zip(finished_indices, finished_outputs):
            partial_pooler_output[i] = out
        return partial_pooler_output

    assert isinstance(raw_pooler_output, list)
    if len(raw_pooler_output) != num_reqs:
        raise ValueError(
            "Pooler output batch size does not match finished mask size: "
            f"{len(raw_pooler_output)} != {num_reqs}."
        )

    pooler_output: list[torch.Tensor | None] = [None] * num_reqs
    for i, (out, include) in enumerate(zip(raw_pooler_output, finished_mask)):
        if include and out is not None:
            pooler_output[i] = out.to("cpu", non_blocking=True)
    return pooler_output


class AsyncGPUPoolingModelRunnerOutput(AsyncModelRunnerOutput):
    def __init__(
        self,
        model_runner_output: ModelRunnerOutput,
        raw_pooler_output: PoolerOutput,
        finished_mask: list[bool],
        async_output_copy_stream: torch.cuda.Stream,
        synchronize=None,
    ):
        self._synchronize = synchronize or sm70_trace_event_sync
        self._model_runner_output = model_runner_output

        # Event on the copy stream so we can synchronize the non-blocking copy.
        self.async_copy_ready_event = torch.Event()

        # Keep a reference to the device tensors to avoid them being
        # deallocated until we finish copying it to the host.
        self._raw_pooler_output = raw_pooler_output

        # Initiate the copy on a separate stream, but do not synchronize it.
        default_stream = torch.cuda.current_stream()
        with torch.cuda.stream(async_output_copy_stream):
            async_output_copy_stream.wait_stream(default_stream)
            self._model_runner_output.pooler_output = _copy_pooler_output_to_cpu(
                raw_pooler_output=self._raw_pooler_output,
                finished_mask=finished_mask,
            )
            self.async_copy_ready_event.record()

    def get_output(self) -> ModelRunnerOutput:
        """Copy the device tensors to the host and return a ModelRunnerOutput.
        This function blocks until the copy is finished.
        """
        self._synchronize(
            self.async_copy_ready_event,
            "AsyncGPUPoolingModelRunnerOutput.async_copy_ready_event.synchronize",
        )

        # Release the device tensors once the copy has completed.
        del self._raw_pooler_output
        return self._model_runner_output


class ExecuteModelState(NamedTuple):
    """Ephemeral cached state transferred between execute_model() and
    sample_tokens(), after execute_model() returns None."""

    scheduler_output: "SchedulerOutput"
    logits: torch.Tensor | None
    spec_decode_metadata: SpecDecodeMetadata | None
    spec_decode_common_attn_metadata: CommonAttentionMetadata | None
    hidden_states: torch.Tensor
    sample_hidden_states: torch.Tensor
    logits_indices: torch.Tensor | None
    cudagraph_mode: CUDAGraphMode
    sample_hidden_ready_event: torch.cuda.Event | None
    aux_hidden_states: list[torch.Tensor] | None
    ec_connector_output: ECConnectorOutput | None
    cudagraph_stats: CUDAGraphStat | None
    slot_mappings_by_group: dict[int, torch.Tensor] | None
    slot_mappings: dict[str, torch.Tensor] | list[dict[str, torch.Tensor]] | None


@dataclass(frozen=True)
class DDTreeAcceptedCopyPlan:
    accepted_rows: list[list[int]]
    kv_local_copies: list[tuple[int, int]]
    state_slot_copies: list[tuple[int, int, int]]
    flat_prefix: bool


class DDTreeMambaCopyRecord(TypedDict):
    kv_cache_gid: int
    req_idx: int
    req_id: str
    req_state: CachedRequestState
    src_slot: int
    dst_slot: int
    state_window_start: int
    src_block_idx: int
    dst_block_idx: int
    src_block_id: int
    dst_block_id: int


def _non_greedy_rows_carry_drafts(
    sampling_metadata: SamplingMetadata,
    spec_decode_metadata: SpecDecodeMetadata,
) -> bool:
    """Whether any non-greedy request in this verify step carries draft tokens.

    Draft tokens are proposed one step ahead with the *previous* batch's
    sampling metadata. When that batch was all-greedy the proposer takes the
    argmax fast path and legitimately returns no draft probabilities. If a
    sampled (non-greedy) request joins the batch on the next step it has zero
    draft tokens at that step, so no probability rows are needed for it, and
    the greedy rows are verified by argmax without probabilities. Only a
    non-greedy row that actually carries draft tokens needs ``draft_probs``;
    that is the case the missing-probability guard must reject.
    """
    num_draft_tokens = spec_decode_metadata.num_draft_tokens
    if not any(num_draft_tokens):
        return False
    temperature = sampling_metadata.temperature
    if temperature is None:
        return False
    # Exceptional path only (probabilistic MTP, mixed batch, no probs), so the
    # small device-to-host copy here does not sit on the steady-state step.
    is_greedy = (temperature[: len(num_draft_tokens)] == GREEDY_TEMPERATURE).tolist()
    return any(n > 0 and not greedy for n, greedy in zip(num_draft_tokens, is_greedy))


_V41_TRUNC_CUTOFF = int(envs.VLLM_V41_TRUNC_CUTOFF)
_V41_TRUNC = envs.VLLM_V41_TRUNC == "1"


class GPUModelRunner(
    LoRAModelRunnerMixin, KVConnectorModelRunnerMixin, ECConnectorModelRunnerMixin
):
    @contextmanager
    def _dflash_ddtree_target_forward_profile_scope(
        self,
        *,
        use_spec_decode: bool,
        num_tokens: int,
        num_reqs: int,
        cudagraph_mode: CUDAGraphMode,
    ) -> Iterator[None]:
        if (
            not use_spec_decode
            or self.speculative_config is None
            or not (
                self.speculative_config.use_dflash_ddtree()
                or self.speculative_config.use_dspark()
            )
            or self.device.type != "cuda"
        ):
            yield
            return

        # The scope opens before the forward context, so the module-level
        # lookup would rebuild a standalone trace config on every step; the
        # runner borrows its engine's own diagnostic owner instead.
        trace = self.vllm_config.observability_config.runtime_trace
        nvtx_enabled = _dflash_ddtree_target_forward_nvtx_enabled(trace)
        profiler_step = _dflash_ddtree_target_forward_profiler_step(trace)
        if not nvtx_enabled and profiler_step <= 0:
            yield
            return

        step = getattr(self, "_dflash_ddtree_target_forward_profile_step", 0) + 1
        self._dflash_ddtree_target_forward_profile_step = step
        label_prefix = (
            "ddtree_target_forward"
            if self.speculative_config.use_dflash_ddtree()
            else "dspark_target_forward"
        )
        label = (
            f"{label_prefix}:step={step}:tokens={num_tokens}:reqs={num_reqs}"
            f":mode={cudagraph_mode.name}:pid={os.getpid()}"
        )
        profile_this_step = profiler_step > 0 and step == profiler_step
        pushed_nvtx = False
        started_profiler = False
        try:
            if nvtx_enabled:
                torch.cuda.nvtx.range_push(label)
                pushed_nvtx = True
            if profile_this_step:
                # Make the cudaProfilerApi capture range contain only this
                # target forward's graph replay/kernels, not earlier queued work.
                torch.accelerator.synchronize()
                torch.cuda.cudart().cudaProfilerStart()
                started_profiler = True
            yield
        finally:
            if started_profiler:
                torch.accelerator.synchronize()
                torch.cuda.cudart().cudaProfilerStop()
            if pushed_nvtx:
                torch.cuda.nvtx.range_pop()

    def __init__(
        self,
        vllm_config: VllmConfig,
        device: torch.device,
    ):
        self.vllm_config = vllm_config
        self._diagnostics = bind_diagnostics(vllm_config)
        self.model_config = vllm_config.model_config
        self.mm_encoder_batch_size = getattr(
            self.model_config.multimodal_config, "mm_encoder_batch_size", 0
        )
        self.cache_config = vllm_config.cache_config
        self.offload_config = vllm_config.offload_config
        self.compilation_config = vllm_config.compilation_config
        self.lora_config = vllm_config.lora_config
        self.load_config = vllm_config.load_config
        self.parallel_config = vllm_config.parallel_config
        self.scheduler_config = vllm_config.scheduler_config
        self.speculative_config = vllm_config.speculative_config
        self.observability_config = vllm_config.observability_config

        model_config = self.model_config
        cache_config = self.cache_config
        scheduler_config = self.scheduler_config
        parallel_config = self.parallel_config
        self.device = device
        self._auxiliary_warmup_enabled = auxiliary_warmup_enabled(vllm_config)
        self._step_profiler = create_step_profiler(
            vllm_config, device, role="runner", logger=logger
        )
        from vllm.v1.worker.mixed_prefill import MixedPrefillTimer

        self.mixed_prefill_timer = MixedPrefillTimer()
        self.pin_memory = is_pin_memory_available()
        self.dtype = self.model_config.dtype

        self.kv_cache_dtype = kv_cache_dtype_str_to_dtype(
            cache_config.cache_dtype, self.model_config
        )

        self.is_pooling_model = model_config.runner_type == "pooling"
        self.enable_prompt_embeds = model_config.enable_prompt_embeds
        self.is_multimodal_raw_input_only_model = (
            model_config.is_multimodal_raw_input_only_model
        )
        # These will be overridden in load_model()
        self.is_multimodal_pruning_enabled = False
        self.requires_sequential_video_encoding = False
        # Set to True after init_routed_experts_capturer() completes.
        # Prevents routed experts code from running during profiling/dummy run.
        self.routed_experts_initialized = False
        self.max_model_len = model_config.max_model_len

        # Always set to false after the first forward pass
        self.calculate_kv_scales = self.cache_config.calculate_kv_scales
        self.dcp_world_size = self.parallel_config.decode_context_parallel_size
        self.dcp_rank = 0 if self.dcp_world_size <= 1 else get_dcp_group().rank_in_group
        self.max_num_tokens = scheduler_config.max_num_batched_tokens
        self.max_num_reqs = scheduler_config.max_num_seqs
        self.max_spec_state_slots = 1 + (
            self.speculative_config.num_speculative_state_tokens()
            if self.speculative_config is not None
            else 0
        )
        self.num_spec_tokens = (
            self.speculative_config.num_speculative_tokens
            if self.speculative_config is not None
            else 0
        )

        # Broadcast PP output for external_launcher (torchrun)
        # to make sure we are synced across pp ranks
        # TODO: Support overlapping micro-batches
        # https://github.com/vllm-project/vllm/issues/18019
        self.broadcast_pp_output = (
            self.parallel_config.distributed_executor_backend == "external_launcher"
            and len(get_pp_group().ranks) > 1
        )

        # Model-related.
        self.num_query_heads = model_config.get_num_attention_heads(parallel_config)
        self.inputs_embeds_size = model_config.get_inputs_embeds_size()
        # Only relevant for models using ALiBi (e.g, MPT)
        self.use_alibi = model_config.uses_alibi

        ple_layer_ids = getattr(model_config.hf_text_config, "ple_layer_ids", ())
        self.uses_ngram_embedding = bool(ple_layer_ids)
        if self.uses_ngram_embedding:
            self.ngram_context_len = int(model_config.hf_text_config.ngram_size) - 1
            self.ngram_eos_token_id = int(model_config.hf_text_config.eos_token_id)
        else:
            self.ngram_context_len = 0
            self.ngram_eos_token_id = 0
        if self.uses_ngram_embedding and self.ngram_context_len <= 0:
            raise ValueError("N-gram embedding requires context length >= 1")
        if self.uses_ngram_embedding:
            from vllm.models.qwen4_exp.common.ple import (
                check_ple_layers_on_first_pp_rank,
            )

            check_ple_layers_on_first_pp_rank(
                model_config.hf_text_config, parallel_config.pipeline_parallel_size
            )
        self._ple_offload_connector: Any | None = None

        self.cascade_attn_enabled = not self.model_config.disable_cascade_attn
        self.is_mm_prefix_lm = self.model_config.is_mm_prefix_lm

        # Multi-modal data support
        self.mm_registry = MULTIMODAL_REGISTRY
        self.uses_mrope = model_config.uses_mrope
        self.uses_xdrope_dim = model_config.uses_xdrope_dim
        self.supports_mm_inputs = self.mm_registry.supports_multimodal_inputs(
            model_config
        )

        if self.model_config.is_encoder_decoder:
            # Maximum length of the encoder input, only for encoder-decoder
            # models.
            self.max_encoder_len = scheduler_config.max_num_encoder_input_tokens
        else:
            self.max_encoder_len = 0

        # Async scheduling
        self.use_async_scheduling = bool(self.scheduler_config.async_scheduling)
        self.dspark_confidence_scheduling = bool(
            self.speculative_config is not None
            and self.speculative_config.use_dspark()
            and (
                self.speculative_config.dspark_confidence_threshold > 0.0
                or (
                    self.speculative_config.dspark_max_verification_tokens is not None
                    and self.speculative_config.dspark_max_verification_tokens
                    < self.num_spec_tokens
                )
            )
        )
        if self.dspark_confidence_scheduling and self.use_async_scheduling:
            raise ValueError(
                "DSpark confidence prefix scheduling currently requires "
                "synchronous scheduling."
            )
        self._sm70_async_worker_execute_trace_step = 0
        self._sm70_async_worker_sample_trace_step = 0
        self._input_transfer = create_input_transfer(vllm_config, device, logger=logger)
        from vllm.diagnostics import bind_event_tracer

        self._event_tracer = bind_event_tracer(vllm_config)
        self._runtime_trace = vllm_config.observability_config.runtime_trace
        assert self._runtime_trace.async_every is not None
        self._async_trace_every = self._runtime_trace.async_every

        # Sampler
        self.sampler = Sampler(
            logprobs_mode=self.model_config.logprobs_mode, diagnostics=self._diagnostics
        )
        self.sm70_greedy_token_fastpath = bool(
            vllm_config.kernel_config.layer_execution.greedy_token_fastpath
        )
        self.sm70_greedy_token_fastpath_trace = self._runtime_trace.greedy_token_trace
        self._sm70_greedy_token_fastpath_trace_seen: set[str] = set()
        draft_vocab_config = resolve_mtp_draft_vocab_config(
            (self.speculative_config.method or "") if self.speculative_config else "",
            self.parallel_config.tensor_parallel_size,
            self.model_config.architecture,
            self.model_config.model,
            policy=(
                self.speculative_config.sampling_policy
                if self.speculative_config is not None
                else None
            ),
        )
        self.dynamic_draft_vocab_prefill_topk = draft_vocab_config.prefill_topk
        validate_dynamic_draft_vocab_prefill_topk(
            self.dynamic_draft_vocab_prefill_topk,
            gpu_lru_enabled=draft_vocab_config.gpu_lru_enabled,
            full_vocab_size=self.model_config.get_vocab_size(),
        )
        self._dynamic_draft_vocab_prefill_bootstrap = (
            DynamicDraftVocabPrefillBootstrapState()
        )
        if self.dynamic_draft_vocab_prefill_topk:
            logger.warning(
                "Enabled one-shot target-logits dynamic-vocab prefill bootstrap: "
                "topk=%d. This experimental GPU-LRU route requires fresh-process "
                "acceptance validation.",
                self.dynamic_draft_vocab_prefill_topk,
            )
        _maybe_log_sm70_decode_event_trace_config(
            use_async_scheduling=self.use_async_scheduling,
            greedy_token_fastpath=self.sm70_greedy_token_fastpath,
            num_spec_tokens=self.num_spec_tokens,
            diagnostics=self._diagnostics,
        )

        self.eplb_state: EplbState | None = None
        self._moe_model: MixtureOfExperts | None = None
        # NOTE(yongji): flag to temporarily disable EPLB during scaling up/down
        self.eep_eplb_suppressed = False
        """
        State of the expert parallelism load balancer.

        Will be lazily initialized when the model is loaded.
        """

        # Lazy initializations
        # self.model: nn.Module  # Set after load_model
        # Initialize in initialize_kv_cache
        self.kv_caches: list[torch.Tensor] = []
        # Initialize in initialize_kv_cache_tensors
        self.cross_layers_kv_cache: torch.Tensor | None = None
        self.cross_layers_attn_backend: type[AttentionBackend] | None = None
        # indexes: [kv_cache_group_id][attn_group]
        self.attn_groups: list[list[AttentionGroup]] = []
        # self.kv_cache_config: KVCacheConfig

        # mm_hash ->  encoder_output
        self.encoder_cache: dict[str, torch.Tensor] = {}
        self.late_interaction_runner = LateInteractionRunner()

        # Encoder CUDA graph manager (initialized after model load if enabled)
        self.encoder_cudagraph_manager: EncoderCudaGraphManager | None = None

        self.use_aux_hidden_state_outputs = False
        # Set up speculative decoding.
        # NOTE(Jiayi): currently we put the entire draft model on
        # the last PP rank. This is not ideal if there are many
        # layers in the draft model.
        if self.speculative_config and get_pp_group().is_last_rank:
            self.drafter: (
                NgramProposer  # noqa: F823
                | NgramProposerGPU
                | SuffixDecodingProposer
                | EagleProposer
                | DFlashProposer
                | DSparkProposer
                | DraftModelProposer
                | MedusaProposer
                | ExtractHiddenStatesProposer
                | Gemma4Proposer
                | Step3p5MTPProposer
                | Qwen4ExpMTPProposer
                | None
            )
            if self.speculative_config.method == "custom_class":
                self.drafter = create_custom_proposer(  # type: ignore[assignment]
                    self.vllm_config
                )
            elif self.speculative_config.method == "ngram":
                from vllm.v1.spec_decode.ngram_proposer import NgramProposer

                self.drafter = NgramProposer(self.vllm_config)
            elif self.speculative_config.uses_draft_model():
                self.drafter = DraftModelProposer(
                    vllm_config=self.vllm_config,
                    device=self.device,
                    runner=self,
                )
            elif self.speculative_config.use_ngram_gpu():
                self.drafter = NgramProposerGPU(self.vllm_config, self.device, self)
                self.num_tokens_no_spec_gpu = torch.zeros(
                    self.max_num_reqs, dtype=torch.int32, device=device
                )
                self.token_ids_gpu_tensor = torch.zeros(
                    self.max_num_reqs,
                    self.max_model_len,
                    dtype=torch.int32,
                    device=device,
                )
                self._ngram_pinned_idx_buf = torch.zeros(
                    self.max_num_reqs, dtype=torch.long, pin_memory=True
                )
                self._ngram_pinned_val_buf = torch.zeros(
                    self.max_num_reqs, dtype=torch.int32, pin_memory=True
                )
            elif self.speculative_config.use_gemma4_mtp():
                self.drafter = Gemma4Proposer(self.vllm_config, self.device, self)
            elif self.speculative_config.use_step3p5_mtp():
                self.drafter = Step3p5MTPProposer(self.vllm_config, self.device, self)
            elif self.speculative_config.use_qwen4_exp_mtp():
                self.drafter = Qwen4ExpMTPProposer(self.vllm_config, self.device, self)
            elif self.speculative_config.use_dspark():
                self.drafter = DSparkProposer(self.vllm_config, self.device, self)
                self.use_aux_hidden_state_outputs = True
            elif self.speculative_config.use_dflash_ddtree():
                self.drafter = DFlashProposer(self.vllm_config, self.device, self)
                self.use_aux_hidden_state_outputs = (
                    self.drafter.eagle3_use_aux_hidden_state
                    and not envs.VLLM_DFLASH_DISABLE_AUX_OUTPUTS
                )
            elif self.speculative_config.method == "suffix":
                self.drafter = SuffixDecodingProposer(self.vllm_config)
            elif self.speculative_config.use_eagle():
                self.drafter = EagleProposer(self.vllm_config, self.device, self)
                if self.speculative_config.method == "eagle3":
                    self.use_aux_hidden_state_outputs = (
                        self.drafter.eagle3_use_aux_hidden_state
                    )
            elif self.speculative_config.method == "medusa":
                self.drafter = MedusaProposer(
                    vllm_config=self.vllm_config, device=self.device
                )
            elif self.speculative_config.method == "extract_hidden_states":
                self.drafter = ExtractHiddenStatesProposer(
                    vllm_config=self.vllm_config, device=self.device
                )
                self.use_aux_hidden_state_outputs = True
            else:
                raise ValueError(
                    "Unknown speculative decoding method: "
                    f"{self.speculative_config.method}"
                )
            self.rejection_sampler = RejectionSampler(
                self.sampler,
                self.speculative_config,
                self.device,
                diagnostics=self._diagnostics,
            )

        elif self.speculative_config:
            # Non-last PP ranks never build a drafter (the entire draft
            # model lives on the last rank, see the note above), but code
            # that runs on every rank probes the attribute -- the
            # attention-metadata builder does so during memory profiling,
            # long before any request arrives. Bind it so those
            # isinstance() checks fall through instead of raising
            # AttributeError.
            self.drafter = None
        self.valid_sampled_token_count_gpu: torch.Tensor | None = None
        if self.speculative_config:
            draft_config = self.speculative_config.draft_model_config
            if draft_config is not None and draft_config.max_model_len is not None:
                self.effective_drafter_max_model_len = draft_config.max_model_len
            else:
                self.effective_drafter_max_model_len = self.max_model_len
        self.sync_spec_decode_accept_counts = (
            self.use_async_scheduling
            and self.num_spec_tokens > 0
            and self.speculative_config is not None
            and self.speculative_config.sampling_policy.sync_accept_counts
        )
        self.use_async_spec_decode = (
            self.use_async_scheduling
            and self.num_spec_tokens > 0
            and not self.sync_spec_decode_accept_counts
        )

        # Request states.
        self.requests: dict[str, CachedRequestState] = {}
        # NOTE(rob): num_prompt_logprobs only includes reqs
        # that are currently in the prefill phase.
        self.num_prompt_logprobs: dict[str, int] = {}

        # Input Batch
        # NOTE(Chen): Ideally, we should initialize the input batch inside
        # `initialize_kv_cache` based on the kv cache config. However, as in
        # https://github.com/vllm-project/vllm/pull/18298, due to some unknown
        # reasons, we have to initialize the input batch before `load_model`,
        # quantization + weight offloading will fail otherwise. As a temporary
        # solution, we initialize the input batch here, and re-initialize it
        # in `initialize_kv_cache` if the block_sizes here is different from
        # the block_sizes in the kv cache config.
        logits_processors = model_config.logits_processors
        custom_logitsprocs: Sequence[str | type[LogitsProcessor]] = (
            tuple(logits_processors) if logits_processors is not None else ()
        )
        placeholder_block_size = (
            self.cache_config.block_size or CacheConfig.DEFAULT_BLOCK_SIZE
        )
        self._init_block_sizes = [placeholder_block_size]
        self._init_kernel_block_sizes = [placeholder_block_size]
        self._init_dcp_sharded = [True]
        self.input_batch = InputBatch(
            runtime_policy=self.vllm_config.kernel_config.sm70_runtime,
            max_num_reqs=self.max_num_reqs,
            # We need to use the encoder length for encoder-decoder
            # because of KV cache for cross-attention.
            max_model_len=max(self.max_model_len, self.max_encoder_len),
            max_num_batched_tokens=self.max_num_tokens,
            device=self.device,
            pin_memory=self.pin_memory,
            vocab_size=self.model_config.get_vocab_size(),
            block_sizes=[placeholder_block_size],
            kernel_block_sizes=[placeholder_block_size],
            num_spec_tokens=self.num_spec_tokens,
            logitsprocs=build_logitsprocs(
                self.vllm_config,
                self.device,
                self.pin_memory,
                self.is_pooling_model,
                custom_logitsprocs,
            ),
            # We currently don't know whether a particular custom logits processor
            # uses output token ids so we set this conservatively.
            # ThinkingTokenBudgetLogitsProcessor also needs output token ids to
            # correctly track think start/end token sequences in async scheduling.
            logitsprocs_need_output_token_ids=bool(custom_logitsprocs)
            or self.vllm_config.reasoning_config is not None,
            is_pooling_model=self.is_pooling_model,
            cp_kv_cache_interleave_size=self.parallel_config.cp_kv_cache_interleave_size,
            reasoning_config=self.vllm_config.reasoning_config,
        )

        # Separate cuda stream for overlapping transfer of sampled token ids from
        # GPU to CPU when async scheduling is enabled.
        self.async_output_copy_stream: torch.cuda.Stream | None = None
        # cuda event to synchronize use of output tensors between steps
        # when async scheduling is enabled.
        self.prepare_inputs_event = None
        if self.use_async_scheduling:
            self.async_output_copy_stream = torch.cuda.Stream()
            self.prepare_inputs_event = torch.Event()

        # self.cudagraph_batch_sizes sorts in ascending order.
        if (
            self.compilation_config.cudagraph_capture_sizes
            and self.compilation_config.cudagraph_mode != CUDAGraphMode.NONE
        ):
            self.cudagraph_batch_sizes = sorted(
                self.compilation_config.cudagraph_capture_sizes
            )
        else:
            self.cudagraph_batch_sizes = []

        # Cache the device properties.
        self._init_device_properties()

        # Encoder timing registry for observability
        self.encoder_timing_registry: dict[str, EncoderTimingStats] = {}
        self._encoder_timing_lock = threading.Lock()

        # Persistent buffers for CUDA graphs.
        self.input_ids = self._make_buffer(self.max_num_tokens, dtype=torch.int32)
        self.positions = torch.zeros(
            self.max_num_tokens, dtype=torch.int64, device=self.device
        )
        self.query_start_loc = self._make_buffer(
            self.max_num_reqs + 1, dtype=torch.int32
        )
        self.seq_lens = torch.zeros(
            self.max_num_reqs, dtype=torch.int32, device=self.device
        )
        self.optimistic_seq_lens_cpu = torch.zeros(
            self.max_num_reqs, dtype=torch.int32, pin_memory=self.pin_memory
        )
        self.num_computed_tokens = torch.zeros(
            self.max_num_reqs, dtype=torch.int32, device=self.device
        )
        self.prev_num_draft_tokens = self._make_buffer(
            self.max_num_reqs, dtype=torch.int32
        )
        self.req_indices = self._make_buffer(self.max_num_tokens, dtype=torch.int64)
        # Maps current batch position -> previous batch position (-1 for new reqs)
        self.prev_positions = self._make_buffer(self.max_num_reqs, dtype=torch.int64)
        self.num_scheduled_tokens = self._make_buffer(
            self.max_num_reqs, dtype=torch.int32
        )

        self.encoder_seq_lens = self._make_buffer(self.max_num_reqs, dtype=torch.int32)
        if self.dcp_world_size > 1:
            self.dcp_local_seq_lens = self._make_buffer(
                self.max_num_reqs, dtype=torch.int32
            )
        # Because inputs_embeds may be bfloat16 and we don't need a numpy
        # version of this tensor, avoid a RuntimeError by not creating a
        # numpy buffer.
        self.inputs_embeds = self._make_buffer(
            self.max_num_tokens, self.inputs_embeds_size, dtype=self.dtype, numpy=False
        )
        if self.uses_ngram_embedding:
            self.ngram_context = self._make_buffer(
                self.max_num_reqs,
                self.ngram_context_len,
                dtype=torch.int32,
            )
        self.is_token_ids = self._make_buffer(self.max_num_tokens, dtype=torch.bool)
        self.discard_request_mask = self._make_buffer(
            self.max_num_reqs, dtype=torch.bool
        )
        self.num_decode_draft_tokens = self._make_buffer(
            self.max_num_reqs, dtype=torch.int32
        )
        self.num_accepted_tokens = self._make_buffer(
            self.max_num_reqs, dtype=torch.int32
        )
        self.spec_state_slot_selectors = self._make_buffer(
            self.max_num_reqs, dtype=torch.int32
        )
        self.current_mamba_state_block_ids = self._make_buffer(
            self.max_num_reqs,
            self.max_spec_state_slots,
            dtype=torch.int32,
        )
        self.ddtree_parent_ids = self._make_buffer(
            self.max_num_reqs,
            self.max_spec_state_slots,
            dtype=torch.int32,
        )
        self.ddtree_num_tree_tokens_cpu = torch.zeros(
            self.max_num_reqs, dtype=torch.int32, device="cpu"
        )

        # Only relevant for models using M-RoPE (e.g, Qwen2-VL)
        if self.uses_mrope:
            # NOTE: `mrope_positions` is implemented with one additional dummy
            # position on purpose to make it non-contiguous so that it can work
            # with torch compile.
            # See detailed explanation in https://github.com/vllm-project/vllm/pull/12128#discussion_r1926431923

            # NOTE: When M-RoPE is enabled, position ids are 3D regardless of
            # the modality of inputs. For text-only inputs, each dimension has
            # identical position IDs, making M-RoPE functionally equivalent to
            # 1D-RoPE.
            # See page 5 of https://arxiv.org/abs/2409.12191
            self.mrope_positions = self._make_buffer(
                (3, self.max_num_tokens + 1), dtype=torch.int64
            )

        # Only relevant for models using XD-RoPE (e.g, HunYuan-VL)
        if self.uses_xdrope_dim > 0:
            # Similar to mrope but use assigned dimension number for RoPE, 4 as default.
            self.xdrope_positions = self._make_buffer(
                (self.uses_xdrope_dim, self.max_num_tokens + 1), dtype=torch.int64
            )

        # None in the first PP rank. The rest are set after load_model.
        self.intermediate_tensors: IntermediateTensors | None = None

        # OPTIMIZATION: Cache the arange tensors rather than creating them
        # every step. Keep in int64 to avoid overflow with long context.
        # - arange_np: immutable [0, 1, 2, ...] used as source for batched computation
        # - query_pos: CpuGpuBuffer for the computed batched arange result
        arange_size = max(self.max_num_reqs + 1, self.max_num_tokens)
        self.arange_np = np.arange(arange_size, dtype=np.int64)
        self.query_pos = self._make_buffer(arange_size, dtype=torch.int64)
        self._arange_scratch = np.empty(arange_size, dtype=np.int64)

        # Layer pairings for cross-layer KV sharing.
        # If an Attention layer `layer_name` is in the keys of this dict, it
        # means this layer will perform attention using the keys and values
        # from the KV cache of `shared_kv_cache_layers[layer_name]`.
        self.shared_kv_cache_layers: dict[str, str] = {}
        self.kv_sharing_fast_prefill_eligible_layers: set[str] = set()

        self.kv_sharing_fast_prefill_logits_indices = None
        if self.cache_config.kv_sharing_fast_prefill:
            self.kv_sharing_fast_prefill_logits_indices = torch.zeros(
                self.max_num_tokens, dtype=torch.int32, device=self.device
            )

        self.uniform_decode_query_len = self.max_spec_state_slots

        # Cudagraph dispatcher for runtime cudagraph dispatching.
        self.cudagraph_dispatcher = CudagraphDispatcher(self.vllm_config)

        self.mm_budget = (
            MultiModalBudget(self.vllm_config, self.mm_registry)
            if self.supports_mm_inputs
            else None
        )

        self.reorder_batch_threshold: int | None = None

        # Attention layers that are only in the KVCacheConfig of the runner
        # (e.g., KV sharing, encoder-only attention), but not in the
        # KVCacheConfig of the scheduler.
        self.runner_only_attn_layers: set[str] = set()

        # Cached outputs.
        self._draft_token_ids: list[list[int]] | torch.Tensor | None = None
        self._draft_probs: torch.Tensor | None = None
        self._draft_prob_req_ids: list[str] | None = None
        self._draft_prob_token_ids: list[list[int]] | torch.Tensor | None = None
        self._draft_confidence_logits: torch.Tensor | None = None
        self._draft_confidence_req_ids: list[str] | None = None
        self._draft_confidence_token_ids: list[list[int]] | torch.Tensor | None = None
        self._dspark_verification_lengths: torch.Tensor | None = None
        self._dspark_verification_lengths_cpu: torch.Tensor | None = None
        if self.dspark_confidence_scheduling:
            self._dspark_verification_lengths_cpu = torch.empty(
                self.max_num_reqs,
                dtype=torch.int32,
                device="cpu",
                pin_memory=self.pin_memory,
            )
        self._dflash_ddtree_payloads: tuple[DDTreeDraftPayload, ...] | None = None
        self._ddtree_parent_metadata: DDTreeParentMetadata | None = None
        self._ddtree_accepted_rows_cpu_sidecar: list[list[int]] | None = None
        self._ddtree_sampled_token_counts_cpu_sidecar: list[int] | None = None
        self._current_positions_cpu_sidecar: np.ndarray | None = None
        self._current_req_indices_cpu_sidecar: np.ndarray | None = None
        # N-gram GPU path: async D2H buffer/event for per-request valid draft counts.
        self._num_valid_draft_tokens: torch.Tensor | None = None
        self._num_valid_draft_tokens_cpu: torch.Tensor | None = None
        self._num_valid_draft_tokens_event: torch.cuda.Event | None = None
        self._num_valid_draft_tokens_copy_stream: torch.cuda.Stream | None = None
        if (
            self.speculative_config is not None
            and self.speculative_config.use_ngram_gpu()
        ):
            self._num_valid_draft_tokens_cpu = torch.empty(
                self.max_num_reqs, dtype=torch.int32, pin_memory=self.pin_memory
            )
            self._num_valid_draft_tokens_event = torch.cuda.Event()
            self._num_valid_draft_tokens_copy_stream = torch.cuda.Stream()

        self._draft_token_req_ids: list[str] | None = None
        self.transfer_event = torch.Event()
        self.sampled_token_ids_pinned_cpu = torch.empty(
            (self.max_num_reqs, 1),
            dtype=torch.int64,
            device="cpu",
            pin_memory=self.pin_memory,
        )

        # Pre-allocated tensor for copying valid sampled token counts to CPU,
        # with dedicated stream for overlapping and event for coordination.
        self.valid_sampled_token_count_event: torch.Event | None = None
        self.valid_sampled_token_count_copy_stream: torch.cuda.Stream | None = None
        # We also copy the drafted tokens to the CPU asynchronously,
        # in case we need them for structured outputs.
        self.draft_token_ids_event: torch.Event | None = None
        self.draft_token_ids_copy_stream: torch.cuda.Stream | None = None
        self.valid_sampled_token_count_cpu: torch.Tensor | None = None
        self.draft_token_ids_cpu: torch.Tensor | None = None
        self.num_accepted_tokens_event: torch.Event | None = None
        # Row ownership for the runner-owned accepted-token D2H snapshots.
        # Keep the request object as well as its ID so abort-and-resubmit with
        # the same ID is still treated as a new request.
        self._mamba_accepted_token_state_rows: dict[
            str, tuple[int, CachedRequestState]
        ] = {}
        if self.num_spec_tokens:
            self.draft_token_ids_event = torch.Event()
            self.num_accepted_tokens_event = torch.Event()
            self.draft_token_ids_copy_stream = torch.cuda.Stream()
            self.draft_token_ids_cpu = torch.empty(
                (self.max_num_reqs, self.num_spec_tokens),
                dtype=torch.int64,
                device="cpu",
                pin_memory=self.pin_memory,
            )
            if self.use_async_scheduling:
                self.valid_sampled_token_count_event = torch.Event()
                self.valid_sampled_token_count_copy_stream = torch.cuda.Stream()
                self.valid_sampled_token_count_cpu = torch.empty(
                    self.max_num_reqs,
                    dtype=torch.int32,
                    device="cpu",
                    pin_memory=self.pin_memory,
                )

        # Model weight offloader
        # Make sure this is called before any get_offloader call
        set_offloader(create_offloader(self.offload_config))

        # Ephemeral state transferred between execute_model() and sample_tokens().
        self.execute_model_state: ExecuteModelState | None = None
        # Non-last PP rank under speculative decoding: this step's
        # scheduler_output, kept until the sampled matrix arrives from the
        # last rank in sample_tokens() (hybrid-state update).
        self._pp_nonlast_scheduler_output: SchedulerOutput | None = None
        self.kv_connector_output: KVConnectorOutput | None = None
        self.mamba_state_idx: dict[str, int] = {}
        self._mamba_bufs: mamba_utils.MambaBuffers | None = None
        self.mamba_prev_last_scheduled_idx: CpuGpuBuffer | None = None
        if self.cache_config.mamba_cache_mode == "all" and self.num_spec_tokens > 0:
            self.mamba_prev_last_scheduled_idx = self._make_buffer(
                self.max_num_reqs, dtype=torch.int32
            )
        self.layerwise_nvtx_hooks_registered = False

    def update_max_model_len(self, max_model_len: int) -> None:
        self.max_model_len = max_model_len
        if self.speculative_config:
            draft_config = self.speculative_config.draft_model_config
            if draft_config is None or draft_config.max_model_len is None:
                self.effective_drafter_max_model_len = self.max_model_len

    def reset_mm_cache(self) -> None:
        """
        Clear the multi-modal cache that was used during profiling,
        but no longer needed during inference.
        """
        if self.mm_budget:
            self.mm_budget.reset_cache()
        self.late_interaction_runner.clear()

    def reset_encoder_cache(self) -> None:
        """Clear the GPU-side encoder cache storing vision embeddings.

        This should be called when model weights are updated to ensure
        stale embeddings computed with old weights are not reused.
        """
        self.encoder_cache.clear()
        self.late_interaction_runner.clear()

    def post_kv_cache_wake_up(self) -> None:
        self.init_fp8_kv_scales()

    @torch.inference_mode()
    def init_fp8_kv_scales(self) -> None:
        """
        Re-initialize the KV cache and FP8 scales after waking from sleep.
        1. Zero out the KV cache tensors to remove garbage data from re-allocation.
        2. Reset Attention layer scaling factors (_k_scale, _v_scale) to 1.0.
          If these are left at 0.0 (default after wake_up), all KV cache values
          become effectively zero, causing gibberish output.
        """
        if not is_quantized_kv_cache(self.cache_config.cache_dtype):
            return

        kv_caches = getattr(self, "kv_caches", [])
        for cache_tensor in kv_caches:
            if cache_tensor is not None:
                cache_tensor.zero_()

        k_attr_names = ("_k_scale", "k_scale")
        v_attr_names = ("_v_scale", "v_scale")

        attn_layers = self.compilation_config.static_forward_context
        for name, module in attn_layers.items():
            if isinstance(module, (Attention, MLAAttention)):
                # TODO: Generally, scale is 1.0 if user uses on-the-fly fp8
                # kvcache quant. However, to get better accuracy, compression
                # frameworks like llm-compressors allow users to tune the
                # scale. We may need to restore the specific calibrated scales
                # here in the future.
                k_scale_val, v_scale_val = 1.0, 1.0

                # Processing K Scale
                for attr in k_attr_names:
                    if hasattr(module, attr):
                        param = getattr(module, attr)
                        if isinstance(param, torch.Tensor):
                            param.fill_(k_scale_val)

                # Processing V Scale
                for attr in v_attr_names:
                    if hasattr(module, attr):
                        param = getattr(module, attr)
                        if isinstance(param, torch.Tensor):
                            param.fill_(v_scale_val)

    def _get_positions(self, num_tokens: Any):
        if isinstance(num_tokens, int):
            if self.uses_mrope:
                return self.mrope_positions.gpu[:, :num_tokens]
            if self.uses_xdrope_dim > 0:
                return self.xdrope_positions.gpu[:, :num_tokens]
            return self.positions[:num_tokens]
        else:
            if self.uses_mrope:
                return self.mrope_positions.gpu[:, num_tokens]
            if self.uses_xdrope_dim > 0:
                return self.xdrope_positions.gpu[:, num_tokens]
            return self.positions[num_tokens]

    def _make_buffer(
        self, *size: int | torch.SymInt, dtype: torch.dtype, numpy: bool = True
    ) -> CpuGpuBuffer:
        return CpuGpuBuffer(
            *size,
            dtype=dtype,
            device=self.device,
            pin_memory=self.pin_memory,
            with_numpy=numpy,
        )

    @property
    def prepare_inputs_event(self) -> torch.Event | None:
        return self._input_transfer.event

    @prepare_inputs_event.setter
    def prepare_inputs_event(self, event: torch.Event | None) -> None:
        self._input_transfer.event = event

    def _can_use_sm70_staged_input_prep(
        self, scheduler_output: "SchedulerOutput"
    ) -> bool:
        if not self._input_transfer.eligible:
            return False
        return self._input_transfer.can_stage(
            num_tokens=scheduler_output.total_num_scheduled_tokens,
            num_reqs=self.input_batch.num_reqs,
            has_previous_sample=self.input_batch.prev_sampled_token_ids is not None,
            has_encoder_inputs=bool(scheduler_output.scheduled_encoder_inputs),
            has_draft_tokens=bool(scheduler_output.scheduled_spec_decode_tokens),
            has_accepted_event=self.num_accepted_tokens_event is not None,
        )

    def _copy_buffer_to_gpu(
        self, buffer: CpuGpuBuffer, n: int | None = None
    ) -> torch.Tensor:
        return self._input_transfer.copy_buffer(buffer, n)

    def _copy_position_buffer_to_gpu(
        self, buffer: CpuGpuBuffer, n: int
    ) -> torch.Tensor:
        return self._input_transfer.copy_positions(buffer, n)

    def _commit_block_table_to_gpu(self, num_reqs: int) -> None:
        self._input_transfer.commit_block_table(self.input_batch.block_table, num_reqs)

    def _get_mamba_bufs(self) -> mamba_utils.MambaBuffers:
        # Only reachable on the ``mamba_cache_mode == "align"`` path.
        # The postprocess sub-object is additionally gated on spec
        # decode + hybrid model.
        assert self.cache_config.mamba_cache_mode == "align"
        if self._mamba_bufs is None:
            self._mamba_bufs = mamba_utils.MambaBuffers.create(
                max_num_reqs=self.max_num_reqs,
                kv_cache_config=self.kv_cache_config,
                copy_funcs=self.model.get_mamba_state_copy_func(),
                make_buffer=self._make_buffer,
                device=self.device,
                with_postprocess_align=(
                    self.speculative_config is not None and self.model_config.is_hybrid
                ),
            )
        return self._mamba_bufs

    def _get_ddtree_mamba_compact_copy_bufs(self) -> mamba_utils.MambaCopyBuffers:
        copy_bufs = getattr(self, "_ddtree_mamba_compact_copy_bufs", None)
        if copy_bufs is None:
            copy_bufs = mamba_utils.MambaCopyBuffers.create(
                max_num_reqs=self.max_num_reqs,
                kv_cache_config=self.kv_cache_config,
                copy_funcs=self.model.get_mamba_state_copy_func(),
                make_buffer=self._make_buffer,
                copies_per_req=max(1, self.max_spec_state_slots),
            )
            self._ddtree_mamba_compact_copy_bufs = copy_bufs
        return copy_bufs

    def _init_model_kwargs(self):
        model_kwargs = dict[str, Any]()

        if not self.is_pooling_model:
            return model_kwargs

        num_reqs = self.input_batch.num_reqs
        pooling_params = self.input_batch.get_pooling_params()

        token_type_id_requests = dict[int, Any]()
        for i, param in enumerate(pooling_params):
            if (
                param.extra_kwargs is not None
                and (token_types := param.extra_kwargs.get("compressed_token_type_ids"))
                is not None
            ):
                token_type_id_requests[i] = token_types

        if len(token_type_id_requests) == 0:
            return model_kwargs

        # Build ids on CPU using the CPU-resident upper bound for seq_lens;
        # `torch.arange(seq_lens[i])` with a GPU scalar would force a sync.
        seq_lens_cpu = self.optimistic_seq_lens_cpu[:num_reqs].tolist()
        token_type_ids = []

        for i in range(num_reqs):
            seq_len_i = seq_lens_cpu[i]
            pos = token_type_id_requests.get(i, seq_len_i)
            ids = (torch.arange(seq_len_i) >= pos).int()
            token_type_ids.append(ids)

        token_type_ids_cpu = torch.empty(
            sum(seq_lens_cpu), dtype=torch.int32, pin_memory=self.pin_memory
        )
        torch.cat(token_type_ids, out=token_type_ids_cpu)
        model_kwargs["token_type_ids"] = token_type_ids_cpu.to(
            device=self.device, non_blocking=True
        )
        return model_kwargs

    def _may_reorder_batch(self, scheduler_output: "SchedulerOutput") -> None:
        """
        Update the order of requests in the batch based on the attention
        backend's needs. For example, some attention backends (namely MLA) may
        want to separate requests based on if the attention computation will be
        compute-bound or memory-bound.

        Args:
            scheduler_output: The scheduler output.
        """
        # Attention free models have zero kv_cache_groups, however models
        # like Mamba are also attention free but use the kv_cache for
        # keeping its internal state. This is why we check the number
        # of kv_cache groups instead of solely checking
        # for self.model_config.is_attention_free.
        if len(self.kv_cache_config.kv_cache_groups) == 0:
            return

        if self.reorder_batch_threshold is not None:
            reorder_batch_to_split_decodes_and_prefills(
                self.input_batch,
                scheduler_output,
                decode_threshold=self.reorder_batch_threshold,
            )

    def _init_kv_zero_meta(self) -> None:
        """One-time precomputation for _zero_block_ids.

        Delegates to KVBlockZeroer.init_meta with the runner's state.
        Called from gpu_worker.py outside the CuMem pool context.
        """
        self._kv_block_zeroer = KVBlockZeroer(self.device, self.pin_memory)
        self._kv_block_zeroer.init_meta(
            attn_groups_iter=self._kv_cache_spec_attn_group_iterator(),
            kernel_block_sizes=self._kernel_block_sizes,
            cache_dtype=self.cache_config.cache_dtype,
            runner_only_attn_layers=self.runner_only_attn_layers,
            static_forward_context=(self.compilation_config.static_forward_context),
            host_backed_layers={
                name
                for tensor in self.kv_cache_config.kv_cache_tensors
                if tensor.host_backed
                for name in tensor.shared_by
            },
        )

    def _zero_block_ids(self, block_ids: list[int]) -> None:
        """Zero the KV cache memory for the given block IDs."""
        if hasattr(self, "_kv_block_zeroer"):
            self._kv_block_zeroer.zero_block_ids(block_ids)

    def _warmup_sm70_aux_kernels(self) -> None:
        """Compatibility hook; resources stay with the runner, order with the plan."""
        if not self._auxiliary_warmup_enabled:
            return
        tasks = []
        if hasattr(self, "_kv_block_zeroer"):
            tasks.append(
                warmup_boolean("zero_kv_blocks", self._kv_block_zeroer.warmup_kernel)
            )
        if hasattr(self, "input_batch") and self.input_batch.block_table is not None:
            tasks.append(
                warmup_unconditional(
                    "compute_slot_mapping",
                    self.input_batch.block_table.warmup_slot_mapping_kernel,
                )
            )
        if self.cache_config.mamba_cache_mode == "align":
            tasks.append(
                warmup_boolean(
                    "mamba_batch_memcpy",
                    lambda: mamba_utils.warmup_batch_memcpy_kernel(self.device),
                )
            )

        def prepare_and_warm_postprocess():
            mamba_bufs = self._get_mamba_bufs()
            postprocess_ctx = mamba_bufs.postprocess_align
            assert postprocess_ctx is not None
            if not postprocess_ctx.is_initialized:
                postprocess_ctx.initialize_from_forward_context(
                    self.kv_cache_config,
                    self.compilation_config.static_forward_context,
                    self.model.get_mamba_state_copy_func(),
                    [
                        self.input_batch.block_table[group_id].get_device_tensor(1)
                        for group_id in postprocess_ctx.mamba_group_ids
                    ],
                )
            return postprocess_ctx.warmup_fused_postprocess(
                expanded=self.vllm_config.kernel_config.sm70_runtime.mtp_concurrency_warmup
            )

        if (
            self.cache_config.mamba_cache_mode == "align"
            and self.speculative_config is not None
            and self.model_config.is_hybrid
        ):
            tasks.append(
                warmup_boolean("mamba_spec_postprocess", prepare_and_warm_postprocess)
            )
        tasks.extend(proposer_warmup_tasks(getattr(self, "drafter", None)))
        spec_config = self.speculative_config
        if (
            spec_config is not None
            and spec_config.use_dflash_ddtree()
            and os.getenv("VLLM_DFLASH_DDTREE_GPU_SAMPLER", "1") != "0"
        ):
            tasks.append(
                warmup_boolean(
                    "ddtree_top_token_sampler",
                    lambda: warmup_ddtree_single_top_token_sampler(
                        device=self.device, max_rows=self.max_spec_state_slots
                    ),
                )
            )
        tasks.append(model_convolution_warmup_task(self.model))
        warmed = run_warmup_tasks(tasks)
        if warmed:
            logger.info_once("SM70 auxiliary kernel warmup finished: %s", warmed)

    # Note: used for model runner override.
    def _init_device_properties(self) -> None:
        """Initialize attributes from torch.cuda.get_device_properties"""

        self.num_sms = num_compute_units(self.device.index)

    # Note: used for model runner override.
    def _sync_device(self) -> None:
        torch.accelerator.synchronize()

    def _get_or_create_async_output_copy_stream(self) -> torch.cuda.Stream:
        stream = self.async_output_copy_stream
        if stream is None:
            stream = torch.cuda.Stream()
            self.async_output_copy_stream = stream
        return stream

    def _pp_prepend_accepted_drafts(
        self,
        req_id: str,
        req_state: CachedRequestState,
        req_index: int | None,
        num_computed_tokens: int,
        sent_token_ids: list[int],
        all_token_ids: dict[str, list[int]],
    ) -> list[int]:
        """Non-last PP rank, non-async scheduling: rebuild the tokens sampled
        since this rank's last update.

        The scheduler sends only the tokens at ``num_computed_tokens`` onward
        (the bonus token after a spec-decode step). The accepted drafts before
        it, positions ``[req_state.num_tokens, num_computed_tokens)``, are the
        previous step's scheduled drafts. Without them ``output_token_ids``
        skips the drafts and ``token_ids_cpu`` gets the bonus token broadcast
        over every accepted position, which corrupts the token history this
        rank feeds the model.
        """
        num_accepted = num_computed_tokens - req_state.num_tokens
        if num_accepted <= 0:
            return sent_token_ids
        full = all_token_ids.get(req_id)
        if full is not None and len(full) >= num_computed_tokens:
            return list(full[req_state.num_tokens : num_computed_tokens]) + list(
                sent_token_ids
            )
        prev_spec = (
            self.input_batch.spec_token_ids[req_index] if req_index is not None else []
        )
        if num_accepted <= len(prev_spec):
            return list(prev_spec[:num_accepted]) + list(sent_token_ids)
        logger.warning_once(
            "PP spec decode: %d accepted draft token(s) of request %s are not "
            "available on this pipeline rank (%d held); its token history on "
            "this rank will be wrong.",
            num_accepted,
            req_id,
            len(prev_spec),
        )
        return sent_token_ids

    def _update_states(self, scheduler_output: "SchedulerOutput") -> Callable | None:
        """Update the cached states and the persistent batch with the scheduler
        output.

        The updated states are used by the `_prepare_inputs` function to create
        the input GPU tensors for the model.

        The SamplingMetadata is updated and copied to the GPU if there is a
        new/resumed/paused/finished request in the batch.
        """
        self._dynamic_draft_vocab_prefill_bootstrap.clear_finished_requests(
            scheduler_output.finished_req_ids
        )
        # Remove finished requests from the cached states.
        for req_id in scheduler_output.finished_req_ids:
            self.requests.pop(req_id, None)
            self.num_prompt_logprobs.pop(req_id, None)
        self.late_interaction_runner.on_requests_finished(
            scheduler_output.finished_req_ids
        )
        # Remove the finished requests from the persistent batch.
        # NOTE(woosuk): There could be an edge case where finished_req_ids and
        # scheduled_req_ids overlap. This happens when a request is aborted and
        # then resubmitted with the same ID. In this case, we treat them as two
        # distinct requests - clearing the cached states for the first request
        # and handling the second as a new request.
        for req_id in scheduler_output.finished_req_ids:
            self.input_batch.remove_request(req_id)

        # Zero GPU memory for freshly allocated cache blocks to prevent
        # stale NaN/data from corrupting attention or SSM computation.
        if scheduler_output.new_block_ids_to_zero:
            self._zero_block_ids(scheduler_output.new_block_ids_to_zero)
        if scheduler_output.kv_block_copies:
            self._kv_block_zeroer.copy_block_ids(scheduler_output.kv_block_copies)

        # Free the cached encoder outputs.
        for mm_hash in scheduler_output.free_encoder_mm_hashes:
            self.encoder_cache.pop(mm_hash, None)

        # Remove the unscheduled requests from the persistent batch.
        # NOTE(woosuk): The unscheduled requests are either preempted requests
        # or running requests that are not scheduled in this step. We remove
        # them from the persistent batch but keep their cached states since
        # they will be scheduled again sometime in the future.
        scheduled_req_ids = scheduler_output.num_scheduled_tokens.keys()
        cached_req_ids = self.input_batch.req_id_to_index.keys()
        resumed_req_ids = scheduler_output.scheduled_cached_reqs.resumed_req_ids
        # NOTE(zhuohan): cached_req_ids and resumed_req_ids are usually disjoint,
        # so `(scheduled_req_ids - resumed_req_ids) == scheduled_req_ids` holds
        # apart from the forced-preemption case in reset_prefix_cache. And in
        # that case we include the resumed_req_ids in the unscheduled set so
        # that they get cleared from the persistent batch before being re-scheduled
        # in the normal resumed request path.
        unscheduled_req_ids = cached_req_ids - (scheduled_req_ids - resumed_req_ids)
        # NOTE(woosuk): The persistent batch optimization assumes that
        # consecutive batches contain mostly the same requests. If batches
        # have low request overlap (e.g., alternating between two distinct
        # sets of requests), this optimization becomes very inefficient.
        for req_id in unscheduled_req_ids:
            self.input_batch.remove_request(req_id)

        is_ngram_gpu = (
            self.speculative_config is not None
            and self.speculative_config.use_ngram_gpu()
        )
        if is_ngram_gpu:
            ngram_gpu_new_reqs: list[CachedRequestState] = []

        reqs_to_add: list[CachedRequestState] = []
        deferred_spec_decode_corrections = []

        # Add new requests to the cached states.
        for new_req_data in scheduler_output.scheduled_new_reqs:
            req_id = new_req_data.req_id
            if req_id in self.requests:
                # For streaming case only.
                req_state = self._update_streaming_request(req_id, new_req_data)
                reqs_to_add.append(req_state)
                continue

            sampling_params = new_req_data.sampling_params
            pooling_params = new_req_data.pooling_params

            if (
                sampling_params
                and sampling_params.sampling_type == SamplingType.RANDOM_SEED
            ):
                generator = torch.Generator(device=self.device)
                generator.manual_seed(sampling_params.seed)
            else:
                generator = None

            if self.is_pooling_model:
                assert pooling_params is not None
                task = pooling_params.task
                assert task is not None, "You did not set `task` in the API"

                model = cast(VllmModelForPooling, self.get_model())
                to_update = model.pooler.get_pooling_updates(task)
                to_update.apply(pooling_params)

            req_state = CachedRequestState(
                req_id=req_id,
                prompt_token_ids=new_req_data.prompt_token_ids,
                prompt_embeds=new_req_data.prompt_embeds,
                prompt_is_token_ids=new_req_data.prompt_is_token_ids,
                mm_features=new_req_data.mm_features,
                sampling_params=sampling_params,
                pooling_params=pooling_params,
                generator=generator,
                block_ids=new_req_data.block_ids,
                num_computed_tokens=new_req_data.num_computed_tokens,
                output_token_ids=[],
                lora_request=new_req_data.lora_request,
            )
            self.requests[req_id] = req_state
            self.late_interaction_runner.register_request(req_id, pooling_params)
            if new_req_data.num_computed_tokens > 0:
                restore = getattr(self.get_model(), "restore_prefix", None)
                if restore is not None:
                    restore(
                        new_req_data.num_computed_tokens, new_req_data.prompt_token_ids
                    )

            if sampling_params and sampling_params.prompt_logprobs is not None:
                self.num_prompt_logprobs[req_id] = (
                    self.input_batch.vocab_size
                    if sampling_params.prompt_logprobs == -1
                    else sampling_params.prompt_logprobs
                )

            # Only relevant for models using M-RoPE (e.g, Qwen2-VL)
            if self.uses_mrope:
                self._init_mrope_positions(req_state)

            # Only relevant for models using XD-RoPE (e.g, HunYuan-VL)
            if self.uses_xdrope_dim > 0:
                self._init_xdrope_positions(req_state)

            reqs_to_add.append(req_state)
            # Track new requests for ngram_gpu full tensor copy
            if is_ngram_gpu:
                ngram_gpu_new_reqs.append(req_state)

        # Update the states of the running/resumed requests.
        is_last_rank = get_pp_group().is_last_rank
        req_data = scheduler_output.scheduled_cached_reqs
        scheduled_spec_tokens = scheduler_output.scheduled_spec_decode_tokens

        # Save scheduler-allocated spec lengths before trimming so
        # prev_num_draft_len keeps the optimistic count for rejection correction.
        original_num_spec_per_req: dict[str, int] = {}
        if (
            self.speculative_config is not None
            and self.speculative_config.use_ngram_gpu()
        ):
            for req_id, toks in scheduled_spec_tokens.items():
                original_num_spec_per_req[req_id] = len(toks)
            update_scheduler_for_invalid_drafts(
                self._num_valid_draft_tokens_event,
                self._num_valid_draft_tokens_cpu,
                scheduler_output,
                self.input_batch.req_id_to_index,
            )
        if self.use_async_spec_decode:
            self.prev_num_draft_tokens.np.fill(0)
        sync_valid_sampled_token_count: list[int] | None = None
        if self.sync_spec_decode_accept_counts:
            sync_valid_sampled_token_count = self._get_valid_sampled_token_count()

        for i, req_id in enumerate(req_data.req_ids):
            req_state = self.requests[req_id]
            num_computed_tokens = req_data.num_computed_tokens[i]
            new_block_ids = req_data.new_block_ids[i]
            resumed_from_preemption = req_id in req_data.resumed_req_ids
            num_output_tokens = req_data.num_output_tokens[i]
            req_index = self.input_batch.req_id_to_index.get(req_id)

            if req_state.prev_num_draft_len and self.use_async_scheduling:
                # prev_num_draft_len is used in async scheduling mode with
                # spec decode. it indicates if need to update num_computed_tokens
                # of the request. for example:
                # first step: num_computed_tokens = 0, spec_tokens = [],
                # prev_num_draft_len = 0.
                # second step: num_computed_tokens = 100(prompt length),
                # spec_tokens = [a,b], prev_num_draft_len = 0.
                # third step: num_computed_tokens = 100 + 2, spec_tokens = [c,d],
                # prev_num_draft_len = 2.
                # num_computed_tokens in first step and second step doesn't contain
                # the spec tokens length, but in third step it contains the
                # spec tokens length. we only need to update num_computed_tokens
                # when prev_num_draft_len > 0.
                if req_index is None:
                    req_state.prev_num_draft_len = 0
                elif self.sync_spec_decode_accept_counts:
                    assert self.input_batch.prev_req_id_to_index is not None
                    assert sync_valid_sampled_token_count is not None
                    prev_req_index = self.input_batch.prev_req_id_to_index[req_id]
                    num_accepted = sync_valid_sampled_token_count[prev_req_index] - 1
                    num_rejected = req_state.prev_num_draft_len - num_accepted
                    num_computed_tokens -= num_rejected
                    req_state.output_token_ids.extend([-1] * num_accepted)
                else:
                    # Optimistically assume all accepted; queue up a correction
                    # to be called after the model forward to preserve async
                    # scheduling. Corrected on GPU in _prepare_inputs.
                    optimistic_num_accepted = req_state.prev_num_draft_len
                    req_state.output_token_ids.extend([-1] * optimistic_num_accepted)

                    deferred_spec_decode_corrections.append(
                        (req_id, optimistic_num_accepted, req_state)
                    )

                    async_prev_req_index = (
                        self.input_batch.prev_req_id_to_index.get(req_id)
                        if self.input_batch.prev_req_id_to_index
                        else None
                    )
                    if async_prev_req_index is not None:
                        self.prev_num_draft_tokens.np[async_prev_req_index] = (
                            optimistic_num_accepted
                        )

                    if is_ngram_gpu and optimistic_num_accepted > 0:
                        self.input_batch.num_tokens_no_spec[req_index] += (
                            optimistic_num_accepted
                        )

            # Update the cached states.
            req_state.num_computed_tokens = num_computed_tokens

            if not is_last_rank:
                if not req_data.new_token_ids:
                    # Async scheduled PP: Sampled tokens propagated via GPU broadcast.
                    new_token_ids: list[int] = []
                    num_sent_tokens = 0
                else:
                    # Non-async scheduling with PP: The scheduler sends
                    # sampled token ids back because there's no direct communication
                    # between the first-stage worker and the last-stage worker.
                    new_token_ids = req_data.new_token_ids[i]
                    num_sent_tokens = len(new_token_ids)
                    new_token_ids = self._pp_prepend_accepted_drafts(
                        req_id,
                        req_state,
                        req_index,
                        num_computed_tokens,
                        new_token_ids,
                        req_data.all_token_ids,
                    )
                    # Add the sampled token(s) from the previous step (if any).
                    # This doesn't include "unverified" tokens like spec tokens.
                    num_new_tokens = (
                        num_computed_tokens + num_sent_tokens - req_state.num_tokens
                    )
                    if num_new_tokens == 1:
                        # Avoid slicing list in most common case.
                        req_state.output_token_ids.append(new_token_ids[-1])
                    elif num_new_tokens > 0:
                        req_state.output_token_ids.extend(
                            new_token_ids[-num_new_tokens:]
                        )
            if num_output_tokens < len(req_state.output_token_ids):
                # Some output tokens were discarded due to a sync-KV-load
                # failure, or output_token_ids was inflated by the optimistic
                # extend above (async spec decode). Align the cached state.
                # This runs on every pipeline rank: the optimistic extend is
                # not gated on the rank either, and the deferred correction
                # only fixes the token counts, never the placeholders.
                del req_state.output_token_ids[num_output_tokens:]
                if req_index is not None:
                    end_idx = (
                        self.input_batch.num_prompt_tokens[req_index]
                        + num_output_tokens
                    )
                    self.input_batch.num_tokens_no_spec[req_index] = end_idx

            # Update the block IDs.
            if not resumed_from_preemption:
                if new_block_ids is not None:
                    # Append the new blocks to the existing block IDs.
                    for block_ids, new_ids in zip(req_state.block_ids, new_block_ids):
                        block_ids.extend(new_ids)
            else:
                assert req_index is None
                assert new_block_ids is not None
                # The request is resumed from preemption.
                # Replace the existing block IDs with the new ones.
                req_state.block_ids = new_block_ids

            if req_index is None:
                # The request is not in the persistent batch.
                # The request was either preempted and resumed later, or was not
                # scheduled in the previous step and needs to be added again.

                if self.use_async_scheduling and num_output_tokens > 0:
                    # We must recover the output token ids for resumed requests in the
                    # async scheduling case, so that correct input_ids are obtained.
                    resumed_token_ids = req_data.all_token_ids[req_id]
                    req_state.output_token_ids = resumed_token_ids[-num_output_tokens:]

                reqs_to_add.append(req_state)
                # Track resumed requests for ngram_gpu full tensor copy
                if is_ngram_gpu:
                    ngram_gpu_new_reqs.append(req_state)
                continue

            # Update the persistent batch.
            self.input_batch.num_computed_tokens_cpu[req_index] = num_computed_tokens
            if new_block_ids is not None:
                self.input_batch.block_table.append_row(new_block_ids, req_index)

            # For the last rank, we don't need to update the token_ids_cpu
            # because the sampled tokens are already cached.
            if not is_last_rank:
                start_token_index = self.input_batch.num_tokens_no_spec[req_index]
                # For chunked prefill, num_computed_tokens may less
                # than num_tokens_no_spec.
                # Async scheduled PP: no new_token_ids, advance num_tokens_no_spec
                # according to num_computed_tokens.
                end_token_index = max(
                    start_token_index,
                    num_computed_tokens + num_sent_tokens,
                )
                if end_token_index > start_token_index:
                    if new_token_ids:
                        # Add new_token_ids to token_ids_cpu.
                        num_new_tokens = end_token_index - start_token_index
                        tokens_to_append = new_token_ids[-num_new_tokens:]
                        self.input_batch.token_ids_cpu[
                            req_index, start_token_index:end_token_index
                        ] = tokens_to_append
                    self.input_batch.is_token_ids[
                        req_index, start_token_index:end_token_index
                    ] = True
                    self.input_batch.num_tokens_no_spec[req_index] = end_token_index

            # Add spec_token_ids to token_ids_cpu.
            self.input_batch.update_req_spec_token_ids(req_state, scheduled_spec_tokens)
            # Restore scheduler-side draft count after ngram trimming.
            if original_num_spec_per_req:
                orig = original_num_spec_per_req.get(req_id, 0)
                if orig != req_state.prev_num_draft_len:
                    req_state.prev_num_draft_len = orig

        # Add the new or resumed requests to the persistent batch.
        # The smaller empty indices are filled first.
        for request in reqs_to_add:
            self.input_batch.add_request(request)
            self.input_batch.update_req_spec_token_ids(request, scheduled_spec_tokens)

        # Condense the batched states if there are gaps left by removed requests
        self.input_batch.condense()
        # Allow attention backend to reorder the batch, potentially
        self._may_reorder_batch(scheduler_output)
        # Refresh batch metadata with any pending updates.
        self.input_batch.refresh_metadata()

        # Incrementally update ngram_gpu tensors after batch is stable
        if is_ngram_gpu:
            update_ngram_gpu_tensors_incremental(
                self.input_batch,
                self.token_ids_gpu_tensor,
                self.num_tokens_no_spec_gpu,
                ngram_gpu_new_reqs,
                self.device,
                _pinned_idx_buf=self._ngram_pinned_idx_buf,
                _pinned_val_buf=self._ngram_pinned_val_buf,
            )

        if deferred_spec_decode_corrections:

            def correct_spec_decode_token_counts():
                valid_sampled_token_count = self._get_valid_sampled_token_count()
                if not valid_sampled_token_count:
                    return
                prev_req_id_to_index = self.input_batch.prev_req_id_to_index
                if not prev_req_id_to_index:
                    return
                for (
                    req_id,
                    optimistic_num_accepted,
                    req_state,
                ) in deferred_spec_decode_corrections:
                    prev_req_index = prev_req_id_to_index.get(req_id)
                    if prev_req_index is None:
                        continue
                    num_accepted = valid_sampled_token_count[prev_req_index] - 1
                    correction = optimistic_num_accepted - num_accepted
                    req_state.num_computed_tokens -= correction
                    cur_req_index = self.input_batch.req_id_to_index.get(req_id)
                    if cur_req_index is None:
                        continue
                    self.input_batch.num_computed_tokens_cpu[cur_req_index] -= (
                        correction
                    )
                    if is_ngram_gpu and correction > 0:
                        self.input_batch.num_tokens_no_spec[cur_req_index] -= correction
                        self.num_tokens_no_spec_gpu[cur_req_index] -= correction

            return correct_spec_decode_token_counts
        else:
            return None

    def _update_states_after_model_execute(
        self,
        output_token_ids: torch.Tensor,
        scheduler_output: "SchedulerOutput",
        ddtree_accepted_node_indices: torch.Tensor | None = None,
        ddtree_mamba_state_compacted: bool = False,
    ) -> None:
        """Update the cached states after model execution.

        This is used for MTP/EAGLE for hybrid models, as in linear attention,
        only the last token's state is kept. In MTP/EAGLE, for draft tokens
        the state are kept util we decide how many tokens are accepted for
        each sequence, and a shifting is done during the next iteration
        based on the number of accepted tokens.
        """
        commit_state = getattr(
            getattr(self, "model", None), "commit_speculative_state", None
        )
        if commit_state is not None:
            # V4.1 keeps bounded Engram/C2 candidates rather than Mamba blocks.
            # Reuse the same contiguous accepted-count convention. The model
            # selects its full input length for a prefill chunk, including
            # chunks whose sampler output is intentionally discarded.
            batch = getattr(self, "input_batch", None)
            if batch is not None:
                budget = None
                get_budget = getattr(self.model, "stateful_output_budget", None)
                if get_budget is not None:
                    if output_token_ids.shape[0] != 1:
                        raise ValueError("Private V4.1 state requires one request")
                    request = self.requests[batch.req_ids[0]]
                    params = request.sampling_params
                    if params is not None and params.max_tokens is not None:
                        budget = get_budget(
                            params.max_tokens, request.num_prompt_tokens
                        )
                _clip_stateful_sample_limits(
                    output_token_ids, batch.req_ids, self.requests, budget
                )
            commit_state(_count_contiguous_spec_tokens(output_token_ids))
        if not self.speculative_config or not self.model_config.is_hybrid:
            return

        profile_enabled = _dflash_ddtree_worker_profile_enabled()
        profile_t0 = time.perf_counter() if profile_enabled else 0.0
        profile_count_ms = 0.0
        profile_selector_ms = 0.0
        profile_assign_ms = 0.0
        profile_get_mamba_bufs_ms = 0.0
        profile_mamba_stage_ms = 0.0
        profile_mamba_postprocess_ms = 0.0
        profile_event_ms = 0.0
        profile_sidecar_cpu = False

        # Count only the contiguous accepted prefix. Values after the first -1
        # are rejected/padding slots and may contain stale token ids.
        num_reqs = output_token_ids.size(0)
        self._mamba_accepted_token_state_rows = {
            req_id: (i, self.requests[req_id])
            for i, req_id in enumerate(self.input_batch.req_ids[:num_reqs])
        }
        profile_count_t0 = time.perf_counter() if profile_enabled else 0.0
        sidecar_values = None
        if (
            ddtree_accepted_node_indices is not None
            and scheduler_output.scheduled_ddtree_payloads
        ):
            sidecar_values = self._ddtree_state_update_cpu_sidecar(
                num_reqs=num_reqs,
                ddtree_mamba_state_compacted=ddtree_mamba_state_compacted,
                stage_gpu=(
                    self.cache_config.mamba_cache_mode == "align"
                    and not envs.VLLM_MAMBA_ALIGN_CPU_POSTPROCESS
                ),
            )
        if sidecar_values is not None:
            num_accepted_tokens_cpu, spec_state_slot_selectors_cpu = sidecar_values
            num_accepted_tokens = self.num_accepted_tokens.gpu[:num_reqs]
            spec_state_slot_selectors = self.spec_state_slot_selectors.gpu[:num_reqs]
            profile_sidecar_cpu = True
        else:
            num_accepted_tokens = _count_contiguous_spec_tokens(output_token_ids)
            spec_state_slot_selectors = num_accepted_tokens
            num_accepted_tokens_cpu = None
            spec_state_slot_selectors_cpu = None
        if profile_enabled:
            profile_count_ms = (time.perf_counter() - profile_count_t0) * 1000.0
        if (
            ddtree_accepted_node_indices is not None
            and scheduler_output.scheduled_ddtree_payloads
            and not profile_sidecar_cpu
        ):
            profile_selector_t0 = time.perf_counter() if profile_enabled else 0.0
            if not ddtree_mamba_state_compacted:
                spec_state_slot_selectors = (
                    self._ddtree_state_slot_selectors_from_accepted_nodes(
                        ddtree_accepted_node_indices,
                        flat_selectors=num_accepted_tokens,
                    )
                )
            if profile_enabled:
                profile_selector_ms = (
                    time.perf_counter() - profile_selector_t0
                ) * 1000.0
            debug_enabled = _dflash_ddtree_debug_enabled()
            trace_enabled = _dflash_ddtree_trace_enabled()
            if debug_enabled or trace_enabled:
                num_accepted_tokens_list = num_accepted_tokens.detach().cpu().tolist()
                spec_state_slot_selectors_list = (
                    spec_state_slot_selectors.detach().cpu().tolist()
                )
                accepted_node_indices_list = (
                    ddtree_accepted_node_indices.detach().cpu().tolist()
                )
                if debug_enabled:
                    _dflash_ddtree_debug_log(
                        "hybrid state selectors num_accepted=%s selectors=%s "
                        "accepted_nodes=%s mamba_state_compacted=%s",
                        num_accepted_tokens_list,
                        spec_state_slot_selectors_list,
                        accepted_node_indices_list,
                        ddtree_mamba_state_compacted,
                    )
                if trace_enabled:
                    _dflash_ddtree_trace_event(
                        "runner_state_selectors",
                        {
                            "num_accepted_tokens": num_accepted_tokens_list,
                            "spec_state_slot_selectors": (
                                spec_state_slot_selectors_list
                            ),
                            "accepted_node_indices": accepted_node_indices_list,
                            "output_token_ids": (
                                output_token_ids.detach().cpu().tolist()
                            ),
                            "mamba_state_compacted": ddtree_mamba_state_compacted,
                        },
                    )
        profile_assign_t0 = time.perf_counter() if profile_enabled else 0.0
        if not profile_sidecar_cpu:
            self.num_accepted_tokens.gpu[:num_reqs] = num_accepted_tokens
            self.spec_state_slot_selectors.gpu[:num_reqs] = spec_state_slot_selectors
        if profile_enabled:
            profile_assign_ms = (time.perf_counter() - profile_assign_t0) * 1000.0

        if self.cache_config.mamba_cache_mode == "align":
            # Fused GPU postprocess: stage this step's metadata immediately
            # before the kernel. In async scheduling, staging these single
            # buffers in _prepare_inputs lets the next step overwrite them
            # before the previous postprocess kernel consumes them.
            profile_get_mamba_bufs_t0 = time.perf_counter() if profile_enabled else 0.0
            mamba_bufs = self._get_mamba_bufs()
            if profile_enabled:
                profile_get_mamba_bufs_ms = (
                    time.perf_counter() - profile_get_mamba_bufs_t0
                ) * 1000.0
            if envs.VLLM_MAMBA_ALIGN_CPU_POSTPROCESS:
                if num_accepted_tokens_cpu is not None:
                    self.input_batch.num_accepted_tokens_cpu_tensor[:num_reqs].copy_(
                        num_accepted_tokens_cpu
                    )
                    self.input_batch.spec_num_accepted_tokens_cpu_tensor[
                        :num_reqs
                    ].copy_(spec_state_slot_selectors_cpu)
                else:
                    self.input_batch.num_accepted_tokens_cpu_tensor[:num_reqs].copy_(
                        self.num_accepted_tokens.gpu[:num_reqs]
                    )
                    self.input_batch.spec_num_accepted_tokens_cpu_tensor[
                        :num_reqs
                    ].copy_(self.spec_state_slot_selectors.gpu[:num_reqs])
                mamba_utils.postprocess_mamba(
                    scheduler_output,
                    self.kv_cache_config,
                    self.input_batch,
                    self.requests,
                    self.mamba_state_idx,
                    self.compilation_config.static_forward_context,
                    self.model.get_mamba_state_copy_func(),
                    mamba_bufs.preprocess,
                    ddtree_accepted_node_indices=(
                        ddtree_accepted_node_indices
                        if scheduler_output.scheduled_ddtree_payloads
                        and not ddtree_mamba_state_compacted
                        else None
                    ),
                )
                # CPU postprocess updates InputBatch in place. Mirror its final
                # values into the runner-owned snapshot used by the next step.
                self.num_accepted_tokens.cpu[:num_reqs].copy_(
                    self.input_batch.num_accepted_tokens_cpu_tensor[:num_reqs]
                )
                self.spec_state_slot_selectors.cpu[:num_reqs].copy_(
                    self.input_batch.spec_num_accepted_tokens_cpu_tensor[:num_reqs]
                )
            else:
                profile_mamba_stage_t0 = time.perf_counter() if profile_enabled else 0.0
                assert mamba_bufs.postprocess_align is not None
                mamba_utils.stage_postprocess_inputs_to_gpu(
                    mamba_bufs.postprocess_align,
                    scheduler_output,
                    self.input_batch.req_ids,
                    num_reqs,
                    self.requests,
                    self.mamba_state_idx,
                )
                if profile_enabled:
                    profile_mamba_stage_ms = (
                        time.perf_counter() - profile_mamba_stage_t0
                    ) * 1000.0
                profile_mamba_postprocess_t0 = (
                    time.perf_counter() if profile_enabled else 0.0
                )
                mamba_utils.postprocess_mamba_align_gpu(
                    bufs=mamba_bufs,
                    num_reqs=num_reqs,
                    num_accepted_tokens_gpu=self.num_accepted_tokens.gpu,
                    spec_state_slot_selectors_gpu=(self.spec_state_slot_selectors.gpu),
                    num_accepted_tokens_cpu_tensor=self.num_accepted_tokens.cpu,
                    spec_num_accepted_tokens_cpu_tensor=(
                        self.spec_state_slot_selectors.cpu
                    ),
                    input_batch=self.input_batch,
                    kv_cache_config=self.kv_cache_config,
                    forward_context=self.compilation_config.static_forward_context,
                    mamba_state_copy_funcs=self.model.get_mamba_state_copy_func(),
                    ddtree_accepted_node_indices=(
                        ddtree_accepted_node_indices
                        if scheduler_output.scheduled_ddtree_payloads
                        and not ddtree_mamba_state_compacted
                        else None
                    ),
                )
                if profile_enabled:
                    profile_mamba_postprocess_ms = (
                        time.perf_counter() - profile_mamba_postprocess_t0
                    ) * 1000.0

            assert self.num_accepted_tokens_event is not None
            profile_event_t0 = time.perf_counter() if profile_enabled else 0.0
            self.num_accepted_tokens_event.record()
            if profile_enabled:
                profile_event_ms = (time.perf_counter() - profile_event_t0) * 1000.0
        else:
            profile_mamba_stage_t0 = time.perf_counter() if profile_enabled else 0.0
            if num_accepted_tokens_cpu is not None:
                self.input_batch.num_accepted_tokens_cpu_tensor[:num_reqs].copy_(
                    num_accepted_tokens_cpu
                )
                self.input_batch.spec_num_accepted_tokens_cpu_tensor[:num_reqs].copy_(
                    spec_state_slot_selectors_cpu
                )
            else:
                self.num_accepted_tokens.cpu[:num_reqs].copy_(
                    self.num_accepted_tokens.gpu[:num_reqs], non_blocking=True
                )
                self.spec_state_slot_selectors.cpu[:num_reqs].copy_(
                    self.spec_state_slot_selectors.gpu[:num_reqs],
                    non_blocking=True,
                )
            if profile_enabled:
                profile_mamba_stage_ms = (
                    time.perf_counter() - profile_mamba_stage_t0
                ) * 1000.0
            assert self.num_accepted_tokens_event is not None
            profile_event_t0 = time.perf_counter() if profile_enabled else 0.0
            self.num_accepted_tokens_event.record()
            if profile_enabled:
                profile_event_ms = (time.perf_counter() - profile_event_t0) * 1000.0

            if self.cache_config.mamba_cache_mode == "all":
                profile_mamba_postprocess_t0 = (
                    time.perf_counter() if profile_enabled else 0.0
                )
                mamba_utils.postprocess_mamba_all(
                    scheduler_output,
                    self.kv_cache_config,
                    self.input_batch,
                    self.requests,
                    self.mamba_state_idx,
                    self.num_spec_tokens,
                    num_reqs,
                )
                if profile_enabled:
                    profile_mamba_postprocess_ms = (
                        time.perf_counter() - profile_mamba_postprocess_t0
                    ) * 1000.0

        if profile_enabled:
            logger.info(
                "DFLASH_DDTREE_WORKER_PROFILE update_states_inner_split "
                "total_ms=%.3f count_ms=%.3f selector_ms=%.3f "
                "assign_ms=%.3f get_mamba_bufs_ms=%.3f mamba_stage_ms=%.3f "
                "mamba_postprocess_ms=%.3f event_ms=%.3f sidecar_cpu=%d",
                (time.perf_counter() - profile_t0) * 1000.0,
                profile_count_ms,
                profile_selector_ms,
                profile_assign_ms,
                profile_get_mamba_bufs_ms,
                profile_mamba_stage_ms,
                profile_mamba_postprocess_ms,
                profile_event_ms,
                int(profile_sidecar_cpu),
            )

    @staticmethod
    def _ddtree_clamped_accepted_node_indices(
        accepted_node_indices: torch.Tensor,
        valid_sampled_token_counts: torch.Tensor,
    ) -> torch.Tensor:
        """Clamp accepted DDTree nodes to match clamped sampled tokens.

        ``sampled_token_ids`` follows the spec decode convention of
        ``accepted tokens + one target token``. Therefore a row with ``N``
        sampled tokens can keep at most ``N`` accepted-node entries: root plus
        ``N - 1`` accepted draft nodes. The final sampled token is treated as
        the target token for the boundary step.
        """
        if accepted_node_indices.ndim != 2:
            raise ValueError("accepted_node_indices must have shape [reqs, accepted]")
        if accepted_node_indices.shape[0] != valid_sampled_token_counts.shape[0]:
            raise ValueError(
                "accepted_node_indices and sampled token counts have "
                "different batch sizes"
            )
        keep_offsets = torch.arange(
            accepted_node_indices.shape[1],
            device=accepted_node_indices.device,
            dtype=valid_sampled_token_counts.dtype,
        )
        keep_mask = keep_offsets.unsqueeze(0) < valid_sampled_token_counts.unsqueeze(1)
        return torch.where(
            keep_mask,
            accepted_node_indices,
            torch.full_like(accepted_node_indices, -1),
        )

    def _clamp_ddtree_sampler_output_to_request_limits(
        self,
        sampler_output: SamplerOutput,
    ) -> SamplerOutput:
        accepted_node_indices = sampler_output.ddtree_accepted_node_indices
        if accepted_node_indices is None:
            return sampler_output

        sampled_token_ids = sampler_output.sampled_token_ids
        if sampled_token_ids.ndim != 2 or sampled_token_ids.shape[0] == 0:
            return sampler_output

        max_generated_tokens: list[int] = []
        for req_id in self.input_batch.req_ids[: sampled_token_ids.shape[0]]:
            req_state = self.requests.get(req_id)
            sampling_params = None if req_state is None else req_state.sampling_params
            max_tokens = None if sampling_params is None else sampling_params.max_tokens
            if req_state is None or max_tokens is None:
                max_generated_tokens.append(sampled_token_ids.shape[1])
                continue
            max_generated_tokens.append(
                max(0, max_tokens - len(req_state.output_token_ids))
            )

        sampled_counts_sidecar = getattr(
            self, "_ddtree_sampled_token_counts_cpu_sidecar", None
        )
        if (
            sampled_counts_sidecar is not None
            and len(sampled_counts_sidecar) == sampled_token_ids.shape[0]
            and all(
                int(count) <= int(limit)
                for count, limit in zip(
                    sampled_counts_sidecar, max_generated_tokens, strict=True
                )
            )
        ):
            return sampler_output

        max_generated = torch.tensor(
            max_generated_tokens,
            dtype=torch.int32,
            device=sampled_token_ids.device,
        ).clamp(max=sampled_token_ids.shape[1])
        valid_sampled_token_counts = _count_contiguous_spec_tokens(sampled_token_ids)
        clamped_counts = torch.minimum(valid_sampled_token_counts, max_generated)
        if torch.equal(clamped_counts, valid_sampled_token_counts):
            return sampler_output

        offsets = torch.arange(
            sampled_token_ids.shape[1],
            device=sampled_token_ids.device,
            dtype=clamped_counts.dtype,
        )
        keep_mask = offsets.unsqueeze(0) < clamped_counts.unsqueeze(1)
        clamped_sampled_token_ids = torch.where(
            keep_mask,
            sampled_token_ids,
            torch.full_like(sampled_token_ids, -1),
        )
        clamped_accepted_node_indices = self._ddtree_clamped_accepted_node_indices(
            accepted_node_indices,
            clamped_counts.to(device=accepted_node_indices.device),
        )
        self._ddtree_accepted_rows_cpu_sidecar = None
        self._ddtree_sampled_token_counts_cpu_sidecar = None
        if _dflash_ddtree_trace_enabled():
            _dflash_ddtree_trace_event(
                "sampler_output_clamped",
                {
                    "req_ids": list(
                        self.input_batch.req_ids[: sampled_token_ids.shape[0]]
                    ),
                    "valid_sampled_token_counts": (
                        valid_sampled_token_counts.detach().cpu().tolist()
                    ),
                    "max_generated_tokens": max_generated.detach().cpu().tolist(),
                    "clamped_counts": clamped_counts.detach().cpu().tolist(),
                    "sampled_token_ids": sampled_token_ids.detach().cpu().tolist(),
                    "clamped_sampled_token_ids": (
                        clamped_sampled_token_ids.detach().cpu().tolist()
                    ),
                    "accepted_node_indices": (
                        accepted_node_indices.detach().cpu().tolist()
                    ),
                    "clamped_accepted_node_indices": (
                        clamped_accepted_node_indices.detach().cpu().tolist()
                    ),
                },
            )
        return SamplerOutput(
            sampled_token_ids=clamped_sampled_token_ids,
            logprobs_tensors=sampler_output.logprobs_tensors,
            ddtree_accepted_node_indices=clamped_accepted_node_indices,
        )

    @staticmethod
    def _ddtree_accepted_rows_cpu(
        accepted_node_indices: torch.Tensor,
    ) -> list[list[int]]:
        if accepted_node_indices.ndim != 2:
            raise ValueError("accepted_node_indices must have shape [reqs, accepted]")
        return accepted_node_indices.detach().cpu().tolist()

    def _cache_ddtree_accepted_rows_cpu(
        self,
        ddtree_result: DDTreeGreedySamplerResult,
    ) -> None:
        self._ddtree_accepted_rows_cpu_sidecar = [
            list(result.accepted_node_indices)
            for result in ddtree_result.verification_results
        ]
        self._ddtree_sampled_token_counts_cpu_sidecar = [
            len(result.output_token_ids)
            for result in ddtree_result.verification_results
        ]

    @staticmethod
    def _ddtree_accepted_kv_local_copies_from_rows(
        *,
        req_ids: Sequence[str],
        num_scheduled_tokens: Mapping[str, int],
        scheduled_spec_decode_tokens: Mapping[str, Sequence[int]],
        accepted_rows: Sequence[Sequence[int]],
    ) -> list[tuple[int, int]]:
        copies: list[tuple[int, int]] = []
        req_start = 0
        for req_idx, req_id in enumerate(req_ids):
            req_num_tokens = int(num_scheduled_tokens.get(req_id, 0))
            draft_len = len(scheduled_spec_decode_tokens.get(req_id, ()))
            if req_num_tokens <= 0:
                continue
            if draft_len <= 0 or req_num_tokens < draft_len + 1:
                req_start += req_num_tokens
                continue
            sample_start = req_start + req_num_tokens - draft_len - 1
            accepted_pos = 0
            if req_idx >= len(accepted_rows):
                req_start += req_num_tokens
                continue
            for raw_node_idx in accepted_rows[req_idx]:
                node_idx = int(raw_node_idx)
                if node_idx < 0:
                    break
                if node_idx == 0:
                    continue
                if node_idx > draft_len:
                    break
                src_local = sample_start + node_idx
                dst_local = sample_start + 1 + accepted_pos
                accepted_pos += 1
                if src_local != dst_local:
                    copies.append((src_local, dst_local))
            req_start += req_num_tokens
        return copies

    @staticmethod
    def _ddtree_accepted_kv_local_copies(
        *,
        req_ids: Sequence[str],
        num_scheduled_tokens: Mapping[str, int],
        scheduled_spec_decode_tokens: Mapping[str, Sequence[int]],
        accepted_node_indices: torch.Tensor,
    ) -> list[tuple[int, int]]:
        return GPUModelRunner._ddtree_accepted_kv_local_copies_from_rows(
            req_ids=req_ids,
            num_scheduled_tokens=num_scheduled_tokens,
            scheduled_spec_decode_tokens=scheduled_spec_decode_tokens,
            accepted_rows=GPUModelRunner._ddtree_accepted_rows_cpu(
                accepted_node_indices
            ),
        )

    @staticmethod
    def _ddtree_accepted_nodes_are_flat_prefix_from_rows(
        accepted_rows: Sequence[Sequence[int]],
    ) -> bool:
        for row in accepted_rows:
            for expected_node_idx, raw_node_idx in enumerate(row):
                node_idx = int(raw_node_idx)
                if node_idx < 0:
                    break
                if node_idx != expected_node_idx:
                    return False
        return True

    @staticmethod
    def _ddtree_accepted_nodes_are_flat_prefix(
        accepted_node_indices: torch.Tensor,
    ) -> bool:
        return GPUModelRunner._ddtree_accepted_nodes_are_flat_prefix_from_rows(
            GPUModelRunner._ddtree_accepted_rows_cpu(accepted_node_indices)
        )

    @staticmethod
    def _ddtree_accepted_state_slot_copies_from_rows(
        accepted_rows: Sequence[Sequence[int]],
        *,
        max_spec_slots: int,
    ) -> list[tuple[int, int, int]]:
        copies: list[tuple[int, int, int]] = []
        for req_idx, row in enumerate(accepted_rows):
            accepted_pos = 0
            for raw_node_idx in row:
                node_idx = int(raw_node_idx)
                if node_idx < 0:
                    break
                if node_idx == 0:
                    continue
                if node_idx >= max_spec_slots:
                    break
                dst_slot = 1 + accepted_pos
                accepted_pos += 1
                if node_idx != dst_slot:
                    copies.append((req_idx, node_idx, dst_slot))
        return copies

    def _ddtree_accepted_copy_plan(
        self,
        sampler_output: SamplerOutput,
        scheduler_output: "SchedulerOutput",
    ) -> DDTreeAcceptedCopyPlan | None:
        accepted_node_indices = sampler_output.ddtree_accepted_node_indices
        if accepted_node_indices is None:
            return None
        accepted_rows = getattr(self, "_ddtree_accepted_rows_cpu_sidecar", None)
        if (
            accepted_rows is None
            or len(accepted_rows) != accepted_node_indices.shape[0]
        ):
            accepted_rows = self._ddtree_accepted_rows_cpu(accepted_node_indices)
        return DDTreeAcceptedCopyPlan(
            accepted_rows=accepted_rows,
            kv_local_copies=self._ddtree_accepted_kv_local_copies_from_rows(
                req_ids=self.input_batch.req_ids[: self.input_batch.num_reqs],
                num_scheduled_tokens=scheduler_output.num_scheduled_tokens,
                scheduled_spec_decode_tokens=(
                    scheduler_output.scheduled_spec_decode_tokens
                ),
                accepted_rows=accepted_rows,
            ),
            state_slot_copies=self._ddtree_accepted_state_slot_copies_from_rows(
                accepted_rows,
                max_spec_slots=getattr(
                    self, "max_spec_state_slots", accepted_node_indices.shape[1]
                ),
            ),
            flat_prefix=self._ddtree_accepted_nodes_are_flat_prefix_from_rows(
                accepted_rows
            ),
        )

    @staticmethod
    def _ddtree_state_slot_selectors_from_accepted_nodes(
        accepted_node_indices: torch.Tensor,
        flat_selectors: torch.Tensor | None = None,
    ) -> torch.Tensor:
        """Return DDTree recurrent-state selector values per request.

        Existing hybrid kernels interpret ``num_accepted_tokens - 1`` as the
        speculative state slot to continue from. For a DDTree path this slot is
        the last accepted compact node index, not the accepted-token count.
        """
        if accepted_node_indices.ndim != 2:
            raise ValueError("accepted_node_indices must have shape [reqs, accepted]")
        if accepted_node_indices.shape[1] == 0:
            return torch.ones(
                accepted_node_indices.shape[0],
                dtype=torch.int32,
                device=accepted_node_indices.device,
            )
        valid = accepted_node_indices >= 1
        positions = torch.arange(
            accepted_node_indices.shape[1],
            dtype=torch.long,
            device=accepted_node_indices.device,
        )
        last_positions = (
            torch.where(
                valid,
                positions.unsqueeze(0),
                torch.full(
                    accepted_node_indices.shape,
                    -1,
                    dtype=torch.long,
                    device=accepted_node_indices.device,
                ),
            )
            .max(dim=1)
            .values
        )
        gather_positions = last_positions.clamp(min=0)
        last_node_indices = accepted_node_indices.gather(
            1,
            gather_positions.unsqueeze(1),
        ).squeeze(1)
        last_node_indices = torch.where(
            last_positions >= 0,
            last_node_indices,
            torch.zeros_like(last_node_indices),
        )
        if flat_selectors is not None:
            flat_selectors = flat_selectors.to(
                dtype=torch.int32, device=accepted_node_indices.device
            )
            return torch.where(
                last_node_indices >= 1,
                last_node_indices + 1,
                flat_selectors,
            )
        return (last_node_indices + 1).to(torch.int32)

    def _ddtree_state_update_cpu_sidecar(
        self,
        *,
        num_reqs: int,
        ddtree_mamba_state_compacted: bool,
        stage_gpu: bool,
    ) -> tuple[torch.Tensor, torch.Tensor] | None:
        accepted_rows = getattr(self, "_ddtree_accepted_rows_cpu_sidecar", None)
        sampled_counts = getattr(self, "_ddtree_sampled_token_counts_cpu_sidecar", None)
        if (
            accepted_rows is None
            or sampled_counts is None
            or len(accepted_rows) != num_reqs
            or len(sampled_counts) != num_reqs
        ):
            return None

        num_accepted_np = self.num_accepted_tokens.np
        selectors_np = self.spec_state_slot_selectors.np
        for req_idx in range(num_reqs):
            count = int(sampled_counts[req_idx])
            num_accepted_np[req_idx] = count
            selector = count
            if not ddtree_mamba_state_compacted:
                last_non_root_node = 0
                for raw_node_idx in accepted_rows[req_idx]:
                    node_idx = int(raw_node_idx)
                    if node_idx < 0:
                        break
                    if node_idx >= 1:
                        last_non_root_node = node_idx
                if last_non_root_node >= 1:
                    selector = last_non_root_node + 1
            selectors_np[req_idx] = selector

        if stage_gpu:
            self._copy_buffer_to_gpu(self.num_accepted_tokens, num_reqs)
            self._copy_buffer_to_gpu(self.spec_state_slot_selectors, num_reqs)
        return (
            self.num_accepted_tokens.cpu[:num_reqs],
            self.spec_state_slot_selectors.cpu[:num_reqs],
        )

    @staticmethod
    def _attach_ddtree_metadata_for_cudagraph_capture(
        builder: AttentionMetadataBuilder,
        attn_metadata: AttentionMetadata,
        extra_attn_metadata_args: Mapping[str, Any],
    ) -> None:
        parent_ids = extra_attn_metadata_args.get("ddtree_parent_ids")
        num_tree_tokens_cpu = extra_attn_metadata_args.get("ddtree_num_tree_tokens_cpu")
        if parent_ids is None:
            return

        attach = getattr(builder, "_attach_ddtree_metadata", None)
        if callable(attach):
            attach(
                attn_metadata,
                ddtree_parent_ids=parent_ids,
                ddtree_num_tree_tokens_cpu=num_tree_tokens_cpu,
            )
            return

        if hasattr(attn_metadata, "ddtree_parent_ids"):
            attn_metadata.ddtree_parent_ids = parent_ids
        if hasattr(attn_metadata, "ddtree_num_tree_tokens_cpu"):
            attn_metadata.ddtree_num_tree_tokens_cpu = num_tree_tokens_cpu
        if (
            hasattr(attn_metadata, "ddtree_num_tree_tokens")
            and num_tree_tokens_cpu is not None
        ):
            attn_metadata.ddtree_num_tree_tokens = num_tree_tokens_cpu.to(
                parent_ids.device, non_blocking=True
            )

        # FlexAttention pre-builds its block mask during metadata build. If
        # DDTree parents are attached after build_for_cudagraph_capture(), rebuild
        # the mask so capture records the tree mask instead of plain causal.
        if hasattr(attn_metadata, "block_mask") and hasattr(
            attn_metadata, "build_block_mask"
        ):
            attn_metadata.block_mask = None
            if getattr(attn_metadata, "direct_build", False) and hasattr(
                attn_metadata, "_build_block_mask_direct"
            ):
                attn_metadata.block_mask = attn_metadata._build_block_mask_direct()
            else:
                attn_metadata.block_mask = attn_metadata.build_block_mask()

    @staticmethod
    def _ddtree_slot_from_cpu_position(
        *,
        block_table: np.ndarray,
        req_idx: int,
        position: int,
        block_size: int,
    ) -> int | None:
        block_idx = position // block_size
        block_offset = position - block_idx * block_size
        if (
            req_idx < 0
            or req_idx >= block_table.shape[0]
            or block_idx < 0
            or block_idx >= block_table.shape[1]
        ):
            return None
        block_id = int(block_table[req_idx, block_idx])
        if block_id == PAD_SLOT_ID:
            return None
        return block_id * block_size + block_offset

    def _ddtree_attention_kv_slot_pairs_from_cpu_sidecar(
        self,
        *,
        kv_cache_gid: int,
        block_size: int,
        copies: Sequence[tuple[int, int]],
    ) -> list[tuple[int, int, int, int]] | None:
        positions_cpu = getattr(self, "_current_positions_cpu_sidecar", None)
        req_indices_cpu = getattr(self, "_current_req_indices_cpu_sidecar", None)
        if positions_cpu is None or req_indices_cpu is None:
            return None

        block_tables = getattr(self.input_batch.block_table, "block_tables", None)
        if block_tables is None or kv_cache_gid >= len(block_tables):
            return None
        block_table_obj = block_tables[kv_cache_gid]
        total_cp_world_size = int(getattr(block_table_obj, "pcp_world_size", 1)) * int(
            getattr(block_table_obj, "dcp_world_size", 1)
        )
        if total_cp_world_size != 1:
            return None
        if int(getattr(block_table_obj, "block_size", block_size)) != block_size:
            return None

        block_table = block_table_obj.get_numpy_array()
        slot_copy_pairs: list[tuple[int, int, int, int]] = []
        for src_local, dst_local in copies:
            if (
                src_local < 0
                or dst_local < 0
                or src_local >= len(positions_cpu)
                or dst_local >= len(positions_cpu)
                or src_local >= len(req_indices_cpu)
                or dst_local >= len(req_indices_cpu)
            ):
                continue
            src_req_idx = int(req_indices_cpu[src_local])
            dst_req_idx = int(req_indices_cpu[dst_local])
            if src_req_idx != dst_req_idx:
                return None
            src_slot = self._ddtree_slot_from_cpu_position(
                block_table=block_table,
                req_idx=src_req_idx,
                position=int(positions_cpu[src_local]),
                block_size=block_size,
            )
            dst_slot = self._ddtree_slot_from_cpu_position(
                block_table=block_table,
                req_idx=dst_req_idx,
                position=int(positions_cpu[dst_local]),
                block_size=block_size,
            )
            if src_slot is None or dst_slot is None:
                return None
            slot_copy_pairs.append((src_local, dst_local, src_slot, dst_slot))
        return slot_copy_pairs

    @staticmethod
    def _ddtree_payload_is_flat_chain(payload: object) -> bool:
        is_flat_chain = getattr(payload, "is_flat_chain", None)
        if callable(is_flat_chain):
            return bool(is_flat_chain())
        flat = tuple(getattr(payload, "flat_draft_token_ids", ()))
        tree = tuple(getattr(payload, "tree_token_ids", ()))
        parents = tuple(getattr(payload, "parent_indices", ()))
        depths = tuple(getattr(payload, "node_depths", ()))
        num_nodes = len(tree)
        expected_parents = () if num_nodes == 0 else (-1,) + tuple(range(num_nodes - 1))
        expected_depths = tuple(range(1, num_nodes + 1))
        return (
            tree == flat and parents == expected_parents and depths == expected_depths
        )

    @classmethod
    def _ddtree_scheduled_payloads_require_hybrid_tree_state(
        cls,
        scheduler_output: "SchedulerOutput",
    ) -> bool:
        payloads = scheduler_output.scheduled_ddtree_payloads
        if not payloads:
            return False
        return any(
            not cls._ddtree_payload_is_flat_chain(payload)
            for payload in payloads.values()
        )

    def _validate_ddtree_hybrid_state_path(
        self,
        sampler_output: SamplerOutput,
        scheduler_output: "SchedulerOutput",
        copy_plan: DDTreeAcceptedCopyPlan | None = None,
    ) -> None:
        if (
            not self.model_config.is_hybrid
            or sampler_output.ddtree_accepted_node_indices is None
            or not scheduler_output.scheduled_ddtree_payloads
            or not self._ddtree_scheduled_payloads_require_hybrid_tree_state(
                scheduler_output
            )
        ):
            return

        accepted_path = (
            "flat-prefix"
            if (
                copy_plan.flat_prefix
                if copy_plan is not None
                else self._ddtree_accepted_nodes_are_flat_prefix(
                    sampler_output.ddtree_accepted_node_indices
                )
            )
            else "branched"
        )
        if os.getenv("VLLM_DFLASH_DDTREE_ENABLE_HYBRID_TREE_STATE", "0") == "1":
            return
        raise RuntimeError(
            "Branched DDTree verification for hybrid models requires "
            "tree-aware GDN/Mamba parent-state computation and accepted-path "
            "state commit before the recurrent state update. "
            f"Observed accepted path: {accepted_path}."
        )

    def _stage_ddtree_parent_metadata(
        self,
        metadata: DDTreeParentMetadata | None,
        *,
        num_reqs: int,
        num_reqs_padded: int | None = None,
    ) -> DDTreeParentMetadata | None:
        if metadata is None:
            return None
        num_rows = num_reqs_padded or num_reqs
        if num_rows <= 0:
            return None
        if num_rows > self.max_num_reqs:
            raise ValueError(
                f"DDTree parent metadata rows {num_rows} exceed "
                f"max_num_reqs {self.max_num_reqs}"
            )
        if metadata.parent_ids.shape[1] > self.max_spec_state_slots:
            raise ValueError(
                "DDTree parent metadata width "
                f"{metadata.parent_ids.shape[1]} exceeds max_spec_state_slots "
                f"{self.max_spec_state_slots}"
            )

        staged_parent_ids = self.ddtree_parent_ids.gpu
        already_staged = (
            metadata.parent_ids.device == staged_parent_ids.device
            and metadata.parent_ids.data_ptr() == staged_parent_ids.data_ptr()
            and metadata.num_tree_tokens_cpu.device.type == "cpu"
            and metadata.num_tree_tokens_cpu.data_ptr()
            == self.ddtree_num_tree_tokens_cpu.data_ptr()
        )
        if already_staged:
            if metadata.parent_ids.shape[0] < num_rows:
                staged_rows = metadata.parent_ids.shape[0]
                self.ddtree_parent_ids.cpu[staged_rows:num_rows].fill_(0)
                self.ddtree_num_tree_tokens_cpu[staged_rows:num_rows].zero_()
                self._copy_buffer_to_gpu(self.ddtree_parent_ids, num_rows)
            return DDTreeParentMetadata(
                parent_ids=staged_parent_ids[:num_rows],
                num_tree_tokens_cpu=self.ddtree_num_tree_tokens_cpu[:num_rows],
                request_ids=metadata.request_ids[:num_reqs],
            )

        num_tree_tokens_cpu = metadata.num_tree_tokens_cpu[:num_reqs].clone()
        self.ddtree_parent_ids.cpu[:num_rows].fill_(0)
        self.ddtree_parent_ids.cpu[:num_reqs, : metadata.parent_ids.shape[1]].copy_(
            metadata.parent_ids[:num_reqs].to(device="cpu", non_blocking=False)
        )
        self.ddtree_num_tree_tokens_cpu[:num_rows].zero_()
        self.ddtree_num_tree_tokens_cpu[:num_reqs].copy_(num_tree_tokens_cpu)
        self._copy_buffer_to_gpu(self.ddtree_parent_ids, num_rows)
        return DDTreeParentMetadata(
            parent_ids=self.ddtree_parent_ids.gpu[:num_rows],
            num_tree_tokens_cpu=self.ddtree_num_tree_tokens_cpu[:num_rows],
            request_ids=metadata.request_ids[:num_reqs],
        )

    def _dummy_ddtree_parent_metadata(
        self,
        *,
        num_reqs: int,
        num_reqs_padded: int | None = None,
    ) -> DDTreeParentMetadata | None:
        if num_reqs <= 0 or self.num_spec_tokens <= 0:
            return None
        width = self.max_spec_state_slots
        num_tree_tokens = max(0, width - 1)
        payload = DDTreeDraftPayload(
            tree_token_ids=tuple(0 for _ in range(num_tree_tokens)),
            parent_indices=(
                ()
                if num_tree_tokens == 0
                else (-1,) + tuple(range(num_tree_tokens - 1))
            ),
            node_depths=tuple(range(1, num_tree_tokens + 1)),
            node_scores=tuple(0.0 for _ in range(num_tree_tokens)),
            top1_chain_token_ids=tuple(0 for _ in range(num_tree_tokens)),
            flat_draft_token_ids=tuple(0 for _ in range(num_tree_tokens)),
            budget=num_tree_tokens,
            top_k=1,
            chain_seed=True,
        )
        req_ids = tuple(f"dummy-{i}" for i in range(num_reqs))
        metadata = build_padded_parent_ids(
            req_ids,
            {req_id: payload for req_id in req_ids},
            device="cpu",
            pad_to=width,
        )
        return self._stage_ddtree_parent_metadata(
            metadata,
            num_reqs=num_reqs,
            num_reqs_padded=num_reqs_padded,
        )

    @staticmethod
    def _copy_attention_kv_slot(
        kv_cache: torch.Tensor,
        *,
        src_slot: int,
        dst_slot: int,
        block_size: int,
    ) -> str | None:
        if src_slot < 0 or dst_slot < 0 or src_slot == dst_slot:
            return None
        if kv_cache.ndim < 5:
            return None
        src_block, src_offset = divmod(src_slot, block_size)
        dst_block, dst_offset = divmod(dst_slot, block_size)
        # vLLM paged attention KV caches appear in both
        # [blocks, 2, block, ...] and [2, blocks, block, ...] layouts. Match
        # flash_attn_v100._split_paged_kv_cache and prefer axis 1 so a tiny
        # two-block cache is not mistaken for K/V-first layout.
        if kv_cache.shape[1] == 2 and kv_cache.shape[2] == block_size:
            kv_cache[dst_block, :, dst_offset].copy_(kv_cache[src_block, :, src_offset])
            return "blocks_kv_block"
        elif kv_cache.shape[0] == 2 and kv_cache.shape[2] == block_size:
            kv_cache[:, dst_block, dst_offset].copy_(kv_cache[:, src_block, src_offset])
            return "kv_blocks_block"
        return None

    @staticmethod
    def _copy_attention_kv_slots(
        kv_cache: torch.Tensor,
        *,
        slot_copy_pairs: Sequence[tuple[int, int, int, int]],
        block_size: int,
        slot_copy_tensors: tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]
        | None = None,
    ) -> str | None:
        if not slot_copy_pairs:
            return None
        if len(slot_copy_pairs) == 1:
            _, _, src_slot, dst_slot = slot_copy_pairs[0]
            return GPUModelRunner._copy_attention_kv_slot(
                kv_cache,
                src_slot=src_slot,
                dst_slot=dst_slot,
                block_size=block_size,
            )
        src_slots = [src_slot for _, _, src_slot, _ in slot_copy_pairs]
        dst_slots = [dst_slot for _, _, _, dst_slot in slot_copy_pairs]
        if set(src_slots) & set(dst_slots):
            copied_layout = None
            for _, _, src_slot, dst_slot in slot_copy_pairs:
                copied_layout = GPUModelRunner._copy_attention_kv_slot(
                    kv_cache,
                    src_slot=src_slot,
                    dst_slot=dst_slot,
                    block_size=block_size,
                )
            return copied_layout
        if slot_copy_tensors is None:
            src_blocks_offsets = [
                divmod(src_slot, block_size) for src_slot in src_slots
            ]
            dst_blocks_offsets = [
                divmod(dst_slot, block_size) for dst_slot in dst_slots
            ]
            src_blocks = torch.tensor(
                [block for block, _ in src_blocks_offsets],
                dtype=torch.long,
                device=kv_cache.device,
            )
            src_offsets = torch.tensor(
                [offset for _, offset in src_blocks_offsets],
                dtype=torch.long,
                device=kv_cache.device,
            )
            dst_blocks = torch.tensor(
                [block for block, _ in dst_blocks_offsets],
                dtype=torch.long,
                device=kv_cache.device,
            )
            dst_offsets = torch.tensor(
                [offset for _, offset in dst_blocks_offsets],
                dtype=torch.long,
                device=kv_cache.device,
            )
        else:
            src_blocks, src_offsets, dst_blocks, dst_offsets = slot_copy_tensors
        if kv_cache.shape[1] == 2 and kv_cache.shape[2] == block_size:
            kv_cache[dst_blocks, :, dst_offsets] = kv_cache[src_blocks, :, src_offsets]
            return "blocks_kv_block_batched"
        if kv_cache.shape[0] == 2 and kv_cache.shape[2] == block_size:
            kv_cache[:, dst_blocks, dst_offsets] = kv_cache[:, src_blocks, src_offsets]
            return "kv_blocks_block_batched"
        return None

    @staticmethod
    def _attention_kv_slot_memcpy_specs(
        kv_cache: torch.Tensor,
        *,
        slot_copy_pairs: Sequence[tuple[int, int, int, int]],
        block_size: int,
    ) -> tuple[list[int], list[int], list[int], str] | None:
        if not slot_copy_pairs or kv_cache.ndim < 5:
            return None

        expected_stride = 1
        token_numel = 1
        for dim_size, dim_stride in reversed(
            list(zip(kv_cache.shape[3:], kv_cache.stride()[3:]))
        ):
            if dim_stride != expected_stride:
                return None
            dim_size = int(dim_size)
            token_numel *= dim_size
            expected_stride *= dim_size
        if token_numel <= 0:
            return None

        elem_size = kv_cache.element_size()
        size_bytes = token_numel * elem_size
        strides = kv_cache.stride()
        base_ptr = kv_cache.data_ptr()
        src_ptrs: list[int] = []
        dst_ptrs: list[int] = []
        sizes: list[int] = []

        if kv_cache.shape[1] == 2 and kv_cache.shape[2] == block_size:
            for _, _, src_slot, dst_slot in slot_copy_pairs:
                src_block, src_offset = divmod(src_slot, block_size)
                dst_block, dst_offset = divmod(dst_slot, block_size)
                for kv_idx in range(2):
                    src_elem = (
                        src_block * strides[0]
                        + kv_idx * strides[1]
                        + src_offset * strides[2]
                    )
                    dst_elem = (
                        dst_block * strides[0]
                        + kv_idx * strides[1]
                        + dst_offset * strides[2]
                    )
                    src_ptrs.append(base_ptr + src_elem * elem_size)
                    dst_ptrs.append(base_ptr + dst_elem * elem_size)
                    sizes.append(size_bytes)
            return src_ptrs, dst_ptrs, sizes, "blocks_kv_block_memcpy_batched"

        if kv_cache.shape[0] == 2 and kv_cache.shape[2] == block_size:
            for _, _, src_slot, dst_slot in slot_copy_pairs:
                src_block, src_offset = divmod(src_slot, block_size)
                dst_block, dst_offset = divmod(dst_slot, block_size)
                for kv_idx in range(2):
                    src_elem = (
                        kv_idx * strides[0]
                        + src_block * strides[1]
                        + src_offset * strides[2]
                    )
                    dst_elem = (
                        kv_idx * strides[0]
                        + dst_block * strides[1]
                        + dst_offset * strides[2]
                    )
                    src_ptrs.append(base_ptr + src_elem * elem_size)
                    dst_ptrs.append(base_ptr + dst_elem * elem_size)
                    sizes.append(size_bytes)
            return src_ptrs, dst_ptrs, sizes, "kv_blocks_block_memcpy_batched"

        return None

    def _compact_ddtree_accepted_attention_kv(
        self,
        sampler_output: SamplerOutput,
        scheduler_output: "SchedulerOutput",
        slot_mappings_by_group: dict[int, torch.Tensor] | None,
        copy_plan: DDTreeAcceptedCopyPlan | None = None,
    ) -> None:
        accepted_node_indices = sampler_output.ddtree_accepted_node_indices
        if (
            accepted_node_indices is None
            or not scheduler_output.scheduled_ddtree_payloads
            or slot_mappings_by_group is None
        ):
            return
        if not self._ddtree_scheduled_payloads_require_hybrid_tree_state(
            scheduler_output
        ):
            return

        if copy_plan is None:
            copy_plan = self._ddtree_accepted_copy_plan(
                sampler_output, scheduler_output
            )
        copies = [] if copy_plan is None else copy_plan.kv_local_copies
        if not copies:
            if _dflash_ddtree_trace_enabled():
                _dflash_ddtree_trace_event(
                    "attention_kv_compact",
                    {
                        "accepted_node_indices": (
                            copy_plan.accepted_rows
                            if copy_plan is not None
                            else accepted_node_indices.detach().cpu().tolist()
                        ),
                        "copies": [],
                    },
                )
            return

        forward_context = self.compilation_config.static_forward_context
        trace_records: list[dict[str, object]] = []
        for kv_cache_gid, kv_cache_group in enumerate(
            self.kv_cache_config.kv_cache_groups
        ):
            slot_mapping = slot_mappings_by_group.get(kv_cache_gid)
            if slot_mapping is None:
                continue
            kv_cache_spec = kv_cache_group.kv_cache_spec
            if isinstance(kv_cache_spec, UniformTypeKVCacheSpecs):
                kv_cache_spec = next(iter(kv_cache_spec.kv_cache_specs.values()))
            if not isinstance(kv_cache_spec, AttentionSpec):
                continue
            block_size = kv_cache_spec.block_size
            slot_copy_pairs = self._ddtree_attention_kv_slot_pairs_from_cpu_sidecar(
                kv_cache_gid=kv_cache_gid,
                block_size=block_size,
                copies=copies,
            )
            if slot_copy_pairs is None:
                slot_mapping_cpu = slot_mapping.detach().cpu().tolist()
                slot_copy_pairs = []
                for src_local, dst_local in copies:
                    if src_local >= len(slot_mapping_cpu) or dst_local >= len(
                        slot_mapping_cpu
                    ):
                        continue
                    slot_copy_pairs.append(
                        (
                            src_local,
                            dst_local,
                            int(slot_mapping_cpu[src_local]),
                            int(slot_mapping_cpu[dst_local]),
                        )
                    )
            if not slot_copy_pairs:
                continue
            slot_copy_tensors = None
            src_slots = [src_slot for _, _, src_slot, _ in slot_copy_pairs]
            dst_slots = [dst_slot for _, _, _, dst_slot in slot_copy_pairs]
            index_device = getattr(self, "device", slot_mapping.device)
            can_batch_memcpy = (
                os.getenv("VLLM_DFLASH_DDTREE_ATTN_COMPACT_BATCH", "0") == "1"
                and len(slot_copy_pairs) > 1
                and slot_mapping.is_cuda
                and index_device.type == "cuda"
                and not (set(src_slots) & set(dst_slots))
            )
            batch_src_ptrs: list[int] = []
            batch_dst_ptrs: list[int] = []
            batch_sizes: list[int] = []
            if len(slot_copy_pairs) > 1 and not (set(src_slots) & set(dst_slots)):
                src_blocks_offsets = [
                    divmod(src_slot, block_size) for src_slot in src_slots
                ]
                dst_blocks_offsets = [
                    divmod(dst_slot, block_size) for dst_slot in dst_slots
                ]
                slot_copy_tensors = (
                    torch.tensor(
                        [block for block, _ in src_blocks_offsets],
                        dtype=torch.long,
                        device=index_device,
                    ),
                    torch.tensor(
                        [offset for _, offset in src_blocks_offsets],
                        dtype=torch.long,
                        device=index_device,
                    ),
                    torch.tensor(
                        [block for block, _ in dst_blocks_offsets],
                        dtype=torch.long,
                        device=index_device,
                    ),
                    torch.tensor(
                        [offset for _, offset in dst_blocks_offsets],
                        dtype=torch.long,
                        device=index_device,
                    ),
                )
            for layer_name in kv_cache_group.layer_names:
                attention = forward_context.get(layer_name)
                kv_cache = None if attention is None else attention.kv_cache
                if not isinstance(kv_cache, torch.Tensor):
                    continue
                data_ptr = kv_cache.data_ptr()
                copied_layout = None
                if can_batch_memcpy:
                    memcpy_specs = self._attention_kv_slot_memcpy_specs(
                        kv_cache,
                        slot_copy_pairs=slot_copy_pairs,
                        block_size=block_size,
                    )
                    if memcpy_specs is not None:
                        src_ptrs, dst_ptrs, sizes, copied_layout = memcpy_specs
                        batch_src_ptrs.extend(src_ptrs)
                        batch_dst_ptrs.extend(dst_ptrs)
                        batch_sizes.extend(sizes)
                if copied_layout is None:
                    copied_layout = self._copy_attention_kv_slots(
                        kv_cache,
                        slot_copy_pairs=slot_copy_pairs,
                        block_size=block_size,
                        slot_copy_tensors=slot_copy_tensors,
                    )
                for src_local, dst_local, src_slot, dst_slot in slot_copy_pairs:
                    trace_records.append(
                        {
                            "kv_cache_gid": kv_cache_gid,
                            "layer_name": str(layer_name),
                            "kv_cache_data_ptr": data_ptr,
                            "src_local": src_local,
                            "dst_local": dst_local,
                            "src_slot": src_slot,
                            "dst_slot": dst_slot,
                            "block_size": block_size,
                            "kv_cache_shape": list(kv_cache.shape),
                            "copied_layout": copied_layout,
                        }
                    )
            if batch_src_ptrs:
                index_device = getattr(self, "device", slot_mapping.device)
                mamba_utils.batch_memcpy(
                    torch.tensor(
                        batch_src_ptrs,
                        dtype=torch.int64,
                        device=index_device,
                    ),
                    torch.tensor(
                        batch_dst_ptrs,
                        dtype=torch.int64,
                        device=index_device,
                    ),
                    torch.tensor(
                        batch_sizes,
                        dtype=torch.int64,
                        device=index_device,
                    ),
                    max_size=max(batch_sizes),
                )
        if _dflash_ddtree_trace_enabled():
            _dflash_ddtree_trace_event(
                "attention_kv_compact",
                {
                    "accepted_node_indices": (
                        copy_plan.accepted_rows
                        if copy_plan is not None
                        else accepted_node_indices.detach().cpu().tolist()
                    ),
                    "copies": trace_records,
                },
            )

    @staticmethod
    def _ddtree_accepted_state_slot_copies(
        accepted_node_indices: torch.Tensor,
        *,
        max_spec_slots: int,
    ) -> list[tuple[int, int, int]]:
        return GPUModelRunner._ddtree_accepted_state_slot_copies_from_rows(
            GPUModelRunner._ddtree_accepted_rows_cpu(accepted_node_indices),
            max_spec_slots=max_spec_slots,
        )

    def _compact_ddtree_accepted_mamba_state(
        self,
        sampler_output: SamplerOutput,
        scheduler_output: "SchedulerOutput",
        copy_plan: DDTreeAcceptedCopyPlan | None = None,
    ) -> bool:
        accepted_node_indices = sampler_output.ddtree_accepted_node_indices
        if (
            accepted_node_indices is None
            or not scheduler_output.scheduled_ddtree_payloads
        ):
            return False
        if not self._ddtree_scheduled_payloads_require_hybrid_tree_state(
            scheduler_output
        ):
            return False
        if os.getenv("VLLM_DFLASH_DDTREE_SKIP_MAMBA_COMPACT", "0") == "1":
            if _dflash_ddtree_trace_enabled():
                _dflash_ddtree_trace_event(
                    "mamba_state_compact",
                    {
                        "accepted_node_indices": (
                            copy_plan.accepted_rows
                            if copy_plan is not None
                            else accepted_node_indices.detach().cpu().tolist()
                        ),
                        "copies": [],
                        "skipped": [{"reason": "env_skip_mamba_compact"}],
                        "mamba_cache_mode": self.cache_config.mamba_cache_mode,
                    },
                )
            return False
        if (
            self.cache_config.mamba_cache_mode == "align"
            and os.getenv("VLLM_DFLASH_DDTREE_FORCE_MAMBA_COMPACT", "0") != "1"
        ):
            if _dflash_ddtree_trace_enabled():
                _dflash_ddtree_trace_event(
                    "mamba_state_compact",
                    {
                        "accepted_node_indices": (
                            copy_plan.accepted_rows
                            if copy_plan is not None
                            else accepted_node_indices.detach().cpu().tolist()
                        ),
                        "copies": [],
                        "skipped": [{"reason": "fused_ddtree_postprocess"}],
                        "mamba_cache_mode": self.cache_config.mamba_cache_mode,
                    },
                )
            return False

        if copy_plan is None:
            copy_plan = self._ddtree_accepted_copy_plan(
                sampler_output, scheduler_output
            )
        copies = [] if copy_plan is None else copy_plan.state_slot_copies
        if not copies:
            return False

        forward_context = self.compilation_config.static_forward_context
        trace_records: list[dict[str, object]] = []
        skipped_records: list[dict[str, object]] = []
        copied_any = False
        compacted_any = False
        batch_copy_bufs = None
        if (
            os.getenv("VLLM_DFLASH_DDTREE_MAMBA_COMPACT_BATCH", "1") != "0"
            and getattr(self, "device", None) is not None
            and self.device.type == "cuda"
        ):
            batch_copy_bufs = self._get_ddtree_mamba_compact_copy_bufs()
            batch_copy_bufs.offset = 0
        for kv_cache_gid, kv_cache_group in enumerate(
            self.kv_cache_config.kv_cache_groups
        ):
            kv_cache_spec = kv_cache_group.kv_cache_spec
            if isinstance(kv_cache_spec, UniformTypeKVCacheSpecs):
                kv_cache_spec = next(iter(kv_cache_spec.kv_cache_specs.values()))
            if not isinstance(kv_cache_spec, MambaSpec):
                continue
            block_table = self.input_batch.block_table.block_tables[
                kv_cache_gid
            ].get_numpy_array()
            group_records: list[DDTreeMambaCopyRecord] = []
            for req_idx, src_slot, dst_slot in copies:
                if req_idx >= len(self.input_batch.req_ids):
                    continue
                req_id = self.input_batch.req_ids[req_idx]
                req_state = self.requests.get(req_id)
                if req_state is None:
                    continue
                num_scheduled = int(
                    scheduler_output.num_scheduled_tokens.get(req_id, 0)
                )
                if num_scheduled <= 0:
                    continue
                if self.cache_config.mamba_cache_mode == "none":
                    state_window_start = 0
                else:
                    seq_len = req_state.num_computed_tokens + num_scheduled
                    state_window_start = max(
                        0, (seq_len - 1) // kv_cache_spec.block_size
                    )
                src_block_idx = state_window_start + src_slot
                dst_block_idx = state_window_start + dst_slot
                if (
                    req_idx >= block_table.shape[0]
                    or src_block_idx >= block_table.shape[1]
                    or dst_block_idx >= block_table.shape[1]
                ):
                    skipped_records.append(
                        {
                            "kv_cache_gid": kv_cache_gid,
                            "req_id": req_id,
                            "src_slot": src_slot,
                            "dst_slot": dst_slot,
                            "state_window_start": state_window_start,
                            "src_block_idx": src_block_idx,
                            "dst_block_idx": dst_block_idx,
                            "reason": "block_table_oob",
                        }
                    )
                    continue
                src_block_id = int(block_table[req_idx, src_block_idx])
                dst_block_id = int(block_table[req_idx, dst_block_idx])
                if src_block_id == PAD_SLOT_ID or dst_block_id == PAD_SLOT_ID:
                    skipped_records.append(
                        {
                            "kv_cache_gid": kv_cache_gid,
                            "req_id": req_id,
                            "src_slot": src_slot,
                            "dst_slot": dst_slot,
                            "state_window_start": state_window_start,
                            "src_block_idx": src_block_idx,
                            "dst_block_idx": dst_block_idx,
                            "src_block_id": src_block_id,
                            "dst_block_id": dst_block_id,
                            "reason": "pad_block",
                        }
                    )
                    continue
                compacted_any = True
                if src_block_id == dst_block_id:
                    trace_records.append(
                        {
                            "kv_cache_gid": kv_cache_gid,
                            "req_id": req_id,
                            "src_slot": src_slot,
                            "dst_slot": dst_slot,
                            "state_window_start": state_window_start,
                            "src_block_idx": src_block_idx,
                            "dst_block_idx": dst_block_idx,
                            "src_block_id": src_block_id,
                            "dst_block_id": dst_block_id,
                            "same_block": True,
                        }
                    )
                    continue
                group_records.append(
                    {
                        "kv_cache_gid": kv_cache_gid,
                        "req_idx": req_idx,
                        "req_id": req_id,
                        "req_state": req_state,
                        "src_slot": src_slot,
                        "dst_slot": dst_slot,
                        "state_window_start": state_window_start,
                        "src_block_idx": src_block_idx,
                        "dst_block_idx": dst_block_idx,
                        "src_block_id": src_block_id,
                        "dst_block_id": dst_block_id,
                    }
                )

            src_block_ids = {int(record["src_block_id"]) for record in group_records}
            dst_block_ids = {int(record["dst_block_id"]) for record in group_records}
            use_batch_copy = (
                batch_copy_bufs is not None
                and bool(group_records)
                and not (src_block_ids & dst_block_ids)
            )
            if use_batch_copy:
                assert batch_copy_bufs is not None
                for record in group_records:
                    before_offset = batch_copy_bufs.offset
                    mamba_utils.collect_mamba_copy_meta(
                        batch_copy_bufs,
                        self.kv_cache_config,
                        self.model.get_mamba_state_copy_func(),
                        [kv_cache_gid],
                        int(record["src_block_idx"]),
                        int(record["dst_block_idx"]),
                        0,
                        record["req_state"],
                        forward_context,
                        0,
                    )
                    copied_entries = batch_copy_bufs.offset - before_offset
                    copied_any = copied_any or copied_entries > 0
                    trace_records.append(
                        {
                            "kv_cache_gid": kv_cache_gid,
                            "req_id": str(record["req_id"]),
                            "src_slot": int(record["src_slot"]),
                            "dst_slot": int(record["dst_slot"]),
                            "state_window_start": int(record["state_window_start"]),
                            "src_block_idx": int(record["src_block_idx"]),
                            "dst_block_idx": int(record["dst_block_idx"]),
                            "src_block_id": int(record["src_block_id"]),
                            "dst_block_id": int(record["dst_block_id"]),
                            "batched": True,
                            "copied_entries": copied_entries,
                        }
                    )
                continue

            for record in group_records:
                src_block_id = int(record["src_block_id"])
                dst_block_id = int(record["dst_block_id"])
                for layer_name in kv_cache_group.layer_names:
                    attention = forward_context.get(layer_name)
                    kv_caches = None if attention is None else attention.kv_cache
                    if not isinstance(kv_caches, list):
                        continue
                    for state_idx, state in enumerate(kv_caches):
                        if (
                            not isinstance(state, torch.Tensor)
                            or src_block_id >= state.shape[0]
                            or dst_block_id >= state.shape[0]
                        ):
                            continue
                        state[dst_block_id].copy_(state[src_block_id])
                        copied_any = True
                        trace_records.append(
                            {
                                "kv_cache_gid": kv_cache_gid,
                                "req_id": str(record["req_id"]),
                                "layer_name": str(layer_name),
                                "state_idx": state_idx,
                                "src_slot": int(record["src_slot"]),
                                "dst_slot": int(record["dst_slot"]),
                                "state_window_start": int(record["state_window_start"]),
                                "src_block_idx": int(record["src_block_idx"]),
                                "dst_block_idx": int(record["dst_block_idx"]),
                                "src_block_id": src_block_id,
                                "dst_block_id": dst_block_id,
                                "batched": False,
                            }
                        )
        if batch_copy_bufs is not None:
            mamba_utils.do_mamba_copy_block(batch_copy_bufs)

        if _dflash_ddtree_trace_enabled():
            _dflash_ddtree_trace_event(
                "mamba_state_compact",
                {
                    "accepted_node_indices": (
                        copy_plan.accepted_rows
                        if copy_plan is not None
                        else accepted_node_indices.detach().cpu().tolist()
                    ),
                    "copies": trace_records,
                    "skipped": skipped_records,
                    "mamba_cache_mode": self.cache_config.mamba_cache_mode,
                },
            )
        return compacted_any or copied_any

    def _compact_ddtree_drafter_context(
        self,
        hidden_states: torch.Tensor,
        aux_hidden_states: list[torch.Tensor] | None,
        sampler_output: SamplerOutput,
        scheduler_output: "SchedulerOutput",
        copy_plan: DDTreeAcceptedCopyPlan | None = None,
    ) -> None:
        """Compact DDTree branch hidden states before the next DFlash draft."""
        if not envs.VLLM_DFLASH_DDTREE_COMPACT_DRAFTER_CONTEXT:
            return
        accepted_node_indices = sampler_output.ddtree_accepted_node_indices
        if (
            accepted_node_indices is None
            or not scheduler_output.scheduled_ddtree_payloads
            or not isinstance(hidden_states, torch.Tensor)
        ):
            return
        if not self._ddtree_scheduled_payloads_require_hybrid_tree_state(
            scheduler_output
        ):
            return

        if copy_plan is None:
            copy_plan = self._ddtree_accepted_copy_plan(
                sampler_output, scheduler_output
            )
        copies = [] if copy_plan is None else copy_plan.kv_local_copies
        if not copies:
            return

        tensors: list[torch.Tensor] = [hidden_states]
        if aux_hidden_states is not None:
            tensors.extend(
                tensor
                for tensor in aux_hidden_states
                if isinstance(tensor, torch.Tensor)
            )

        copied = 0
        trace_records: list[dict[str, int]] = []
        for src_local, dst_local in copies:
            for tensor in tensors:
                if src_local < tensor.shape[0] and dst_local < tensor.shape[0]:
                    tensor[dst_local].copy_(tensor[src_local].clone())
            if (
                src_local < self.input_ids.gpu.shape[0]
                and dst_local < self.input_ids.gpu.shape[0]
            ):
                self.input_ids.gpu[dst_local].copy_(self.input_ids.gpu[src_local])
            positions = getattr(self, "positions", None)
            if (
                isinstance(positions, torch.Tensor)
                and src_local < positions.shape[0]
                and dst_local < positions.shape[0]
            ):
                positions[dst_local].copy_(positions[src_local].clone())
            if getattr(self, "uses_mrope", False):
                if (
                    src_local < self.mrope_positions.gpu.shape[1]
                    and dst_local < self.mrope_positions.gpu.shape[1]
                ):
                    self.mrope_positions.gpu[:, dst_local].copy_(
                        self.mrope_positions.gpu[:, src_local].clone()
                    )
                if (
                    src_local < self.mrope_positions.cpu.shape[1]
                    and dst_local < self.mrope_positions.cpu.shape[1]
                ):
                    self.mrope_positions.cpu[:, dst_local].copy_(
                        self.mrope_positions.cpu[:, src_local].clone()
                    )
            if getattr(self, "uses_xdrope_dim", 0) > 0:
                if (
                    src_local < self.xdrope_positions.gpu.shape[1]
                    and dst_local < self.xdrope_positions.gpu.shape[1]
                ):
                    self.xdrope_positions.gpu[:, dst_local].copy_(
                        self.xdrope_positions.gpu[:, src_local].clone()
                    )
                if (
                    src_local < self.xdrope_positions.cpu.shape[1]
                    and dst_local < self.xdrope_positions.cpu.shape[1]
                ):
                    self.xdrope_positions.cpu[:, dst_local].copy_(
                        self.xdrope_positions.cpu[:, src_local].clone()
                    )
            trace_records.append({"src_local": src_local, "dst_local": dst_local})
            copied += 1

        if _dflash_ddtree_trace_enabled():
            _dflash_ddtree_trace_event(
                "drafter_context_compact",
                {
                    "accepted_node_indices": (
                        copy_plan.accepted_rows
                        if copy_plan is not None
                        else accepted_node_indices.detach().cpu().tolist()
                    ),
                    "copies": trace_records,
                },
            )
        _dflash_ddtree_debug_log(
            "compacted drafter context copies=%d pairs=%s",
            copied,
            copies[:8],
        )

    def _update_streaming_request(
        self, req_id: str, new_req_data: NewRequestData
    ) -> CachedRequestState:
        """Updates streaming session request from `scheduled_new_reqs`.

        Removes the request from InputBatch (if present), updates the cached
        state, and prepares it for re-addition to the batch.

        NOTE: prompt_token_ids includes intermediate output tokens - tokens
        previously generated but now are input context (part of the prompt).
        """
        self.input_batch.remove_request(req_id)
        req_state = self.requests[req_id]

        req_state.prompt_token_ids = new_req_data.prompt_token_ids
        req_state.mm_features = new_req_data.mm_features
        req_state.prompt_embeds = new_req_data.prompt_embeds
        req_state.sampling_params = new_req_data.sampling_params
        req_state.pooling_params = new_req_data.pooling_params
        self.late_interaction_runner.register_request(req_id, req_state.pooling_params)
        req_state.block_ids = new_req_data.block_ids
        req_state.num_computed_tokens = new_req_data.num_computed_tokens
        req_state.num_prompt_tokens = length_from_prompt_token_ids_or_embeds(
            req_state.prompt_token_ids, req_state.prompt_embeds
        )

        # Clear `output_token_ids` as previous output tokens are now part of
        # `prompt_token_ids`.
        req_state.output_token_ids.clear()

        if self.uses_mrope:
            self._init_mrope_positions(req_state)

        return req_state

    def _init_mrope_positions(self, req_state: CachedRequestState):
        model = self.get_model()
        assert supports_mrope(model), "M-RoPE support is not implemented."
        assert req_state.prompt_token_ids is not None, (
            "M-RoPE requires prompt_token_ids to be available."
        )
        mrope_model = cast(SupportsMRoPE, model)

        # `prompt_embeds` is a passthrough modality (no grid_thw), models'
        # M-RoPE code assumes per-feature grid info, so filter it out. The
        # prompt_embeds positions are treated as text positions for M-RoPE.
        mrope_features = [
            f for f in req_state.mm_features if f.modality != "prompt_embeds"
        ]
        req_state.mrope_positions, req_state.mrope_position_delta = (
            mrope_model.get_mrope_input_positions(
                req_state.prompt_token_ids,
                mrope_features,
            )
        )

    def _init_xdrope_positions(self, req_state: CachedRequestState):
        model = self.get_model()
        xdrope_model = cast(SupportsXDRoPE, model)
        assert req_state.prompt_token_ids is not None, (
            "XD-RoPE requires prompt_token_ids to be available."
        )
        assert supports_xdrope(model), "XD-RoPE support is not implemented."

        req_state.xdrope_positions = xdrope_model.get_xdrope_input_positions(
            req_state.prompt_token_ids,
            req_state.mm_features,
        )

    def _extract_mm_kwargs(
        self,
        scheduler_output: "SchedulerOutput",
    ) -> BatchedTensorInputs:
        if not scheduler_output or not self.is_multimodal_raw_input_only_model:
            return {}

        mm_kwargs = list[tuple[str, MultiModalKwargsItem]]()
        for req in scheduler_output.scheduled_new_reqs:
            for feature in req.mm_features:
                if feature.data is not None:
                    mm_kwargs.append((feature.modality, feature.data))

        # Input all modalities at once
        mm_kwargs_combined: BatchedTensorInputs = {}
        for _, _, mm_kwargs_batch in group_and_batch_mm_kwargs(
            mm_kwargs,
            device=self.device,
            pin_memory=self.pin_memory,
        ):
            mm_kwargs_combined.update(mm_kwargs_batch)

        return mm_kwargs_combined

    def _dummy_mm_kwargs(self, num_seqs: int) -> BatchedTensorInputs:
        if not self.is_multimodal_raw_input_only_model:
            return {}

        mm_budget = self.mm_budget
        assert mm_budget is not None

        if not mm_budget.mm_max_toks_per_item:
            return {}  # No tower modalities (embed-only mode)

        dummy_modality = mm_budget.get_modality_with_max_tokens()
        return self._get_mm_dummy_batch(dummy_modality, num_seqs)

    def _get_cumsum_and_arange(
        self,
        num_tokens: np.ndarray,
        arange_out: np.ndarray,
        cumsum_dtype: np.dtype | None = None,
    ) -> np.ndarray:
        """Get the cumulative sum and batched arange of the given array.
        E.g., [2, 5, 3] -> [2, 7, 10], arange written to
        arange_out[:10] as [0, 1, 0, 1, 2, 3, 4, 0, 1, 2].
        Equivalent to but faster than:
        np.concatenate([np.arange(n) for n in num_tokens])
        """
        # Step 1. [2, 5, 3] -> [2, 7, 10]
        cu_num_tokens = np.cumsum(num_tokens, dtype=cumsum_dtype)
        total_num_tokens = cu_num_tokens[-1]
        # Step 2. [2, 7, 10] -> [0, 0, 2, 2, 2, 2, 2, 7, 7, 7]
        cumsums_offsets = np.repeat(cu_num_tokens - num_tokens, num_tokens)
        # Step 3. [0, 1, 0, 1, 2, 3, 4, 0, 1, 2]
        np.subtract(
            self.arange_np[:total_num_tokens],
            cumsums_offsets,
            out=arange_out[:total_num_tokens],
        )

        return cu_num_tokens

    def _compute_prev_positions(self, num_reqs: int) -> None:
        """Build prev_positions mapping: current pos -> previous pos (-1 if new).

        Populates self.prev_positions.np[:num_reqs] with the mapping.
        """
        prev_req_id_to_index = self.input_batch.prev_req_id_to_index
        prev_positions = self.prev_positions.np[:num_reqs]

        if not prev_req_id_to_index:
            prev_positions.fill(-1)
            return

        for i, req_id in enumerate(self.input_batch.req_ids[:num_reqs]):
            prev_positions[i] = prev_req_id_to_index.get(req_id, -1)

    def _apply_ddtree_position_overrides(
        self,
        scheduler_output: "SchedulerOutput",
        num_reqs: int,
        num_scheduled_tokens: np.ndarray,
        cu_num_tokens: np.ndarray,
    ) -> None:
        payloads = scheduler_output.scheduled_ddtree_payloads
        if not payloads or self.uses_xdrope_dim > 0:
            return

        req_starts = np.empty(num_reqs, dtype=np.int64)
        req_starts[0] = 0
        if num_reqs > 1:
            req_starts[1:] = cu_num_tokens[:-1]

        for req_idx, req_id in enumerate(self.input_batch.req_ids[:num_reqs]):
            payload = payloads.get(req_id)
            if payload is None or not payload.tree_token_ids:
                continue
            scheduled_spec_tokens = scheduler_output.scheduled_spec_decode_tokens.get(
                req_id,
                (),
            )
            if tuple(scheduled_spec_tokens) != tuple(payload.tree_token_ids):
                continue

            draft_len = len(scheduled_spec_tokens)
            req_num_tokens = int(num_scheduled_tokens[req_idx])
            if draft_len <= 0 or req_num_tokens < draft_len + 1:
                continue

            sample_start = int(req_starts[req_idx] + req_num_tokens - draft_len - 1)
            tree_start = sample_start + 1
            tree_end = tree_start + len(payload.node_depths)
            if tree_end > int(cu_num_tokens[req_idx]):
                continue

            depths = torch.tensor(
                payload.node_depths,
                dtype=torch.int64,
                device=self.positions.device,
            )
            self.positions[tree_start:tree_end].copy_(
                self.positions[sample_start].to(torch.int64) + depths
            )
            positions_cpu = getattr(self, "_current_positions_cpu_sidecar", None)
            if positions_cpu is not None and tree_end <= len(positions_cpu):
                positions_cpu[tree_start:tree_end] = int(
                    positions_cpu[sample_start]
                ) + np.asarray(payload.node_depths, dtype=np.int64)
            if self.uses_mrope:
                root_positions = self.mrope_positions.np[:, sample_start].copy()
                self.mrope_positions.np[:, tree_start:tree_end] = (
                    root_positions[:, None]
                    + np.asarray(payload.node_depths, dtype=np.int64)[None, :]
                )

    def _prepare_input_ids(
        self,
        scheduler_output: "SchedulerOutput",
        num_reqs: int,
        total_num_scheduled_tokens: int,
        cu_num_tokens: np.ndarray,
    ) -> None:
        """Prepare the input IDs for the current batch.

        Carefully handles the `prev_sampled_token_ids` which can be cached
        from the previous engine iteration, in which case those tokens on the
        GPU need to be copied into the corresponding slots into input_ids.

        Uses self.prev_positions[:num_reqs] which maps current pos -> prev pos
        (-1 for new requests).
        """

        if self.input_batch.prev_sampled_token_ids is None:
            # Normal scheduling case
            self._copy_buffer_to_gpu(self.input_ids, total_num_scheduled_tokens)
            if self.enable_prompt_embeds:
                self._copy_buffer_to_gpu(self.inputs_embeds, total_num_scheduled_tokens)
                self._copy_buffer_to_gpu(self.is_token_ids, total_num_scheduled_tokens)
            return

        # Async scheduling case, where some decode requests from the previous
        # iteration won't have entries in input_ids_cpu and need to be copied
        # on the GPU from prev_sampled_token_ids.
        prev_positions = self.prev_positions.np[:num_reqs]
        scheduled_spec_tokens = scheduler_output.scheduled_spec_decode_tokens
        sample_flattened_indices: list[int] = []
        spec_flattened_indices: list[int] = []
        prev_draft_token_indices: list[int] = []
        prev_indices: list[int] = []
        common_indices_match = True
        max_flattened_index = -1
        total_num_spec_tokens = 0

        for cur_index in range(num_reqs):
            prev_index = prev_positions[cur_index]
            if prev_index < 0:
                continue
            prev_indices.append(prev_index)
            req_id = self.input_batch.req_ids[cur_index]
            # We need to compute the flattened input_ids index of the
            # last token in each common request.
            draft_len = len(scheduled_spec_tokens.get(req_id, ()))
            total_num_spec_tokens += draft_len
            flattened_index = cu_num_tokens[cur_index].item() - 1
            # example: cu_num_tokens = [2, 5, 8], draft_tokens = [1, 2, 2]
            # sample_flattened_indices = [0, 2, 5]
            # spec_flattened_indices = [1,   3, 4,    6, 7]
            sample_flattened_indices.append(flattened_index - draft_len)
            spec_flattened_indices.extend(
                range(flattened_index - draft_len + 1, flattened_index + 1)
            )
            start = prev_index * self.num_spec_tokens
            # prev_draft_token_indices is used to find which draft_tokens_id
            # should be copied to input_ids
            # example: prev draft_tokens_id [[1,2], [3,4], [5, 6]]
            # flatten draft_tokens_id [1,2,3,4,5,6]
            # draft_len of each request [1, 2, 1]
            # then prev_draft_token_indices is [0,   2, 3,   4]
            prev_draft_token_indices.extend(range(start, start + draft_len))
            common_indices_match &= prev_index == flattened_index
            max_flattened_index = max(max_flattened_index, flattened_index)

        num_common_tokens = len(sample_flattened_indices)
        total_without_spec = total_num_scheduled_tokens - total_num_spec_tokens
        if num_common_tokens < total_without_spec:
            # If not all requests are decodes from the last iteration,
            # we need to copy the input_ids_cpu to the GPU first.
            self._copy_buffer_to_gpu(self.input_ids, total_num_scheduled_tokens)
            if self.enable_prompt_embeds:
                self._copy_buffer_to_gpu(self.inputs_embeds, total_num_scheduled_tokens)
                self._copy_buffer_to_gpu(self.is_token_ids, total_num_scheduled_tokens)
        if num_common_tokens == 0:
            # No requests in common with the previous iteration
            # So input_ids.cpu will have all the input ids.
            return
        if common_indices_match and max_flattened_index == (num_common_tokens - 1):
            # Common-case optimization: the batch is unchanged
            # and no reordering happened.
            # The indices are both the same permutation of 0..N-1 so
            # we can copy directly using a single slice.
            self.input_ids.gpu[:num_common_tokens].copy_(
                self.input_batch.prev_sampled_token_ids[:num_common_tokens, 0],
                non_blocking=True,
            )
            return
        # Upload the index tensors asynchronously so the scatter can be non-blocking.
        sampled_tokens_index_tensor = torch.tensor(
            sample_flattened_indices, dtype=torch.int64, pin_memory=self.pin_memory
        ).to(self.device, non_blocking=True)
        prev_common_req_indices_tensor = torch.tensor(
            prev_indices, dtype=torch.int64, pin_memory=self.pin_memory
        ).to(self.device, non_blocking=True)
        self.input_ids.gpu.scatter_(
            dim=0,
            index=sampled_tokens_index_tensor,
            src=self.input_batch.prev_sampled_token_ids[
                prev_common_req_indices_tensor, 0
            ],
        )

        # Scatter the draft tokens after the sampled tokens are scattered.
        if not spec_flattened_indices:
            return

        if self._draft_token_ids is None:
            raise RuntimeError(
                "Speculative decode scheduled draft input slots, but the "
                "worker has no draft token tensor to scatter. Continuing would "
                "reuse stale GPU input_ids and can corrupt generation."
            )

        if not isinstance(self._draft_token_ids, torch.Tensor):
            raise RuntimeError(
                "Speculative decode scheduled draft input slots, but the "
                f"worker draft tokens are {type(self._draft_token_ids).__name__} "
                "instead of a tensor. The scheduler must trim invalid draft "
                "slots before target verification."
            )

        draft_tokens_index_tensor = torch.tensor(
            spec_flattened_indices, dtype=torch.int64, pin_memory=self.pin_memory
        ).to(self.device, non_blocking=True)
        if prev_draft_token_indices:
            max_prev_draft_index = max(prev_draft_token_indices)
            if max_prev_draft_index >= self._draft_token_ids.numel():
                raise RuntimeError(
                    "Speculative decode scheduled more draft input slots than "
                    "the worker produced: "
                    f"required_flat_index={max_prev_draft_index}, "
                    f"available={self._draft_token_ids.numel()}."
                )
        prev_draft_token_indices_tensor = torch.tensor(
            prev_draft_token_indices, dtype=torch.int64, pin_memory=self.pin_memory
        ).to(self.device, non_blocking=True)

        # because input_ids dtype is torch.int32,
        # so convert draft_token_ids to torch.int32 here.
        draft_token_ids = self._draft_token_ids.to(dtype=torch.int32)

        self.input_ids.gpu.scatter_(
            dim=0,
            index=draft_tokens_index_tensor,
            src=draft_token_ids.flatten()[prev_draft_token_indices_tensor],
        )

    def _get_encoder_seq_lens(
        self,
        num_scheduled_tokens: dict[str, int],
        kv_cache_spec: KVCacheSpec,
        num_reqs: int,
        for_cudagraph_capture: bool = False,
    ) -> tuple[torch.Tensor | None, np.ndarray | None]:
        if not isinstance(kv_cache_spec, CrossAttentionSpec):
            return None, None

        # Zero out buffer for padding requests that are not actually scheduled (CGs)
        self.encoder_seq_lens.np[:num_reqs] = 0

        # Build encoder_seq_lens array mapping request indices to
        # encoder lengths for inputs scheduled in this batch
        for req_id in num_scheduled_tokens:
            req_index = self.input_batch.req_id_to_index[req_id]
            req_state = self.requests[req_id]
            if req_state.mm_features is None:
                self.encoder_seq_lens.np[req_index] = 0
                continue

            # Get the total number of encoder input tokens for running encoder requests
            # whether encoding is finished or not so that cross-attention knows how
            # many encoder tokens to attend to.
            encoder_input_tokens = sum(
                feature.mm_position.length for feature in req_state.mm_features
            )
            self.encoder_seq_lens.np[req_index] = encoder_input_tokens
        if for_cudagraph_capture:
            # During CUDA graph capture, we need to use realistic encoder lengths
            # so that max_seqlen_k is captured with the correct value.
            max_encoder_len = getattr(
                self.model_config.hf_config,
                "max_source_positions",
                self.max_encoder_len,
            )
            self.encoder_seq_lens.np[:num_reqs] = max_encoder_len

        self._copy_buffer_to_gpu(self.encoder_seq_lens, num_reqs)
        encoder_seq_lens = self.encoder_seq_lens.gpu[:num_reqs]
        encoder_seq_lens_cpu = self.encoder_seq_lens.np[:num_reqs]

        return encoder_seq_lens, encoder_seq_lens_cpu

    def _sync_mamba_accepted_token_state(
        self,
        scheduler_output: "SchedulerOutput",
        num_reqs: int,
    ) -> None:
        """Remap the previous step's accepted-token state by request.

        The GPU postprocess copies into runner-owned CPU buffers. InputBatch
        rows can be removed, reused, or condensed before this synchronization,
        so row-for-row writeback is not safe even with synchronous scheduling.
        """
        previous_counts = self.num_accepted_tokens.np.copy()
        previous_selectors = self.spec_state_slot_selectors.np.copy()
        previous_rows = self._mamba_accepted_token_state_rows
        reset_req_ids = set(scheduler_output.scheduled_cached_reqs.resumed_req_ids)
        reset_req_ids.update(
            req_data.req_id for req_data in scheduler_output.scheduled_new_reqs
        )

        current_counts = self.num_accepted_tokens.np[:num_reqs]
        current_selectors = self.spec_state_slot_selectors.np[:num_reqs]
        for current_idx, req_id in enumerate(self.input_batch.req_ids[:num_reqs]):
            previous = previous_rows.get(req_id)
            if (
                previous is not None
                and req_id not in reset_req_ids
                and self.requests.get(req_id) is previous[1]
            ):
                previous_idx = previous[0]
                current_counts[current_idx] = previous_counts[previous_idx]
                current_selectors[current_idx] = previous_selectors[previous_idx]
            else:
                # A new/restored request has no accepted speculative prefix.
                current_counts[current_idx] = 1
                current_selectors[current_idx] = 1

        self.input_batch.num_accepted_tokens_cpu[:num_reqs] = current_counts
        self.input_batch.spec_num_accepted_tokens_cpu[:num_reqs] = current_selectors

    def _prepare_inputs(
        self,
        scheduler_output: "SchedulerOutput",
        num_scheduled_tokens: np.ndarray,
    ) -> tuple[
        torch.Tensor,
        SpecDecodeMetadata | None,
    ]:
        """
        :return: tuple[
            logits_indices, spec_decode_metadata,
        ]
        """
        total_num_scheduled_tokens = scheduler_output.total_num_scheduled_tokens
        assert total_num_scheduled_tokens > 0
        num_reqs = self.input_batch.num_reqs
        assert num_reqs > 0
        profile_inputs = _dflash_ddtree_worker_profile_enabled()
        profile_prepare_t0 = time.perf_counter() if profile_inputs else 0.0
        profile_parent_ms = 0.0
        profile_block_commit_ms = 0.0
        profile_cpu_index_ms = 0.0
        profile_input_select_ms = 0.0
        profile_attention_base_ms = 0.0
        profile_state_sync_ms = 0.0
        profile_gpu_position_slot_ms = 0.0
        profile_num_computed_ms = 0.0
        profile_req_copy_ms = 0.0
        profile_positions_ms = 0.0
        profile_slot_mapping_inner_ms = 0.0
        profile_ddtree_override_ms = 0.0
        profile_prepare_input_ids_ms = 0.0
        profile_spec_metadata_ms = 0.0
        self._ddtree_parent_metadata = None
        self._current_positions_cpu_sidecar = None
        self._current_req_indices_cpu_sidecar = None
        spec_config = self.speculative_config
        profile_stage_t0 = time.perf_counter() if profile_inputs else 0.0
        if (
            spec_config is not None
            and spec_config.use_dflash_ddtree()
            and not spec_config.ddtree_disable_tree_verify
        ):
            ddtree_budget = spec_config.ddtree_budget or self.num_spec_tokens
            self._ddtree_parent_metadata = build_padded_parent_ids(
                self.input_batch.req_ids[:num_reqs],
                scheduler_output.scheduled_ddtree_payloads,
                device="cpu",
                pad_to=ddtree_budget + 1,
            )
            self._ddtree_parent_metadata = self._stage_ddtree_parent_metadata(
                self._ddtree_parent_metadata,
                num_reqs=num_reqs,
            )
        if profile_inputs:
            profile_parent_ms = (time.perf_counter() - profile_stage_t0) * 1000.0

        # OPTIMIZATION: Start copying the block table first.
        # This way, we can overlap the copy with the following CPU operations.
        profile_stage_t0 = time.perf_counter() if profile_inputs else 0.0
        self._commit_block_table_to_gpu(num_reqs)
        if profile_inputs:
            profile_block_commit_ms = (time.perf_counter() - profile_stage_t0) * 1000.0

        # Get request indices.
        # E.g., [2, 5, 3] -> [0, 0, 1, 1, 1, 1, 1, 2, 2, 2]
        profile_stage_t0 = time.perf_counter() if profile_inputs else 0.0
        req_indices = np.repeat(self.arange_np[:num_reqs], num_scheduled_tokens)

        # cu_num_tokens: [2, 5, 3] -> [2, 7, 10]
        # self.query_pos.np[:10]: [0, 1, 0, 1, 2, 3, 4, 0, 1, 2]
        cu_num_tokens = self._get_cumsum_and_arange(
            num_scheduled_tokens, self.query_pos.np
        )

        # Get positions.
        positions_np = (
            self.input_batch.num_computed_tokens_cpu[req_indices]
            + self.query_pos.np[: cu_num_tokens[-1]]
        )
        self._current_positions_cpu_sidecar = positions_np.astype(np.int64, copy=True)
        self._current_req_indices_cpu_sidecar = req_indices.astype(np.int64, copy=True)

        # Calculate M-RoPE positions.
        # Only relevant for models using M-RoPE (e.g, Qwen2-VL)
        if self.uses_mrope:
            self._calc_mrope_positions(scheduler_output)

        # Calculate XD-RoPE positions.
        # Only relevant for models using XD-RoPE (e.g, HunYuan-VL)
        if self.uses_xdrope_dim > 0:
            self._calc_xdrope_positions(scheduler_output)

        # Get token indices.
        # E.g., [0, 1, 0, 1, 2, 3, 4, 0, 1, 2]
        # -> [0, 1, M, M + 1, M + 2, M + 3, M + 4, 2 * M, 2 * M + 1, 2 * M + 2]
        # where M is the max_model_len.
        token_indices = (
            positions_np + req_indices * self.input_batch.token_ids_cpu.shape[1]
        )
        token_indices_tensor = torch.from_numpy(token_indices)
        if profile_inputs:
            profile_cpu_index_ms = (time.perf_counter() - profile_stage_t0) * 1000.0

        # NOTE(woosuk): We use torch.index_select instead of np.take here
        # because torch.index_select is much faster than np.take for large
        # tensors.
        profile_stage_t0 = time.perf_counter() if profile_inputs else 0.0
        torch.index_select(
            self.input_batch.token_ids_cpu_tensor.flatten(),
            0,
            token_indices_tensor,
            out=self.input_ids.cpu[:total_num_scheduled_tokens],
        )
        if self.enable_prompt_embeds:
            is_token_ids = self.input_batch.is_token_ids_tensor.flatten()
            torch.index_select(
                is_token_ids,
                0,
                token_indices_tensor,
                out=self.is_token_ids.cpu[:total_num_scheduled_tokens],
            )

        # Because we did not pre-allocate a massive prompt_embeds CPU tensor on
        # the InputBatch, we need to fill in the prompt embeds into the expected
        # spots in the GpuModelRunner's pre-allocated prompt_embeds tensor.
        if self.input_batch.req_prompt_embeds:
            output_idx = 0
            for req_idx in range(num_reqs):
                num_sched = num_scheduled_tokens[req_idx]

                # Skip if this request doesn't have embeddings
                if req_idx not in self.input_batch.req_prompt_embeds:
                    output_idx += num_sched
                    continue

                # Skip if no tokens scheduled
                if num_sched <= 0:
                    output_idx += num_sched
                    continue

                req_embeds = self.input_batch.req_prompt_embeds[req_idx]
                start_pos = self.input_batch.num_computed_tokens_cpu[req_idx]

                # Skip if trying to read beyond available embeddings
                if start_pos >= req_embeds.shape[0]:
                    output_idx += num_sched
                    continue

                # Copy available embeddings
                end_pos = start_pos + num_sched
                actual_end = min(end_pos, req_embeds.shape[0])
                actual_num_sched = actual_end - start_pos

                if actual_num_sched > 0:
                    self.inputs_embeds.cpu[
                        output_idx : output_idx + actual_num_sched
                    ].copy_(req_embeds[start_pos:actual_end])

                output_idx += num_sched

        # Prepare the attention metadata.
        if profile_inputs:
            profile_input_select_ms = (time.perf_counter() - profile_stage_t0) * 1000.0
        profile_stage_t0 = time.perf_counter() if profile_inputs else 0.0
        self.query_start_loc.np[0] = 0
        self.query_start_loc.np[1 : num_reqs + 1] = cu_num_tokens
        # Note: pad query_start_loc to be non-decreasing, as kernels
        # like FlashAttention requires that
        self.query_start_loc.np[num_reqs + 1 :].fill(cu_num_tokens[-1])
        self._copy_buffer_to_gpu(self.query_start_loc)
        query_start_loc = self.query_start_loc.gpu[: num_reqs + 1]

        # Compute optimistic seq_lens (assumes all draft tokens from previous
        # iteration accepted). Store in optimistic_seq_lens_cpu for use by
        # _build_attention_metadata (max_seq_len) and discard_request_mask.
        # seq_lens (GPU) will be computed later using the same optimistic values.
        torch.add(
            self.input_batch.num_computed_tokens_cpu_tensor[:num_reqs],
            torch.from_numpy(num_scheduled_tokens),
            out=self.optimistic_seq_lens_cpu[:num_reqs],
        )
        self.optimistic_seq_lens_cpu[num_reqs:].fill_(0)

        # Build prev_positions mapping: current pos -> prev pos (-1 if new).
        # Used for gathering from previous iteration's GPU tensors.
        prev_req_id_to_index = self.input_batch.prev_req_id_to_index
        self._compute_prev_positions(num_reqs)

        num_tokens = [self.requests[r].num_tokens for r in self.input_batch.req_ids]
        num_tokens_np = np.array(num_tokens, dtype=np.int32)

        # Record which requests should not be sampled,
        # so that we could clear the sampled tokens before returning
        self.discard_request_mask.np[:num_reqs] = (
            self.optimistic_seq_lens_cpu[:num_reqs].numpy() < num_tokens_np
        )
        self._copy_buffer_to_gpu(self.discard_request_mask, num_reqs)
        if profile_inputs:
            profile_attention_base_ms = (
                time.perf_counter() - profile_stage_t0
            ) * 1000.0

        # Sync num_accepted_tokens from CPU (set by
        # _update_states_after_model_execute for hybrid models).
        profile_stage_t0 = time.perf_counter() if profile_inputs else 0.0
        if self.num_accepted_tokens_event is not None:
            self._event_tracer.synchronize(
                self.num_accepted_tokens_event,
                "GPUModelRunner.num_accepted_tokens_event.synchronize",
            )
            self._sync_mamba_accepted_token_state(scheduler_output, num_reqs)
            self.num_accepted_tokens.np[num_reqs:].fill(1)
            self.spec_state_slot_selectors.np[num_reqs:].fill(1)
            self._copy_buffer_to_gpu(self.num_accepted_tokens)
            self._copy_buffer_to_gpu(self.spec_state_slot_selectors)
        else:
            self.num_accepted_tokens.np.fill(1)
            self.num_accepted_tokens.gpu.fill_(1)
            self.spec_state_slot_selectors.np.fill(1)
            self.spec_state_slot_selectors.gpu.fill_(1)

        if self.mamba_prev_last_scheduled_idx is not None:
            mamba_utils.preprocess_mamba_all_specdec(
                scheduler_output,
                self.input_batch,
                self.mamba_state_idx,
                num_reqs,
                self.mamba_prev_last_scheduled_idx,
            )
        if profile_inputs:
            profile_state_sync_ms = (time.perf_counter() - profile_stage_t0) * 1000.0

        # Update num_computed_tokens on GPU. In async spec decode,
        # CPU values are optimistic (all drafts accepted). The kernel
        # corrects on GPU using the previous step's
        # valid_sampled_token_count_gpu. Otherwise, just copy from CPU.
        profile_stage_t0 = time.perf_counter() if profile_inputs else 0.0
        profile_inner_t0 = profile_stage_t0
        participating_prev_positions = (
            _async_spec_decode_participating_prev_positions(
                self.prev_positions.np[:num_reqs],
                self.prev_num_draft_tokens.np,
            )
            if self.use_async_spec_decode and prev_req_id_to_index
            else np.empty(0, dtype=np.int32)
        )
        if (
            self.use_async_spec_decode
            and self.valid_sampled_token_count_gpu is not None
            and prev_req_id_to_index
            and participating_prev_positions.size > 0
        ):
            max_prev_position = int(participating_prev_positions.max())
            if max_prev_position >= self.valid_sampled_token_count_gpu.shape[0]:
                raise RuntimeError(
                    "Async speculative decode draft-count state is inconsistent: "
                    f"required previous row {max_prev_position}, but valid sampled "
                    "token counts contain only "
                    f"{self.valid_sampled_token_count_gpu.shape[0]} rows."
                )
            self._copy_buffer_to_gpu(self.prev_positions, num_reqs)
            self._copy_buffer_to_gpu(self.prev_num_draft_tokens)
            cpu_values = self.input_batch.num_computed_tokens_cpu_tensor[:num_reqs].to(
                device=self.device, non_blocking=True
            )
            update_num_computed_tokens_for_batch_change(
                self.num_computed_tokens,
                self.num_accepted_tokens.gpu[:num_reqs],
                self.prev_positions.gpu[:num_reqs],
                self.valid_sampled_token_count_gpu,
                self.prev_num_draft_tokens.gpu,
                cpu_values,
            )
        else:
            self.num_computed_tokens[:num_reqs].copy_(
                self.input_batch.num_computed_tokens_cpu_tensor[:num_reqs],
                non_blocking=True,
            )
        if profile_inputs:
            profile_num_computed_ms = (time.perf_counter() - profile_inner_t0) * 1000.0

        profile_inner_t0 = time.perf_counter() if profile_inputs else 0.0
        self.req_indices.np[:total_num_scheduled_tokens] = req_indices
        self._copy_buffer_to_gpu(self.req_indices, total_num_scheduled_tokens)
        req_indices_gpu = self.req_indices.gpu[:total_num_scheduled_tokens]

        self._copy_buffer_to_gpu(self.query_pos, total_num_scheduled_tokens)
        self.num_scheduled_tokens.np[:num_reqs] = num_scheduled_tokens
        self._copy_buffer_to_gpu(self.num_scheduled_tokens, num_reqs)
        num_scheduled_tokens_gpu = self.num_scheduled_tokens.gpu[:num_reqs]
        if profile_inputs:
            profile_req_copy_ms = (time.perf_counter() - profile_inner_t0) * 1000.0

        profile_inner_t0 = time.perf_counter() if profile_inputs else 0.0
        self.positions[:total_num_scheduled_tokens] = (
            self.num_computed_tokens[req_indices_gpu].to(torch.int64)
            + self.query_pos.gpu[:total_num_scheduled_tokens]
        )
        self.seq_lens[:num_reqs] = (
            self.num_computed_tokens[:num_reqs] + num_scheduled_tokens_gpu
        )
        self.seq_lens[num_reqs:].fill_(0)
        if profile_inputs:
            profile_positions_ms = (time.perf_counter() - profile_inner_t0) * 1000.0

        profile_inner_t0 = time.perf_counter() if profile_inputs else 0.0
        for group_id, kv_cache_group in enumerate(self.kv_cache_config.kv_cache_groups):
            kv_cache_spec = kv_cache_group.kv_cache_spec
            is_circular = isinstance(kv_cache_spec, CircularBufferSpec)
            if isinstance(kv_cache_spec, UniformTypeKVCacheSpecs):
                is_circular = all(
                    isinstance(spec, CircularBufferSpec)
                    for spec in kv_cache_spec.kv_cache_specs.values()
                )
            block_table = self.input_batch.block_table[group_id]
            if is_circular:
                # QSA derives ring slots from logical positions in its own
                # metadata builder. Generic mapping would index beyond the
                # ring's single block-table column.
                block_table.slot_mapping.gpu.fill_(PAD_SLOT_ID)
                continue
            block_table.compute_slot_mapping(
                num_reqs,
                self.query_start_loc.gpu[: num_reqs + 1],
                self.positions[:total_num_scheduled_tokens],
            )
        if profile_inputs:
            profile_slot_mapping_inner_ms = (
                time.perf_counter() - profile_inner_t0
            ) * 1000.0

        profile_inner_t0 = time.perf_counter() if profile_inputs else 0.0
        self._apply_ddtree_position_overrides(
            scheduler_output,
            num_reqs,
            num_scheduled_tokens,
            cu_num_tokens,
        )
        if profile_inputs:
            profile_ddtree_override_ms = (
                time.perf_counter() - profile_inner_t0
            ) * 1000.0
        if profile_inputs:
            profile_gpu_position_slot_ms = (
                time.perf_counter() - profile_stage_t0
            ) * 1000.0

        # Copy the tensors to the GPU.
        profile_stage_t0 = time.perf_counter() if profile_inputs else 0.0
        self._prepare_input_ids(
            scheduler_output,
            num_reqs,
            total_num_scheduled_tokens,
            cu_num_tokens,
        )
        if profile_inputs:
            profile_prepare_input_ids_ms = (
                time.perf_counter() - profile_stage_t0
            ) * 1000.0

        if self.uses_mrope:
            # Only relevant for models using M-RoPE (e.g, Qwen2-VL)
            self._copy_position_buffer_to_gpu(
                self.mrope_positions, total_num_scheduled_tokens
            )
        elif self.uses_xdrope_dim > 0:
            # Only relevant for models using XD-RoPE (e.g, HunYuan-VL)
            self._copy_position_buffer_to_gpu(
                self.xdrope_positions, total_num_scheduled_tokens
            )
        if self.use_async_spec_decode and (self.uses_mrope or self.uses_xdrope_dim > 0):
            drift = self.num_computed_tokens[req_indices_gpu].to(
                torch.int64
            ) - self.input_batch.num_computed_tokens_cpu_tensor[req_indices].to(
                device=self.device, dtype=torch.int64, non_blocking=True
            )
            target = self.mrope_positions if self.uses_mrope else self.xdrope_positions
            target.gpu[:, :total_num_scheduled_tokens] += drift

        use_spec_decode = len(scheduler_output.scheduled_spec_decode_tokens) > 0
        profile_stage_t0 = time.perf_counter() if profile_inputs else 0.0
        if not use_spec_decode:
            # NOTE(woosuk): Due to chunked prefills, the batch may contain
            # partial requests. While we should not sample any token
            # from these partial requests, we do so for simplicity.
            # We will ignore the sampled tokens from the partial requests.
            # TODO: Support prompt logprobs.
            logits_indices = query_start_loc[1:] - 1
            spec_decode_metadata = None
            num_sampled_tokens = np.ones(num_reqs, dtype=np.int32)
        else:
            # Get the number of draft tokens for each request.
            # Iterate over the dictionary rather than all requests since not all
            # requests have draft tokens.
            num_draft_tokens = np.zeros(num_reqs, dtype=np.int32)
            # For chunked prefills, use -1 as mask rather than 0, as guided
            # decoding may rollback speculative tokens.
            num_decode_draft_tokens = np.full(num_reqs, -1, dtype=np.int32)
            for (
                req_id,
                draft_token_ids,
            ) in scheduler_output.scheduled_spec_decode_tokens.items():
                req_idx = self.input_batch.req_id_to_index[req_id]
                draft_len = len(draft_token_ids)
                # _calc_spec_decode_metadata places a request's sampled rows at
                # [cumulative_end - (draft_len + 1), cumulative_end). Fewer
                # query rows than that would silently select the preceding
                # request's hidden states.
                assert num_scheduled_tokens[req_idx] >= draft_len + 1
                num_draft_tokens[req_idx] = draft_len
                if (
                    self.input_batch.num_computed_tokens_cpu[req_idx]
                    >= self.input_batch.num_prompt_tokens[req_idx]
                ):
                    num_decode_draft_tokens[req_idx] = draft_len
            spec_decode_metadata = self._calc_spec_decode_metadata(
                num_draft_tokens, cu_num_tokens
            )
            logits_indices = spec_decode_metadata.logits_indices
            num_sampled_tokens = num_draft_tokens + 1
            # For DECODE only cuda graph of some attention backends (e.g., GDN).
            self.num_decode_draft_tokens.np[:num_reqs] = num_decode_draft_tokens
            self.num_decode_draft_tokens.np[num_reqs:].fill(-1)
            self._copy_buffer_to_gpu(self.num_decode_draft_tokens)
        if profile_inputs:
            profile_spec_metadata_ms = (time.perf_counter() - profile_stage_t0) * 1000.0

        # Hot-Swap lora model
        if self.lora_config:
            assert (
                np.sum(num_sampled_tokens)
                <= self.vllm_config.scheduler_config.max_num_batched_tokens
            )
            self.set_active_loras(
                self.input_batch, num_scheduled_tokens, num_sampled_tokens
            )
        if profile_inputs:
            logger.info(
                "DFLASH_DDTREE_WORKER_PROFILE prepare_inputs_split "
                "total_ms=%.3f parent_ms=%.3f block_commit_ms=%.3f "
                "cpu_index_ms=%.3f input_select_ms=%.3f "
                "attention_base_ms=%.3f state_sync_ms=%.3f "
                "gpu_position_slot_ms=%.3f prepare_input_ids_ms=%.3f "
                "spec_metadata_ms=%.3f num_computed_ms=%.3f "
                "req_copy_ms=%.3f positions_ms=%.3f "
                "slot_mapping_inner_ms=%.3f ddtree_override_ms=%.3f "
                "num_reqs=%d scheduled_tokens=%d spec=%s ddtree=%s",
                (time.perf_counter() - profile_prepare_t0) * 1000.0,
                profile_parent_ms,
                profile_block_commit_ms,
                profile_cpu_index_ms,
                profile_input_select_ms,
                profile_attention_base_ms,
                profile_state_sync_ms,
                profile_gpu_position_slot_ms,
                profile_prepare_input_ids_ms,
                profile_spec_metadata_ms,
                profile_num_computed_ms,
                profile_req_copy_ms,
                profile_positions_ms,
                profile_slot_mapping_inner_ms,
                profile_ddtree_override_ms,
                num_reqs,
                total_num_scheduled_tokens,
                use_spec_decode,
                self._ddtree_parent_metadata is not None,
            )

        return (
            logits_indices,
            spec_decode_metadata,
        )

    def _build_attention_metadata(
        self,
        num_tokens: int,
        num_reqs: int,
        max_query_len: int,
        num_tokens_padded: int | None = None,
        num_reqs_padded: int | None = None,
        ubatch_slices: UBatchSlices | None = None,
        logits_indices: torch.Tensor | None = None,
        use_spec_decode: bool = False,
        for_cudagraph_capture: bool = False,
        num_scheduled_tokens: dict[str, int] | None = None,
        cascade_attn_prefix_lens: list[list[int]] | None = None,
        slot_mappings: dict[int, torch.Tensor] | None = None,
        ddtree_parent_metadata: DDTreeParentMetadata | None = None,
        cudagraph_capture_max_seq_len: int | None = None,
        cudagraph_graph_variant: int | None = None,
        is_dummy_batch: bool = False,
    ) -> tuple[PerLayerAttnMetadata, CommonAttentionMetadata | None]:
        """
        :return: tuple[attn_metadata, spec_decode_common_attn_metadata]
        """
        # Attention metadata is not needed for attention free models
        if len(self.kv_cache_config.kv_cache_groups) == 0:
            return {}, None

        num_tokens_padded = num_tokens_padded or num_tokens
        num_reqs_padded = num_reqs_padded or num_reqs
        assert num_reqs_padded is not None and num_tokens_padded is not None
        ddtree_parent_metadata = self._stage_ddtree_parent_metadata(
            ddtree_parent_metadata,
            num_reqs=num_reqs,
            num_reqs_padded=num_reqs_padded,
        )

        attn_metadata: PerLayerAttnMetadata = {}
        if ubatch_slices is not None:
            attn_metadata = [dict() for _ in range(len(ubatch_slices))]

        if for_cudagraph_capture:
            # For some attention backends (e.g. FA) with sliding window models we need
            # to make sure the backend see a max_seq_len that is larger to the sliding
            # window size when capturing to make sure the correct kernel is selected.
            max_seq_len = (
                min(self.max_model_len, cudagraph_capture_max_seq_len)
                if cudagraph_capture_max_seq_len is not None
                else self.max_model_len
            )
        else:
            max_seq_len = self.optimistic_seq_lens_cpu.numpy()[:num_reqs].max().item()

        if use_spec_decode:
            self.num_accepted_tokens.np[:num_reqs] = (
                self.input_batch.num_accepted_tokens_cpu[:num_reqs]
            )
            self.spec_state_slot_selectors.np[:num_reqs] = (
                self.input_batch.spec_num_accepted_tokens_cpu[:num_reqs]
            )
            self.num_accepted_tokens.np[num_reqs:].fill(1)
            self.spec_state_slot_selectors.np[num_reqs:].fill(1)
            self._copy_buffer_to_gpu(self.num_accepted_tokens, num_reqs_padded)
            self._copy_buffer_to_gpu(self.spec_state_slot_selectors, num_reqs_padded)

        kv_cache_groups = self.kv_cache_config.kv_cache_groups

        def _get_block_table(kv_cache_gid: int):
            assert num_reqs_padded is not None and num_tokens_padded is not None
            kv_cache_spec = kv_cache_groups[kv_cache_gid].kv_cache_spec
            if isinstance(kv_cache_spec, EncoderOnlyAttentionSpec):
                blk_table_tensor = torch.zeros(
                    (num_reqs_padded, 1),
                    dtype=torch.int32,
                    device=self.device,
                )
            else:
                blk_table = self.input_batch.block_table[kv_cache_gid]
                blk_table_tensor = blk_table.get_device_tensor(num_reqs_padded)

            # Fill unused block table entries with NULL_BLOCK_ID (null block)
            # for CUDAGraph padding. Block 0 is reserved for padding.
            blk_table_tensor[num_reqs:num_reqs_padded].fill_(NULL_BLOCK_ID)
            return blk_table_tensor

        assert slot_mappings is not None
        block_table_gid_0 = _get_block_table(0)
        slot_mapping_gid_0 = slot_mappings[0]

        if self.routed_experts_initialized:
            # Copy this step's attention slot_mapping into our private
            # device buffer. The shared ``slot_mappings[attn_gid]`` is
            # owned by the attention block table and will be overwritten
            # by the next ``_prepare_inputs``; we need a stable snapshot
            # because the async D2H may still be in flight on the copy
            # stream when the next step runs.
            attn_gid = self.routed_experts_attn_gid
            slot_mapping_attn = slot_mappings[attn_gid]
            self.routed_experts_slot_mapping_device[:num_tokens].copy_(
                slot_mapping_attn[:num_tokens]
            )

        num_computed_tokens_cpu = self.input_batch.num_computed_tokens_cpu_tensor[
            :num_reqs_padded
        ]
        num_prompt_tokens_cpu = self.input_batch.num_prompt_tokens_cpu_tensor[
            :num_reqs_padded
        ]
        seq_lens_cpu = self.optimistic_seq_lens_cpu[:num_reqs_padded]
        seq_lens_cpu_upper_bound = seq_lens_cpu

        # is_prefilling: True if request is still in prefill phase.
        # Used by mamba backends to distinguish actual decodes from
        # short extends.
        is_prefilling = num_computed_tokens_cpu < num_prompt_tokens_cpu
        # Zero out padded rows so stale data from condense() doesn't
        # misclassify padding as prefill in CUDA graph mode.
        is_prefilling[num_reqs:] = False

        if self.use_async_spec_decode:
            # GPU tensors are authoritative in async mode.
            seq_lens_cpu = None
            num_computed_tokens_cpu = None

        # Prefix-anchored SWA: pass per-request prompt lengths so the
        # attention backend can keep the prefix globally visible. The backend
        # owns the persistent device buffer.
        prefix_anchor_lens = None
        if (
            getattr(
                self.vllm_config.attention_config,
                "prefix_anchored_decode_window",
                None,
            )
            is not None
        ):
            prefix_anchor_lens = num_prompt_tokens_cpu

        cm_base = CommonAttentionMetadata(
            query_start_loc=self.query_start_loc.gpu[: num_reqs_padded + 1],
            query_start_loc_cpu=self.query_start_loc.cpu[: num_reqs_padded + 1],
            seq_lens=self.seq_lens[:num_reqs_padded],
            _seq_lens_cpu=seq_lens_cpu,
            _num_computed_tokens_cpu=num_computed_tokens_cpu,
            seq_lens_cpu_upper_bound=seq_lens_cpu_upper_bound,
            num_reqs=num_reqs_padded,
            num_actual_tokens=num_tokens_padded,
            max_query_len=max_query_len,
            max_seq_len=max_seq_len,
            block_table_tensor=block_table_gid_0,
            slot_mapping=slot_mapping_gid_0,
            is_dummy_batch=is_dummy_batch,
            causal=True,
            cudagraph_graph_variant=cudagraph_graph_variant,
            is_prefilling=is_prefilling,
            positions=self.positions[:num_tokens_padded],
            prefix_anchor_lens=prefix_anchor_lens,
        )

        current_mamba_state_block_ids_by_gid: dict[int, torch.Tensor] = {}

        def _get_current_mamba_state_block_ids(
            kv_cache_gid: int,
        ) -> torch.Tensor | None:
            if not use_spec_decode:
                return None
            if kv_cache_gid in current_mamba_state_block_ids_by_gid:
                return current_mamba_state_block_ids_by_gid[kv_cache_gid]

            state_block_ids = self.current_mamba_state_block_ids
            state_block_ids.cpu[:num_reqs_padded].fill_(PAD_SLOT_ID)
            for req_idx, req_id in enumerate(self.input_batch.req_ids[:num_reqs]):
                state_block_idx = self.mamba_state_idx.get(req_id)
                if state_block_idx is None:
                    continue
                req_state = self.requests[req_id]
                block_ids = req_state.block_ids[kv_cache_gid]
                for offset in range(self.max_spec_state_slots):
                    block_idx = state_block_idx + offset
                    if 0 <= block_idx < len(block_ids):
                        state_block_ids.cpu[req_idx, offset] = block_ids[block_idx]
                    else:
                        break
            self._copy_buffer_to_gpu(state_block_ids, num_reqs_padded)
            current_mamba_state_block_ids_by_gid[kv_cache_gid] = state_block_ids.gpu[
                :num_reqs_padded
            ]
            return current_mamba_state_block_ids_by_gid[kv_cache_gid]

        if self.dcp_world_size > 1:
            self.dcp_local_seq_lens.cpu[:num_reqs] = get_dcp_local_seq_lens(
                self.optimistic_seq_lens_cpu[:num_reqs],
                self.dcp_world_size,
                self.dcp_rank,
                self.parallel_config.cp_kv_cache_interleave_size,
            )
            self.dcp_local_seq_lens.cpu[num_reqs:].fill_(0)
            self._copy_buffer_to_gpu(self.dcp_local_seq_lens, num_reqs_padded)

            cm_base.dcp_local_seq_lens = self.dcp_local_seq_lens.gpu[:num_reqs_padded]
            cm_base.dcp_local_seq_lens_cpu = self.dcp_local_seq_lens.cpu[
                :num_reqs_padded
            ]

        if logits_indices is not None and self.cache_config.kv_sharing_fast_prefill:
            cm_base.num_logits_indices = logits_indices.size(0)
            cm_base.logits_indices_padded = self._prepare_kv_sharing_fast_prefill(
                logits_indices
            )

        # Cache attention metadata builds across hybrid KV-cache groups
        # The only thing that changes between different hybrid KV-cache groups when the
        # same metadata builder and KVCacheSpec is the same is the block table, so we
        # can cache the attention metadata builds and just update the block table using
        # `builder.update_block_table` if the builder supports it.
        cached_attn_metadata: dict[
            tuple[KVCacheSpec, type[AttentionMetadataBuilder]], AttentionMetadata
        ] = {}
        ddtree_fast_build_epoch: int | None = None
        if ddtree_parent_metadata is not None:
            ddtree_fast_build_epoch = getattr(self, "_ddtree_fast_build_epoch", 0) + 1
            self._ddtree_fast_build_epoch = ddtree_fast_build_epoch

        def _build_attn_group_metadata(
            kv_cache_gid: int,
            attn_gid: int,
            common_attn_metadata: CommonAttentionMetadata,
            ubid: int | None = None,
        ) -> None:
            attn_group = self.attn_groups[kv_cache_gid][attn_gid]
            builder = attn_group.get_metadata_builder(ubid or 0)
            kv_cache_spec = kv_cache_groups[kv_cache_gid].kv_cache_spec
            if isinstance(kv_cache_spec, UniformTypeKVCacheSpecs):
                kv_cache_spec = kv_cache_spec.kv_cache_specs[attn_group.layer_names[0]]
            cache_key = (kv_cache_spec, type(builder))

            cascade_attn_prefix_len = (
                cascade_attn_prefix_lens[kv_cache_gid][attn_gid]
                if cascade_attn_prefix_lens
                else 0
            )

            extra_attn_metadata_args = {}
            if use_spec_decode and isinstance(
                builder, (Mamba2AttentionMetadataBuilder, GDNAttentionMetadataBuilder)
            ):
                assert ubid is None, "UBatching not supported with GDN yet"
                extra_attn_metadata_args = dict(
                    num_accepted_tokens=self.num_accepted_tokens.gpu[:num_reqs_padded],
                    num_decode_draft_tokens_cpu=self.num_decode_draft_tokens.cpu[
                        :num_reqs_padded
                    ],
                )
                if isinstance(builder, GDNAttentionMetadataBuilder):
                    extra_attn_metadata_args["spec_state_slot_selectors"] = (
                        self.spec_state_slot_selectors.gpu[:num_reqs_padded]
                    )
                if ddtree_parent_metadata is not None and isinstance(
                    builder, GDNAttentionMetadataBuilder
                ):
                    extra_attn_metadata_args["ddtree_parent_ids"] = (
                        ddtree_parent_metadata.parent_ids
                    )
                    extra_attn_metadata_args["ddtree_num_tree_tokens_cpu"] = (
                        ddtree_parent_metadata.num_tree_tokens_cpu
                    )
                    extra_attn_metadata_args["fast_build"] = True
                    extra_attn_metadata_args["ddtree_fast_build_epoch"] = (
                        ddtree_fast_build_epoch
                    )
                if (
                    isinstance(builder, Mamba2AttentionMetadataBuilder)
                    and self.mamba_prev_last_scheduled_idx is not None
                ):
                    extra_attn_metadata_args["prev_last_scheduled_idx"] = (
                        self.mamba_prev_last_scheduled_idx.gpu[:num_reqs_padded]
                    )
                if (
                    isinstance(builder, GDNAttentionMetadataBuilder)
                    and self.cache_config.mamba_cache_mode == "align"
                ):
                    extra_attn_metadata_args["current_state_block_ids"] = (
                        _get_current_mamba_state_block_ids(kv_cache_gid)
                    )
            elif (
                use_spec_decode
                and isinstance(
                    builder,
                    (FlexAttentionMetadataBuilder, FlashAttnV100MetadataBuilder),
                )
                and ddtree_parent_metadata is not None
            ):
                extra_attn_metadata_args = dict(
                    ddtree_parent_ids=ddtree_parent_metadata.parent_ids,
                    ddtree_num_tree_tokens_cpu=(
                        ddtree_parent_metadata.num_tree_tokens_cpu
                    ),
                )

            metadata_profile = _dflash_ddtree_metadata_profile_enabled()
            metadata_profile_t0 = time.perf_counter() if metadata_profile else 0.0
            metadata_profile_stage = "build"
            metadata_profile_cached = False
            if for_cudagraph_capture:
                metadata_profile_stage = "capture"
                attn_metadata_i = builder.build_for_cudagraph_capture(
                    common_attn_metadata
                )
                self._attach_ddtree_metadata_for_cudagraph_capture(
                    builder,
                    attn_metadata_i,
                    extra_attn_metadata_args,
                )
            elif (
                cache_key in cached_attn_metadata
                and builder.supports_update_block_table
            ):
                metadata_profile_stage = "update_block_table"
                metadata_profile_cached = True
                attn_metadata_i = builder.update_block_table(
                    cached_attn_metadata[cache_key],
                    common_attn_metadata.block_table_tensor,
                    common_attn_metadata.slot_mapping,
                )
            else:
                attn_metadata_i = builder.build(
                    common_prefix_len=cascade_attn_prefix_len,
                    common_attn_metadata=common_attn_metadata,
                    **extra_attn_metadata_args,
                )
                if builder.supports_update_block_table:
                    cached_attn_metadata[cache_key] = attn_metadata_i
            if metadata_profile and is_global_first_rank():
                logger.info(
                    "DFLASH_DDTREE_METADATA_PROFILE builder=%s stage=%s "
                    "kv_cache_gid=%d attn_gid=%d ubid=%s elapsed_ms=%.3f "
                    "cached=%s spec=%s ddtree=%s num_tokens=%d "
                    "num_actual_tokens=%d max_query_len=%d num_reqs=%d",
                    type(builder).__name__,
                    metadata_profile_stage,
                    kv_cache_gid,
                    attn_gid,
                    ubid,
                    (time.perf_counter() - metadata_profile_t0) * 1000.0,
                    metadata_profile_cached,
                    use_spec_decode,
                    ddtree_parent_metadata is not None,
                    num_tokens,
                    common_attn_metadata.num_actual_tokens,
                    common_attn_metadata.max_query_len,
                    common_attn_metadata.num_reqs,
                )

            if ubid is None:
                assert isinstance(attn_metadata, dict)
                attn_metadata_dict = attn_metadata
            else:
                assert isinstance(attn_metadata, list)
                attn_metadata_dict = attn_metadata[ubid]

            for layer_name in attn_group.layer_names:
                attn_metadata_dict[layer_name] = attn_metadata_i

        # Prepare the attention metadata for each KV cache group and make layers
        # in the same group share the same metadata.
        spec_decode_common_attn_metadata = None
        dflash_common_attn_metadata_by_gid: dict[int, CommonAttentionMetadata] | None
        dflash_common_attn_metadata_by_gid = None
        for kv_cache_gid, kv_cache_group in enumerate(kv_cache_groups):
            cm = copy(cm_base)  # shallow copy

            # Basically only the encoder seq_lens, block_table and slot_mapping change
            # for each kv_cache_group.
            cm.encoder_seq_lens, cm.encoder_seq_lens_cpu = self._get_encoder_seq_lens(
                num_scheduled_tokens or {},
                kv_cache_group.kv_cache_spec,
                num_reqs_padded,
                for_cudagraph_capture=for_cudagraph_capture,
            )
            if kv_cache_gid > 0:
                cm.block_table_tensor = _get_block_table(kv_cache_gid)
                cm.slot_mapping = slot_mappings[kv_cache_gid]

            if self.speculative_config and spec_decode_common_attn_metadata is None:
                if isinstance(
                    self.drafter,
                    (
                        EagleProposer,
                        DFlashProposer,
                        Gemma4Proposer,
                        ExtractHiddenStatesProposer,
                    ),
                ):
                    if self.drafter.kv_cache_gid == kv_cache_gid:
                        spec_decode_common_attn_metadata = cm
                else:
                    spec_decode_common_attn_metadata = cm
            # Capture per-group block tables for multi-group proposers.
            if self.speculative_config and isinstance(
                self.drafter, Qwen4ExpMTPProposer
            ):
                self.drafter.set_per_group_block_table(
                    kv_cache_gid, cm.block_table_tensor
                )
            elif self.speculative_config and isinstance(
                self.drafter, Step3p5MTPProposer
            ):
                self.drafter.set_per_group_attn_metadata(
                    kv_cache_gid, cm.block_table_tensor, cm.slot_mapping
                )
            elif self.speculative_config and isinstance(self.drafter, Gemma4Proposer):
                self.drafter.set_per_group_block_table(
                    kv_cache_gid, cm.block_table_tensor
                )
            elif self.speculative_config and isinstance(self.drafter, DFlashProposer):
                dflash_gids = set(self.drafter.draft_layer_to_kv_cache_gid.values())
                if not dflash_gids and self.drafter.kv_cache_gid >= 0:
                    dflash_gids.add(self.drafter.kv_cache_gid)
                if kv_cache_gid in dflash_gids:
                    if dflash_common_attn_metadata_by_gid is None:
                        dflash_common_attn_metadata_by_gid = {}
                    dflash_common_attn_metadata_by_gid[kv_cache_gid] = cm

            for attn_gid in range(len(self.attn_groups[kv_cache_gid])):
                if ubatch_slices is not None:
                    for ubid, _cm in enumerate(split_attn_metadata(ubatch_slices, cm)):
                        _build_attn_group_metadata(kv_cache_gid, attn_gid, _cm, ubid)

                else:
                    _build_attn_group_metadata(kv_cache_gid, attn_gid, cm)

        if self.is_mm_prefix_lm:
            req_doc_ranges = {}

            # Gemma4 bidi: skip ranges that exceed the sliding
            # window. When image tokens > sliding_window, bidi causes
            # early image tokens to attend to the entire image
            # (e.g. 6 → 1092 targets), degrading spatial precision.
            # Per-range filtering keeps bidi for small images/video
            # frames while skipping oversized images.
            hf_text_config = self.model_config.hf_text_config
            _bidi_sw = getattr(hf_text_config, "sliding_window", None)

            for req_id in self.input_batch.req_ids:
                image_doc_ranges = []
                req_state = self.requests[req_id]
                for mm_feature in req_state.mm_features:
                    pos_info = mm_feature.mm_position
                    img_doc_range = pos_info.extract_embeds_range()
                    for r in img_doc_range:
                        if _bidi_sw is not None and (r[1] - r[0] + 1) > _bidi_sw:
                            continue
                        image_doc_ranges.append(r)
                req_idx = self.input_batch.req_id_to_index[req_id]
                req_doc_ranges[req_idx] = image_doc_ranges

            # Set mm_prefix_range for all attention metadata
            self._set_mm_prefix_range_for_metadata(attn_metadata, req_doc_ranges)

        if spec_decode_common_attn_metadata is not None and (
            num_reqs != num_reqs_padded or num_tokens != num_tokens_padded
        ):
            # Currently the drafter still only uses piecewise cudagraphs (and modifies
            # the attention metadata in directly), and therefore does not want to use
            # padded attention metadata.
            spec_decode_common_attn_metadata = (
                spec_decode_common_attn_metadata.unpadded(num_tokens, num_reqs)
            )
        if dflash_common_attn_metadata_by_gid is not None:
            if num_reqs != num_reqs_padded or num_tokens != num_tokens_padded:
                dflash_common_attn_metadata_by_gid = {
                    gid: metadata.unpadded(num_tokens, num_reqs)
                    for gid, metadata in dflash_common_attn_metadata_by_gid.items()
                }
            assert isinstance(self.drafter, DFlashProposer)
            self.drafter.set_common_attn_metadata_by_kv_cache_group(
                dflash_common_attn_metadata_by_gid
            )

        return attn_metadata, spec_decode_common_attn_metadata

    def _compute_cascade_attn_prefix_lens(
        self,
        num_scheduled_tokens: np.ndarray,
        num_computed_tokens: np.ndarray,
        num_common_prefix_blocks: list[int],
    ) -> list[list[int]] | None:
        """
        :return: Optional[cascade_attn_prefix_lens]
            cascade_attn_prefix_lens is 2D: ``[kv_cache_group_id][attn_group_idx]``,
            None if we should not use cascade attention
        """

        use_cascade_attn = False
        num_kv_cache_groups = len(self.kv_cache_config.kv_cache_groups)
        cascade_attn_prefix_lens: list[list[int]] = [
            [] for _ in range(num_kv_cache_groups)
        ]

        for kv_cache_gid in range(num_kv_cache_groups):
            for attn_group in self.attn_groups[kv_cache_gid]:
                if isinstance(attn_group.kv_cache_spec, EncoderOnlyAttentionSpec):
                    cascade_attn_prefix_len = 0
                else:
                    # 0 if cascade attention should not be used
                    cascade_attn_prefix_len = self._compute_cascade_attn_prefix_len(
                        num_scheduled_tokens,
                        num_computed_tokens,
                        num_common_prefix_blocks[kv_cache_gid],
                        attn_group.kv_cache_spec,
                        attn_group.get_metadata_builder(),
                    )
                cascade_attn_prefix_lens[kv_cache_gid].append(cascade_attn_prefix_len)
                use_cascade_attn |= cascade_attn_prefix_len > 0

        return cascade_attn_prefix_lens if use_cascade_attn else None

    def _compute_cascade_attn_prefix_len(
        self,
        num_scheduled_tokens: np.ndarray,
        num_computed_tokens: np.ndarray,
        num_common_prefix_blocks: int,
        kv_cache_spec: KVCacheSpec,
        attn_metadata_builder: AttentionMetadataBuilder,
    ) -> int:
        """Compute the length of the common prefix for cascade attention.

        NOTE(woosuk): The common prefix length returned by this function
        represents the length used specifically for cascade attention, not the
        actual number of tokens shared between requests. When cascade attention
        is disabled (use_cascade=False), this function returns 0 even if
        requests share common tokens. Additionally, the common prefix length is
        truncated to a multiple of the block size and may be further truncated
        due to implementation details explained below.

        Args:
            num_scheduled_tokens: Number of tokens scheduled per request.
            num_common_prefix_blocks: Number of shared KV cache blocks.

        Returns:
            int: Length of common prefix in tokens.
        """

        common_prefix_len = num_common_prefix_blocks * kv_cache_spec.block_size
        if common_prefix_len == 0:
            # Common case.
            return 0

        # NOTE(woosuk): Cascade attention uses two attention kernels: one
        # for the common prefix and the other for the rest. For the first
        # kernel, we concatenate all the query tokens (possibly from
        # different requests) and treat them as if they are from the same
        # request. Then, we use bi-directional attention to process the
        # common prefix in the KV cache. Importantly, this means that the
        # first kernel does not do any masking.

        # Consider the following example:
        # Request 1's input query: [D, E, X]
        # Request 1's kv cache: [A, B, C, D, E, X]
        # Request 1's num_computed_tokens: 3 (i.e., [A, B, C])
        # Request 2's input query: [E, Y]
        # Request 2's kv cache: [A, B, C, D, E, Y]
        # Request 2's num_computed_tokens: 4 (i.e., [A, B, C, D])

        # If we use [A, B, C, D, E] as the common prefix, then the
        # first kernel will compute the bi-directional attention between
        # input query [D, E, X, E, Y] and common prefix [A, B, C, D, E].
        # However, this is wrong because D in Request 1 should not attend to
        # E in the common prefix (i.e., we need masking).
        # To avoid this, [A, B, C, D] should be the common prefix.
        # That is, the common prefix should be capped by the minimum
        # num_computed_tokens among the requests, and plus one to include
        # the first token of the query.

        # In practice, we use [A, B, C] as the common prefix, instead of
        # [A, B, C, D] (i.e., the common prefix is capped by the minimum
        # num_computed_tokens, without plus one).
        # This is because of an implementation detail: We want to always
        # use two kernels for cascade attention. Let's imagine:
        # Request 3's input query: [D]
        # Request 3's kv cache: [A, B, C, D]
        # Request 3's num_computed_tokens: 3 (i.e., [A, B, C])
        # If we use [A, B, C, D] as the common prefix for Request 1-3,
        # then Request 3 will be processed only by the first kernel,
        # and the second kernel will get an empty input. While this is not
        # a fundamental problem, our current implementation does not support
        # this case.
        common_prefix_len = min(common_prefix_len, num_computed_tokens.min())
        # common_prefix_len should be a multiple of the block size.
        common_prefix_len = (
            common_prefix_len // kv_cache_spec.block_size * kv_cache_spec.block_size
        )
        use_sliding_window = isinstance(kv_cache_spec, SlidingWindowSpec) or (
            isinstance(kv_cache_spec, FullAttentionSpec)
            and kv_cache_spec.sliding_window is not None
        )
        use_local_attention = isinstance(kv_cache_spec, ChunkedLocalAttentionSpec) or (
            isinstance(kv_cache_spec, FullAttentionSpec)
            and kv_cache_spec.attention_chunk_size is not None
        )
        assert isinstance(kv_cache_spec, AttentionSpec)
        use_cascade = attn_metadata_builder.use_cascade_attention(
            common_prefix_len=common_prefix_len,
            query_lens=num_scheduled_tokens,
            num_query_heads=self.num_query_heads,
            num_kv_heads=kv_cache_spec.num_kv_heads,
            use_alibi=self.use_alibi,
            use_sliding_window=use_sliding_window,
            use_local_attention=use_local_attention,
            num_sms=self.num_sms,
            dcp_world_size=self.dcp_world_size,
        )
        return common_prefix_len if use_cascade else 0

    def _calc_mrope_positions(self, scheduler_output: "SchedulerOutput"):
        mrope_pos_ptr = 0
        for index, req_id in enumerate(self.input_batch.req_ids):
            req = self.requests[req_id]
            assert req.mrope_positions is not None

            num_computed_tokens = self.input_batch.num_computed_tokens_cpu[index]
            num_scheduled_tokens = scheduler_output.num_scheduled_tokens[req_id]
            num_prompt_tokens = length_from_prompt_token_ids_or_embeds(
                req.prompt_token_ids, req.prompt_embeds
            )

            if num_computed_tokens + num_scheduled_tokens > num_prompt_tokens:
                prompt_part_len = max(0, num_prompt_tokens - num_computed_tokens)
                completion_part_len = max(0, num_scheduled_tokens - prompt_part_len)
            else:
                prompt_part_len = num_scheduled_tokens
                completion_part_len = 0

            assert num_scheduled_tokens == prompt_part_len + completion_part_len

            if prompt_part_len > 0:
                # prompt's mrope_positions are pre-computed
                dst_start = mrope_pos_ptr
                dst_end = mrope_pos_ptr + prompt_part_len
                src_start = num_computed_tokens
                src_end = num_computed_tokens + prompt_part_len

                self.mrope_positions.cpu[:, dst_start:dst_end] = req.mrope_positions[
                    :, src_start:src_end
                ]
                mrope_pos_ptr += prompt_part_len

            if completion_part_len > 0:
                # compute completion's mrope_positions on-the-fly
                dst_start = mrope_pos_ptr
                dst_end = mrope_pos_ptr + completion_part_len

                assert req.mrope_position_delta is not None
                MRotaryEmbedding.get_next_input_positions_tensor(
                    out=self.mrope_positions.np,
                    out_offset=dst_start,
                    mrope_position_delta=req.mrope_position_delta,
                    context_len=num_computed_tokens + prompt_part_len,
                    num_new_tokens=completion_part_len,
                )

                mrope_pos_ptr += completion_part_len

    def _calc_xdrope_positions(self, scheduler_output: "SchedulerOutput"):
        xdrope_pos_ptr = 0
        for index, req_id in enumerate(self.input_batch.req_ids):
            req = self.requests[req_id]
            assert req.xdrope_positions is not None

            num_computed_tokens = self.input_batch.num_computed_tokens_cpu[index]
            num_scheduled_tokens = scheduler_output.num_scheduled_tokens[req_id]
            num_prompt_tokens = length_from_prompt_token_ids_or_embeds(
                req.prompt_token_ids, req.prompt_embeds
            )

            if num_computed_tokens + num_scheduled_tokens > num_prompt_tokens:
                prompt_part_len = max(0, num_prompt_tokens - num_computed_tokens)
                completion_part_len = max(0, num_scheduled_tokens - prompt_part_len)
            else:
                prompt_part_len = num_scheduled_tokens
                completion_part_len = 0

            assert num_scheduled_tokens == prompt_part_len + completion_part_len

            if prompt_part_len > 0:
                # prompt's xdrope_positions are pre-computed
                dst_start = xdrope_pos_ptr
                dst_end = xdrope_pos_ptr + prompt_part_len
                src_start = num_computed_tokens
                src_end = num_computed_tokens + prompt_part_len

                self.xdrope_positions.cpu[:, dst_start:dst_end] = req.xdrope_positions[
                    :, src_start:src_end
                ]
                xdrope_pos_ptr += prompt_part_len

            if completion_part_len > 0:
                # compute completion's xdrope_positions on-the-fly
                dst_start = xdrope_pos_ptr
                dst_end = xdrope_pos_ptr + completion_part_len

                XDRotaryEmbedding.get_next_input_positions_tensor(
                    out=self.xdrope_positions.np,
                    out_offset=dst_start,
                    context_len=num_computed_tokens + prompt_part_len,
                    num_new_tokens=completion_part_len,
                )

                xdrope_pos_ptr += completion_part_len

    def _calc_spec_decode_metadata(
        self,
        num_draft_tokens: np.ndarray,
        cu_num_scheduled_tokens: np.ndarray,
    ) -> SpecDecodeMetadata:
        # Inputs:
        # cu_num_scheduled_tokens:  [  4, 104, 107, 207, 209]
        # num_draft_tokens:         [  3,   0,   2,   0,   1]
        # Outputs:
        # cu_num_draft_tokens:      [  3,   3,   5,   5,   6]
        # logits_indices:           [  0,   1,   2,   3, 103, 104, 105, 106,
        #                            206, 207, 208]
        # target_logits_indices:    [  0,   1,   2,   5,   6,   9]
        # bonus_logits_indices:     [  3,   4,   7,   8,  10]

        # Compute the logits indices.
        # [4, 1, 3, 1, 2]
        num_sampled_tokens = num_draft_tokens + 1

        # Step 1.
        # cu_num_sampled_tokens: [4, 5, 8, 9, 11]
        # _arange_scratch[:11]: [0, 1, 2, 3, 0, 0, 1, 2, 0, 0, 1]
        cu_num_sampled_tokens = self._get_cumsum_and_arange(
            num_sampled_tokens, self._arange_scratch, cumsum_dtype=np.int32
        )
        # Step 2. [0, 0, 0, 0, 103, 104, 104, 104, 206, 207, 207]
        logits_indices = np.repeat(
            cu_num_scheduled_tokens - num_sampled_tokens, num_sampled_tokens
        )
        # Step 3. [0, 1, 2, 3, 103, 104, 105, 106, 206, 207, 208]
        logits_indices += self._arange_scratch[: cu_num_sampled_tokens[-1]]

        # Compute the bonus logits indices.
        bonus_logits_indices = cu_num_sampled_tokens - 1

        # Compute the draft logits indices.
        # cu_num_draft_tokens: [3, 3, 5, 5, 6]
        # _arange_scratch[:6]: [0, 1, 2, 0, 1, 0]
        cu_num_draft_tokens = self._get_cumsum_and_arange(
            num_draft_tokens, self._arange_scratch, cumsum_dtype=np.int32
        )
        # [0, 0, 0, 5, 5, 9]
        target_logits_indices = np.repeat(
            cu_num_sampled_tokens - num_sampled_tokens, num_draft_tokens
        )
        # [0, 1, 2, 5, 6, 9]
        target_logits_indices += self._arange_scratch[: cu_num_draft_tokens[-1]]

        # TODO: Optimize the CPU -> GPU copy.
        cu_num_draft_tokens = torch.from_numpy(cu_num_draft_tokens).to(
            self.device, non_blocking=True
        )
        cu_num_sampled_tokens = torch.from_numpy(cu_num_sampled_tokens).to(
            self.device, non_blocking=True
        )
        logits_indices = torch.from_numpy(logits_indices).to(
            self.device, non_blocking=True
        )
        target_logits_indices = torch.from_numpy(target_logits_indices).to(
            self.device, non_blocking=True
        )
        bonus_logits_indices = torch.from_numpy(bonus_logits_indices).to(
            self.device, non_blocking=True
        )

        # Compute the draft token ids.
        # draft_token_indices:      [  1,   2,   3, 105, 106, 208]
        draft_token_ids = self.input_ids.gpu[logits_indices]
        draft_token_ids = draft_token_ids[target_logits_indices + 1]

        return SpecDecodeMetadata(
            draft_token_ids=draft_token_ids,
            num_draft_tokens=num_draft_tokens.tolist(),
            cu_num_draft_tokens=cu_num_draft_tokens,
            cu_num_sampled_tokens=cu_num_sampled_tokens,
            target_logits_indices=target_logits_indices,
            bonus_logits_indices=bonus_logits_indices,
            logits_indices=logits_indices,
        )

    def _prepare_kv_sharing_fast_prefill(
        self,
        logits_indices: torch.Tensor,
    ) -> torch.Tensor:
        assert self.kv_sharing_fast_prefill_logits_indices is not None
        num_logits = logits_indices.shape[0]
        assert num_logits > 0
        self.kv_sharing_fast_prefill_logits_indices[:num_logits].copy_(logits_indices)
        # There might have leftover indices in logits_indices[num_logits:]
        # from previous iterations, whose values may be greater than the
        # batch size in the current iteration. To ensure indices are always
        # valid, fill the padded indices with the last index. Broadcast the
        # scalar GPU-side to avoid a D2H sync on `.item()`.
        self.kv_sharing_fast_prefill_logits_indices[num_logits:] = logits_indices[-1]
        # Dispatch for the decoder portion of the model.
        _, batch_desc = self.cudagraph_dispatcher.dispatch(
            num_logits, invalid_modes={CUDAGraphMode.FULL}
        )
        num_logits_padded = batch_desc.num_tokens
        logits_indices_padded = self.kv_sharing_fast_prefill_logits_indices[
            :num_logits_padded
        ]
        return logits_indices_padded

    def _batch_mm_inputs_from_scheduler(
        self,
        scheduler_output: "SchedulerOutput",
    ) -> tuple[
        list[str],
        list[tuple[str, MultiModalKwargsItem]],
        list[tuple[str, PlaceholderRange]],
    ]:
        """Batch multimodal inputs from scheduled encoder inputs.

        Args:
            scheduler_output: The scheduler output containing scheduled encoder
                inputs.

        Returns:
            A tuple of (mm_hashes, mm_kwargs, mm_lora_refs) where:
            - mm_hashes: List of multimodal hashes for each item
            - mm_kwargs: List of multimodal kwargs for each item
            - mm_lora_refs: List of (req_id, placeholder_range) for each item
        """
        scheduled_encoder_inputs = scheduler_output.scheduled_encoder_inputs
        if not scheduled_encoder_inputs:
            return [], [], []

        mm_hashes = list[str]()
        mm_kwargs = list[tuple[str, MultiModalKwargsItem]]()
        # Multimodal LoRA reference info to map each multimodal item
        # back to its request & position
        mm_lora_refs = list[tuple[str, PlaceholderRange]]()
        for req_id, encoder_input_ids in scheduled_encoder_inputs.items():
            req_state = self.requests[req_id]

            for mm_input_id in encoder_input_ids:
                mm_feature = req_state.mm_features[mm_input_id]
                if mm_feature.data is None:
                    continue

                mm_hashes.append(mm_feature.identifier)
                mm_kwargs.append((mm_feature.modality, mm_feature.data))
                mm_lora_refs.append((req_id, mm_feature.mm_position))

        return mm_hashes, mm_kwargs, mm_lora_refs

    def _execute_mm_encoder(
        self, scheduler_output: "SchedulerOutput"
    ) -> list[torch.Tensor]:
        mm_hashes, mm_kwargs, mm_lora_refs = self._batch_mm_inputs_from_scheduler(
            scheduler_output
        )

        if not mm_kwargs:
            return []

        # `prompt_embeds` is a passthrough modality, the tensor is already in
        # the model embedding space, so no encoder runs. Inject each
        # `prompt_embeds` tensor directly into the encoder cache here so that
        # `_gather_mm_embeddings` can splice it via the standard `is_mm_embed`
        # path.
        pe_indices = [
            i
            for i, (modality, _) in enumerate(mm_kwargs)
            if modality == "prompt_embeds"
        ]
        if pe_indices:
            for i in pe_indices:
                pe_tensor = mm_kwargs[i][1]["embedding"].data
                assert isinstance(pe_tensor, torch.Tensor)

                self.encoder_cache[mm_hashes[i]] = pe_tensor.to(self.device)
                self.maybe_save_ec_to_connector(self.encoder_cache, mm_hashes[i])
            # Filter out `prompt_embeds` items from mm_kwargs/mm_hashes/mm_lora_refs
            # since they don't require further encoder processing.
            mm_hashes = [h for i, h in enumerate(mm_hashes) if i not in pe_indices]
            mm_kwargs = [k for i, k in enumerate(mm_kwargs) if i not in pe_indices]
            mm_lora_refs = [
                r for i, r in enumerate(mm_lora_refs) if i not in pe_indices
            ]
            if not mm_kwargs:
                return []  # nothing left to encode after filtering out `prompt_embeds`

        should_time = bool(
            self.observability_config
            and self.observability_config.enable_mm_processor_stats
            and scheduler_output.scheduled_encoder_inputs
        )

        # Batch mm inputs as much as we can: if a request in the batch has
        # multiple modalities or a different modality than the previous one,
        # we process it separately to preserve item order.
        # FIXME(ywang96): This is a hacky way to deal with multiple modalities
        # in the same batch while still being able to benefit from batching
        # multimodal inputs. The proper solution should be reordering the
        # encoder outputs.
        model = cast(SupportsMultiModal, self.model)

        if self.lora_config and self.lora_manager.supports_tower_connector_lora():
            # Build LoRA mappings independently for encoder inputs
            # (encoder batch structure is different from main batch)
            prompt_lora_mapping = []
            token_lora_mapping = []
            lora_requests = set()
            encoder_token_counts = []

            for req_id, pos_info in mm_lora_refs:
                req_idx = self.input_batch.req_id_to_index[req_id]
                lora_id = int(self.input_batch.request_lora_mapping[req_idx])

                # Prefer pos_info.get_num_embeds to count precise MM embedding tokens.
                num_tokens = self.model.get_num_mm_encoder_tokens(  # type: ignore[attr-defined]
                    pos_info.get_num_embeds()
                )
                prompt_lora_mapping.append(lora_id)
                token_lora_mapping.extend([lora_id] * num_tokens)
                encoder_token_counts.append(num_tokens)

                if lora_id > 0:
                    lora_request = self.input_batch.lora_id_to_lora_request.get(lora_id)
                    if lora_request is not None:
                        lora_requests.add(lora_request)

            # Set tower adapter mapping
            tower_mapping = LoRAMapping(
                tuple(token_lora_mapping),
                tuple(prompt_lora_mapping),
                is_prefill=True,
                type=LoRAMappingType.TOWER,
            )
            self.lora_manager.set_active_adapters(lora_requests, tower_mapping)

            # Only set connector mapping if the model actually has a connector.
            # Some multimodal models inherit a stub `get_num_mm_connector_tokens`
            # from `SupportsMultiModal`, which returns None and should not be
            # treated as a signal that connector LoRA is supported.
            mm_mapping = (
                self.model.get_mm_mapping()  # type: ignore[attr-defined]
                if hasattr(self.model, "get_mm_mapping")
                else None
            )
            if (
                mm_mapping is not None
                and mm_mapping.connector
                and hasattr(self.model, "get_num_mm_connector_tokens")
            ):
                post_op_counts = [
                    self.model.get_num_mm_connector_tokens(num_tokens)  # type: ignore[attr-defined]
                    for num_tokens in encoder_token_counts
                ]

                connector_token_mapping = np.repeat(
                    np.array(prompt_lora_mapping, dtype=np.int32),
                    np.array(post_op_counts, dtype=np.int32),
                )
                connector_mapping = LoRAMapping(
                    index_mapping=tuple(connector_token_mapping.tolist()),
                    prompt_mapping=tuple(prompt_lora_mapping),
                    is_prefill=True,
                    type=LoRAMappingType.CONNECTOR,
                )

                self.lora_manager.set_active_adapters(
                    lora_requests,
                    connector_mapping,
                )

        encoder_outputs: list[torch.Tensor] = []
        # Track the current index in mm_kwargs/mm_lora_refs to map groups to request IDs
        current_item_idx = 0
        for modality, num_items, mm_kwargs_batch in group_and_batch_mm_kwargs(
            mm_kwargs,
            device=self.device,
            pin_memory=self.pin_memory,
            max_batch_size=getattr(self, "mm_encoder_batch_size", 0),
        ):
            batch_outputs: MultiModalEmbeddings

            # EVS and dynamic res video related change.
            # (ekhvedchenia): Temporary hack to limit peak memory usage when
            # processing multimodal data. This solves the issue with scheduler
            # putting too many video samples into a single batch. Scheduler
            # uses pruned vision tokens count to compare it versus compute
            # budget which is incorrect (Either input media size or non-pruned
            # output vision tokens count should be considered)
            # dynamic res video for nemotron temporarily uses this hack via
            # requires_sequential_video_encoding
            # because it doesn't yet support video batching.
            # TODO(ywang96): Fix memory profiling to take EVS into account and
            # remove this hack.
            if (
                (
                    self.is_multimodal_pruning_enabled
                    or self.requires_sequential_video_encoding
                )
                and modality == "video"
                and num_items > 1
            ):
                batch_outputs_lst = list[torch.Tensor]()
                for video_idx in range(num_items):
                    video_mm_kwargs_item = mm_kwargs[current_item_idx + video_idx]
                    with self.timed_encoder_operation(
                        should_time, mm_lora_refs, current_item_idx + video_idx, 1
                    ):
                        _, _, micro_batch_mm_inputs = next(
                            group_and_batch_mm_kwargs(
                                [video_mm_kwargs_item],
                                device=self.device,
                                pin_memory=self.pin_memory,
                            )
                        )

                        micro_batch_outputs = model.embed_multimodal(
                            **micro_batch_mm_inputs
                        )

                        batch_outputs_lst.extend(micro_batch_outputs)

                batch_outputs = batch_outputs_lst
            else:
                # Run the encoder.
                # `batch_outputs` is either of the following:
                # 1. A tensor of shape (num_items, feature_size, hidden_size)
                # in case feature_size is fixed across all multimodal items.
                # 2. A list or tuple (length: num_items) of tensors,
                # each of shape (feature_size, hidden_size) in case the feature
                # size is dynamic depending on the input multimodal items.

                with self.timed_encoder_operation(
                    should_time, mm_lora_refs, current_item_idx, num_items
                ):
                    cudagraph_output = None
                    if (
                        self.encoder_cudagraph_manager is not None
                        and self.encoder_cudagraph_manager.supports_modality(modality)
                    ):
                        cudagraph_output = self.encoder_cudagraph_manager.execute(
                            mm_kwargs_batch,
                        )

                    if cudagraph_output is not None:
                        batch_outputs = cudagraph_output
                    else:
                        batch_outputs = model.embed_multimodal(**mm_kwargs_batch)

            sanity_check_mm_encoder_outputs(batch_outputs, expected_num_items=num_items)
            encoder_outputs.extend(batch_outputs)

            current_item_idx += num_items

        # Cache the encoder outputs by mm_hash
        for mm_hash, output in zip(mm_hashes, encoder_outputs):
            self.encoder_cache[mm_hash] = output
            logger.debug("Finish execute for mm hash %s", mm_hash)
            self.maybe_save_ec_to_connector(self.encoder_cache, mm_hash)

        return encoder_outputs

    def _gather_mm_embeddings(
        self,
        scheduler_output: "SchedulerOutput",
        shift_computed_tokens: int = 0,
    ) -> tuple[list[torch.Tensor], torch.Tensor]:
        total_num_scheduled_tokens = scheduler_output.total_num_scheduled_tokens

        mm_embeds = list[torch.Tensor]()
        is_mm_embed = torch.zeros(
            total_num_scheduled_tokens, dtype=torch.bool, device="cpu"
        )

        req_start_idx = 0
        should_sync_mrope_positions = False
        should_sync_xdrope_positions = False

        for req_id in self.input_batch.req_ids:
            mm_embeds_req: list[torch.Tensor] = []

            num_scheduled_tokens = scheduler_output.num_scheduled_tokens[req_id]
            req_state = self.requests[req_id]
            num_computed_tokens = req_state.num_computed_tokens + shift_computed_tokens

            for mm_feature in req_state.mm_features:
                pos_info = mm_feature.mm_position
                start_pos = pos_info.offset
                num_encoder_tokens = pos_info.length

                # The encoder output is needed if the two ranges overlap:
                # [num_computed_tokens,
                #  num_computed_tokens + num_scheduled_tokens) and
                # [start_pos, start_pos + num_encoder_tokens)
                if start_pos >= num_computed_tokens + num_scheduled_tokens:
                    # The encoder output is not needed in this step.
                    break
                if start_pos + num_encoder_tokens <= num_computed_tokens:
                    # The encoder output is already processed and stored
                    # in the decoder's KV cache.
                    continue

                start_idx = max(num_computed_tokens - start_pos, 0)
                end_idx = min(
                    num_computed_tokens - start_pos + num_scheduled_tokens,
                    num_encoder_tokens,
                )
                assert start_idx < end_idx
                curr_embeds_start, curr_embeds_end = (
                    pos_info.get_embeds_indices_in_range(start_idx, end_idx)
                )
                # If there are no embeddings in the current range, we skip
                # gathering the embeddings.
                if curr_embeds_start == curr_embeds_end:
                    continue

                mm_hash = mm_feature.identifier
                encoder_output = self.encoder_cache.get(mm_hash, None)
                assert encoder_output is not None, f"Encoder cache miss for {mm_hash}."

                if (is_embed := pos_info.is_embed) is not None:
                    is_embed = is_embed[start_idx:end_idx]
                    mm_embeds_item = encoder_output[curr_embeds_start:curr_embeds_end]
                else:
                    mm_embeds_item = encoder_output[start_idx:end_idx]

                req_start_pos = req_start_idx + start_pos - num_computed_tokens
                # OR mask for overlapping mm_features (use_audio_in_video)
                if is_embed is None:
                    is_mm_embed[req_start_pos + start_idx : req_start_pos + end_idx] = (
                        True
                    )
                else:
                    is_mm_embed[
                        req_start_pos + start_idx : req_start_pos + end_idx
                    ] |= is_embed
                mm_embeds_req.append(mm_embeds_item)

            if self.is_multimodal_pruning_enabled and self.uses_mrope:
                assert req_state.mrope_positions is not None
                should_sync_mrope_positions = True
                mm_embeds_req, new_mrope_positions, new_delta = (
                    self.model.recompute_mrope_positions(
                        input_ids=req_state.prompt_token_ids,
                        multimodal_embeddings=mm_embeds_req,
                        mrope_positions=req_state.mrope_positions,
                        num_computed_tokens=req_state.num_computed_tokens,
                    )
                )
                req_state.mrope_positions.copy_(new_mrope_positions)
                req_state.mrope_position_delta = new_delta

            mm_embeds.extend(mm_embeds_req)
            req_start_idx += num_scheduled_tokens

        if should_sync_mrope_positions:
            self._calc_mrope_positions(scheduler_output)
            self._copy_position_buffer_to_gpu(
                self.mrope_positions, total_num_scheduled_tokens
            )

        if should_sync_xdrope_positions:
            self._calc_xdrope_positions(scheduler_output)
            self._copy_position_buffer_to_gpu(
                self.xdrope_positions, total_num_scheduled_tokens
            )

        return mm_embeds, is_mm_embed

    def get_model(self) -> nn.Module:
        if not hasattr(self, "model"):
            raise ValueError("Cannot get model before model has been initialized")
        if isinstance(
            self.model, (CUDAGraphWrapper, UBatchWrapper, BreakableCUDAGraphWrapper)
        ):
            # get raw model out of the cudagraph wrapper.
            return self.model.unwrap()
        return self.model

    def get_supported_generation_tasks(self) -> list[GenerationTask]:
        model = self.get_model()
        supported_tasks = list[GenerationTask]()

        if is_text_generation_model(model):
            supported_tasks.append("generate")

        if supports_transcription(model):
            if model.supports_transcription_only:
                return ["transcription"]

            supported_tasks.append("transcription")

        if supports_realtime(model):
            supported_tasks.append("realtime")

        return supported_tasks

    def get_supported_pooling_tasks(self) -> list[PoolingTask]:
        model = self.get_model()
        if not is_pooling_model(model):
            return []

        return list(model.pooler.get_supported_tasks())

    def get_supported_tasks(self) -> tuple[SupportedTask, ...]:
        tasks = list[SupportedTask]()

        if self.model_config.runner_type == "generate":
            tasks.extend(self.get_supported_generation_tasks())
        if self.model_config.runner_type == "pooling":
            tasks.extend(self.get_supported_pooling_tasks())

        return tuple(tasks)

    def sync_and_gather_intermediate_tensors(
        self,
        num_tokens: int,
        intermediate_tensors: IntermediateTensors | None,
        sync_self: bool,
    ) -> IntermediateTensors:
        assert self.intermediate_tensors is not None

        tp = self.vllm_config.parallel_config.tensor_parallel_size
        is_rs = is_residual_scattered_for_sp(self.vllm_config, num_tokens)

        # When sequence parallelism is enabled, the "residual" tensor is
        # sharded across TP ranks. All-gather it here because downstream
        # QKV + Attention needs the full residual before the SP split point.
        if sync_self:
            assert intermediate_tensors is not None
            for k, v in intermediate_tensors.items():
                is_scattered = k == "residual" and is_rs
                if is_scattered:
                    local_len = num_tokens // tp
                    v = get_tp_group().all_gather(v[:local_len], dim=0)

                destination = self.intermediate_tensors[k][:num_tokens]
                source = v[:num_tokens]
                if (
                    destination.data_ptr() != source.data_ptr()
                    or destination.shape != source.shape
                    or destination.stride() != source.stride()
                ):
                    destination.copy_(source, non_blocking=True)

        return IntermediateTensors(
            {k: v[:num_tokens] for k, v in self.intermediate_tensors.items()}
        )

    def eplb_step(self, is_dummy: bool = False, is_profile: bool = False) -> None:
        """
        Step for the EPLB (Expert Parallelism Load Balancing) state.
        """
        if not self.parallel_config.enable_eplb or self.eep_eplb_suppressed:
            return

        assert self.eplb_state is not None
        assert self._moe_model is not None
        self.eplb_state.step(
            is_dummy,
            is_profile,
            log_stats=self.parallel_config.eplb_config.log_balancedness,
        )

    def setup_eplb_from_mapping(
        self,
        expanded_physical_to_logical: torch.Tensor,
        old_num_physical_experts: int,
    ) -> None:
        assert self._moe_model is not None

        self.eplb_state = EplbState.from_mapping(
            model=self._moe_model,
            model_config=self.model_config,
            device=self.device,
            parallel_config=self.parallel_config,
            expanded_physical_to_logical=expanded_physical_to_logical,
            num_valid_physical_experts=old_num_physical_experts,
        )

    def _pool(
        self,
        hidden_states: torch.Tensor,
        num_scheduled_tokens: int,
        num_scheduled_tokens_np: np.ndarray,
        kv_connector_output: KVConnectorOutput | None,
    ) -> ModelRunnerOutput | AsyncModelRunnerOutput:
        num_reqs = self.input_batch.num_reqs
        assert num_reqs == len(self.input_batch.pooling_params), (
            "Either all or none of the requests in a batch must be pooling request"
        )

        hidden_states = hidden_states[:num_scheduled_tokens]
        seq_lens_cpu = self.optimistic_seq_lens_cpu[:num_reqs]

        pooling_metadata = self.input_batch.get_pooling_metadata()
        pooling_metadata.build_pooling_cursor(
            num_scheduled_tokens_np,
            seq_lens_cpu,
            device=hidden_states.device,
            query_start_loc_gpu=self.query_start_loc.gpu[: num_reqs + 1],
        )

        model = cast(VllmModelForPooling, self.model)
        raw_pooler_output: PoolerOutput = model.pooler(
            hidden_states=hidden_states, pooling_metadata=pooling_metadata
        )

        finished_mask = [
            seq_len == prompt_len
            for seq_len, prompt_len in zip(seq_lens_cpu, pooling_metadata.prompt_lens)
        ]
        raw_pooler_output = self.late_interaction_runner.postprocess_pooler_output(
            raw_pooler_output=raw_pooler_output,
            pooling_params=pooling_metadata.pooling_params,
            req_ids=self.input_batch.req_ids,
            finished_mask=finished_mask,
        )

        model_runner_output = ModelRunnerOutput(
            req_ids=self.input_batch.req_ids.copy(),
            req_id_to_index=self.input_batch.req_id_to_index.copy(),
            kv_connector_output=kv_connector_output,
        )

        if raw_pooler_output is None or not any(finished_mask):
            model_runner_output.pooler_output = [None] * num_reqs
            return model_runner_output

        if not current_platform.is_cuda_alike():
            # cpu/xpu runners cannot use the CUDA stream/event-based wrapper.
            model_runner_output.pooler_output = _copy_pooler_output_to_cpu(
                raw_pooler_output=raw_pooler_output,
                finished_mask=finished_mask,
            )
            self._sync_device()
            return model_runner_output

        return AsyncGPUPoolingModelRunnerOutput(
            synchronize=self._event_tracer.synchronize,
            model_runner_output=model_runner_output,
            raw_pooler_output=raw_pooler_output,
            finished_mask=finished_mask,
            async_output_copy_stream=self._get_or_create_async_output_copy_stream(),
        )

    def _pad_for_sequence_parallelism(self, num_scheduled_tokens: int) -> int:
        # Pad tokens to multiple of tensor_parallel_size when
        # enabled collective fusion for SP
        tp_size = self.vllm_config.parallel_config.tensor_parallel_size
        if self.compilation_config.pass_config.enable_sp and tp_size > 1:
            return round_up(num_scheduled_tokens, tp_size)
        return num_scheduled_tokens

    def _prepare_mm_inputs(
        self, num_tokens: int
    ) -> tuple[torch.Tensor | None, torch.Tensor]:
        if self.model.requires_raw_input_tokens:
            input_ids = self.input_ids.gpu[:num_tokens]
        else:
            input_ids = None

        inputs_embeds = self.inputs_embeds.gpu[:num_tokens]
        return input_ids, inputs_embeds

    def _prepare_ngram_context(
        self,
        num_reqs: int,
        num_reqs_padded: int,
    ) -> torch.Tensor:
        """Copy committed per-request token history into the PLE context."""
        if not self.uses_ngram_embedding:
            raise RuntimeError("N-gram context requested for a non-PLE model")

        eos_token_id = int(self.ngram_eos_token_id)
        context_cpu = self.ngram_context.np[:num_reqs_padded]
        context_cpu.fill(eos_token_id)
        num_computed = self.input_batch.num_computed_tokens_cpu
        token_ids = self.input_batch.token_ids_cpu
        is_token_ids = self.input_batch.is_token_ids

        for req_idx in range(num_reqs):
            end = int(num_computed[req_idx])
            if end <= 0:
                continue
            start = max(0, end - self.ngram_context_len)
            context_tokens = token_ids[req_idx, start:end]
            if context_tokens.size == 0:
                continue
            if self.enable_prompt_embeds and not is_token_ids[req_idx, start:end].all():
                context_tokens = context_tokens.copy()
                context_tokens[~is_token_ids[req_idx, start:end]] = eos_token_id
            context_cpu[req_idx, -context_tokens.size :] = context_tokens

        self._copy_buffer_to_gpu(self.ngram_context, num_reqs_padded)
        return self.ngram_context.gpu[:num_reqs_padded]

    def _setup_ple_offload(self, ipc_addr: str) -> None:
        """Attach the shared CPU PLE worker to address-stable MRV1 inputs."""
        from vllm.v1.ple_offload.connector import PleOffloadConnector

        if not self.uses_ngram_embedding:
            raise RuntimeError("PLE offload requires PLE model inputs")
        self._ple_offload_connector = PleOffloadConnector(
            self.vllm_config,
            self.get_model(),
            self.device,
            ipc_addr,
            input_ids_source=self.input_ids.cpu,
            query_start_loc_source=self.query_start_loc.cpu,
            ngram_context_source=self.ngram_context.cpu,
        )

    def _maybe_add_ngram_kwargs(
        self,
        model_kwargs: dict[str, Any],
        *,
        num_reqs: int,
        num_reqs_padded: int,
        is_first_rank: bool,
        is_encoder_decoder: bool,
        use_dummy_context: bool,
        query_start_loc: torch.Tensor | None = None,
        num_scheduled_tokens: Sequence[int] | np.ndarray | None = None,
    ) -> None:
        if not self.uses_ngram_embedding or not is_first_rank or is_encoder_decoder:
            return

        if query_start_loc is None:
            if num_scheduled_tokens is None:
                raise RuntimeError("query_start_loc is required for N-gram PLE")
            scheduled = np.asarray(num_scheduled_tokens, dtype=np.int32)
            cu_num_tokens = np.cumsum(scheduled, dtype=np.int32)
            last = int(cu_num_tokens[-1]) if num_reqs > 0 else 0
            self.query_start_loc.np[0] = 0
            if num_reqs > 0:
                self.query_start_loc.np[1 : num_reqs + 1] = cu_num_tokens
            self.query_start_loc.np[num_reqs + 1 :].fill(last)
            self._copy_buffer_to_gpu(self.query_start_loc)
            query_start_loc = self.query_start_loc.gpu[: num_reqs_padded + 1]
        model_kwargs["query_start_loc"] = query_start_loc

        if use_dummy_context:
            self.ngram_context.np[:num_reqs_padded].fill(int(self.ngram_eos_token_id))
            self._copy_buffer_to_gpu(self.ngram_context, num_reqs_padded)
            model_kwargs["ngram_context"] = self.ngram_context.gpu[:num_reqs_padded]
        else:
            model_kwargs["ngram_context"] = self._prepare_ngram_context(
                num_reqs,
                num_reqs_padded,
            )

    def _preprocess(
        self,
        scheduler_output: "SchedulerOutput",
        num_input_tokens: int,  # Padded
        num_reqs: int,
        num_reqs_padded: int,
        intermediate_tensors: IntermediateTensors | None = None,
    ) -> tuple[
        torch.Tensor | None,
        torch.Tensor | None,
        torch.Tensor,
        IntermediateTensors | None,
        dict[str, Any],
        ECConnectorOutput | None,
    ]:
        num_scheduled_tokens = scheduler_output.total_num_scheduled_tokens
        is_first_rank = get_pp_group().is_first_rank
        is_encoder_decoder = self.model_config.is_encoder_decoder

        # _prepare_inputs may reorder the batch, so we must gather multi
        # modal outputs after that to ensure the correct order
        ec_connector_output = None

        if self.supports_mm_inputs and is_first_rank and not is_encoder_decoder:
            # Run the multimodal encoder if any.
            with self.maybe_get_ec_connector_output(
                scheduler_output,
                encoder_cache=self.encoder_cache,
            ) as ec_connector_output:
                self._execute_mm_encoder(scheduler_output)
                mm_embeds, is_mm_embed = self._gather_mm_embeddings(scheduler_output)

            # NOTE(woosuk): To unify token ids and soft tokens (vision
            # embeddings), we always use embeddings (rather than token ids)
            # as input to the multimodal model, even when the input is text.
            inputs_embeds_scheduled = self.model.embed_input_ids(
                self.input_ids.gpu[:num_scheduled_tokens],
                multimodal_embeddings=mm_embeds,
                is_multimodal=is_mm_embed,
            )

            # TODO(woosuk): Avoid the copy. Optimize.
            self.inputs_embeds.gpu[:num_scheduled_tokens].copy_(inputs_embeds_scheduled)

            input_ids, inputs_embeds = self._prepare_mm_inputs(num_input_tokens)
            model_kwargs = {
                **self._init_model_kwargs(),
                **self._extract_mm_kwargs(scheduler_output),
            }
        elif self.enable_prompt_embeds and is_first_rank:
            # Get the input embeddings for the tokens that are not input embeds,
            # then put them into the appropriate positions.
            # TODO(qthequartermasterman): Since even when prompt embeds are
            # enabled, (a) not all requests will use prompt embeds, and (b)
            # after the initial prompt is processed, the rest of the generated
            # tokens will be token ids, it is not desirable to have the
            # embedding layer outside of the CUDA graph all the time. The v0
            # engine avoids this by "double compiling" the CUDA graph, once
            # with input_ids and again with inputs_embeds, for all num_tokens.
            # If a batch only has token ids, then including the embedding layer
            # in the CUDA graph will be more performant (like in the else case
            # below).
            is_token_ids = self.is_token_ids.np[:num_scheduled_tokens]
            token_ids_idx_np = np.nonzero(is_token_ids)[0]
            # Some tokens ids may need to become embeds
            if token_ids_idx_np.size > 0:
                token_ids_idx = torch.from_numpy(token_ids_idx_np)
                token_ids_idx = token_ids_idx.to(self.device, non_blocking=True)
                token_ids = self.input_ids.gpu[token_ids_idx]
                tokens_to_embeds = self.model.embed_input_ids(input_ids=token_ids)
                self.inputs_embeds.gpu[token_ids_idx] = tokens_to_embeds

            inputs_embeds = self.inputs_embeds.gpu[:num_input_tokens]
            model_kwargs = self._init_model_kwargs()
            input_ids = None
        else:
            # For text-only models, we use token ids as input.
            # While it is possible to use embeddings as input just like the
            # multimodal models, it is not desirable for performance since
            # then the embedding layer is not included in the CUDA graph.
            input_ids = self.input_ids.gpu[:num_input_tokens]
            inputs_embeds = None
            model_kwargs = self._init_model_kwargs()

        if (
            self.uses_ngram_embedding
            and is_first_rank
            and not is_encoder_decoder
            and input_ids is None
        ):
            raise RuntimeError(
                "N-gram PLE requires token IDs on the first pipeline rank"
            )
        self._maybe_add_ngram_kwargs(
            model_kwargs,
            num_reqs=num_reqs,
            num_reqs_padded=num_reqs_padded,
            is_first_rank=is_first_rank,
            is_encoder_decoder=is_encoder_decoder,
            use_dummy_context=False,
            query_start_loc=self.query_start_loc.gpu[: num_reqs_padded + 1],
        )

        if self.uses_mrope:
            positions = self.mrope_positions.gpu[:, :num_input_tokens]
        elif self.uses_xdrope_dim > 0:
            positions = self.xdrope_positions.gpu[:, :num_input_tokens]
        else:
            positions = self.positions[:num_input_tokens]
            if num_input_tokens > num_scheduled_tokens:
                self.positions[num_scheduled_tokens:num_input_tokens].zero_()

        if is_first_rank:
            intermediate_tensors = None
        else:
            assert intermediate_tensors is not None
            intermediate_tensors = self.sync_and_gather_intermediate_tensors(
                num_input_tokens, intermediate_tensors, True
            )

        if is_encoder_decoder and scheduler_output.scheduled_encoder_inputs:
            # Run the encoder, just like we do with other multimodal inputs.
            # For an encoder-decoder model, our processing here is a bit
            # simpler, because the outputs are just passed to the decoder.
            # We are not doing any prompt replacement. We also will only
            # ever have a single encoder input.
            encoder_outputs = self._execute_mm_encoder(scheduler_output)
            model_kwargs.update({"encoder_outputs": encoder_outputs})

        return (
            input_ids,
            inputs_embeds,
            positions,
            intermediate_tensors,
            model_kwargs,
            ec_connector_output,
        )

    def _make_sm70_sample_dump_metadata(
        self,
        logits_indices: torch.Tensor | None,
    ) -> dict[str, Any] | None:
        if not self._diagnostics.channels["sample"].policy.directory:
            return None

        num_reqs = self.input_batch.num_reqs
        query_start_loc_cpu = self.query_start_loc.cpu[: num_reqs + 1].clone()
        query_start_loc_gpu = self.query_start_loc.gpu[: num_reqs + 1].detach().cpu()

        metadata: dict[str, Any] = {
            "num_reqs": num_reqs,
            "req_ids": list(self.input_batch.req_ids[:num_reqs]),
            "req_id_to_index": dict(self.input_batch.req_id_to_index),
            "query_start_loc_cpu": query_start_loc_cpu,
            "query_start_loc_gpu": query_start_loc_gpu,
            "seq_lens": self.seq_lens[:num_reqs].detach().cpu(),
            "num_computed_tokens_cpu": (
                self.input_batch.num_computed_tokens_cpu_tensor[:num_reqs].clone()
            ),
            "num_computed_tokens_gpu": (
                self.num_computed_tokens[:num_reqs].detach().cpu()
            ),
            "num_prompt_tokens": (
                self.input_batch.num_prompt_tokens_cpu_tensor[:num_reqs].clone()
            ),
            "num_scheduled_tokens": (
                self.num_scheduled_tokens.gpu[:num_reqs].detach().cpu()
            ),
            "req_output_token_lens": [
                -1 if token_ids is None else len(token_ids)
                for token_ids in self.input_batch.req_output_token_ids[:num_reqs]
            ],
        }

        if logits_indices is None:
            return metadata

        logits_indices_cpu = logits_indices.detach().cpu()
        metadata["logits_indices"] = logits_indices_cpu
        sample_req_indices: list[int] = []
        sample_req_ids: list[str | None] = []
        sample_local_positions: list[int] = []
        qsl = query_start_loc_cpu.tolist()
        req_ids = self.input_batch.req_ids[:num_reqs]
        for raw_idx in logits_indices_cpu.tolist():
            idx = int(raw_idx)
            req_idx = -1
            for candidate in range(num_reqs):
                if qsl[candidate] <= idx < qsl[candidate + 1]:
                    req_idx = candidate
                    break
            sample_req_indices.append(req_idx)
            sample_req_ids.append(req_ids[req_idx] if req_idx >= 0 else None)
            sample_local_positions.append(idx - qsl[req_idx] if req_idx >= 0 else -1)
        metadata["sample_req_indices"] = sample_req_indices
        metadata["sample_req_ids"] = sample_req_ids
        metadata["sample_local_positions"] = sample_local_positions
        metadata["sample_positions"] = self.positions[logits_indices].detach().cpu()
        metadata["sample_input_ids"] = self.input_ids.gpu[logits_indices].detach().cpu()
        return metadata

    @staticmethod
    def _ddtree_non_argmax_processors_safe(
        logitsprocs: LogitsProcessors,
    ) -> bool:
        if not logitsprocs.non_argmax_invariant:
            return True

        from vllm.v1.sample.logits_processor.builtin import (
            LogitBiasLogitsProcessor,
            MinTokensLogitsProcessor,
        )

        for processor in logitsprocs.non_argmax_invariant:
            if isinstance(processor, LogitBiasLogitsProcessor):
                if processor.biases:
                    return False
                continue
            if isinstance(processor, MinTokensLogitsProcessor):
                if processor.min_toks:
                    return False
                continue
            return False
        return True

    @staticmethod
    def _ddtree_greedy_sampling_supported(
        sampling_metadata: SamplingMetadata,
    ) -> bool:
        if not sampling_metadata.all_greedy:
            return False
        if sampling_metadata.max_num_logprobs is not None:
            return False
        if sampling_metadata.logprob_token_ids:
            return False
        if not sampling_metadata.no_penalties:
            return False
        if sampling_metadata.allowed_token_ids_mask is not None:
            return False
        if sampling_metadata.bad_words_token_ids:
            return False
        holder = sampling_metadata.thinking_budget_state_holder
        if holder is not None and holder.has_tracked_requests():
            return False
        logitsprocs = sampling_metadata.logitsprocs
        return GPUModelRunner._ddtree_non_argmax_processors_safe(logitsprocs)

    @staticmethod
    def _ddtree_stochastic_sampling_supported(
        sampling_metadata: SamplingMetadata,
    ) -> bool:
        if sampling_metadata.all_greedy:
            return False
        if sampling_metadata.max_num_logprobs is not None:
            return False
        if sampling_metadata.logprob_token_ids:
            return False
        if not sampling_metadata.no_penalties:
            return False
        if sampling_metadata.allowed_token_ids_mask is not None:
            return False
        if sampling_metadata.bad_words_token_ids:
            return False
        holder = sampling_metadata.thinking_budget_state_holder
        if holder is not None and holder.has_tracked_requests():
            return False
        logitsprocs = sampling_metadata.logitsprocs
        if not GPUModelRunner._ddtree_non_argmax_processors_safe(logitsprocs):
            return False
        return not logitsprocs.argmax_invariant

    def _can_use_ddtree_greedy_top_tokens(
        self,
        scheduler_output: "SchedulerOutput",
        spec_decode_metadata: SpecDecodeMetadata | None,
    ) -> bool:
        spec_config = self.speculative_config
        if (
            spec_config is None
            or not spec_config.use_dflash_ddtree()
            or spec_config.ddtree_disable_tree_verify
            or spec_decode_metadata is None
            or not scheduler_output.scheduled_ddtree_payloads
        ):
            return False
        if _dflash_ddtree_trace_path() is not None or _dflash_ddtree_debug_enabled():
            return False
        if scheduler_output.has_structured_output_requests:
            return False
        if not self.sm70_greedy_token_fastpath:
            return False
        if self.device.type != "cuda":
            return False
        if torch.cuda.get_device_capability(self.device) != (7, 0):
            return False
        if not hasattr(self.model, "get_top_tokens"):
            return False
        return self._ddtree_greedy_sampling_supported(
            self.input_batch.sampling_metadata
        )

    def _ddtree_stochastic_topk_width(
        self,
        sampling_metadata: SamplingMetadata,
    ) -> int | None:
        top_k_cpu = sampling_metadata.top_k_cpu
        if not top_k_cpu:
            return None
        req_top_k = top_k_cpu[: self.input_batch.num_reqs]
        if not req_top_k:
            return None
        max_top_k = max(int(k) for k in req_top_k)
        min_top_k = min(int(k) for k in req_top_k)
        if min_top_k <= 0 or max_top_k > 256:
            return None
        return max_top_k

    def _can_use_ddtree_stochastic_topk_tokens(
        self,
        scheduler_output: "SchedulerOutput",
        spec_decode_metadata: SpecDecodeMetadata | None,
    ) -> bool:
        spec_config = self.speculative_config
        if (
            spec_config is None
            or not spec_config.use_dflash_ddtree()
            or spec_config.ddtree_disable_tree_verify
            or spec_decode_metadata is None
            or not scheduler_output.scheduled_ddtree_payloads
        ):
            return False
        if _dflash_ddtree_trace_path() is not None or _dflash_ddtree_debug_enabled():
            return False
        if scheduler_output.has_structured_output_requests:
            return False
        if os.getenv("VLLM_DFLASH_DDTREE_STOCHASTIC_TOPK_LOGITS", "0") != "1":
            return False
        if self.device.type != "cuda":
            return False
        if torch.cuda.get_device_capability(self.device) != (7, 0):
            return False
        if not hasattr(self.model, "get_topk_tokens_and_logits"):
            return False
        sampling_metadata = self.input_batch.sampling_metadata
        if sampling_metadata.generators:
            return False
        if not self._ddtree_stochastic_sampling_supported(sampling_metadata):
            return False
        return self._ddtree_stochastic_topk_width(sampling_metadata) is not None

    def _prepare_dynamic_draft_vocab_prefill_bootstrap(
        self,
        scheduler_output: "SchedulerOutput",
        logits: torch.Tensor | None,
        spec_decode_metadata: SpecDecodeMetadata | None,
    ) -> tuple[str, torch.Tensor] | None:
        if self.dynamic_draft_vocab_prefill_topk == 0:
            return None
        if self.input_batch.num_reqs != 1:
            return None

        request_id = self.input_batch.req_ids[0]
        request_index = self.input_batch.req_id_to_index[request_id]
        candidate_ids = (
            self._dynamic_draft_vocab_prefill_bootstrap.maybe_prepare_candidates(
                request_id,
                logits,
                topk=self.dynamic_draft_vocab_prefill_topk,
                num_computed_tokens=int(
                    self.input_batch.num_computed_tokens_cpu[request_index]
                ),
                num_scheduled_tokens=scheduler_output.num_scheduled_tokens[request_id],
                num_prompt_tokens=int(
                    self.input_batch.num_prompt_tokens[request_index]
                ),
                spec_decode_active=spec_decode_metadata is not None,
            )
        )
        if candidate_ids is None:
            return None
        return request_id, candidate_ids

    def _commit_dynamic_draft_vocab_prefill_bootstrap(
        self,
        bootstrap: tuple[str, torch.Tensor] | None,
        sampled_token_ids: torch.Tensor,
    ) -> None:
        if bootstrap is None:
            return
        if sampled_token_ids.dtype != torch.int32:
            raise RuntimeError(
                "Dynamic prefill bootstrap requires int32 sampled token IDs."
            )

        update_dynamic_draft_vocab = getattr(
            getattr(self, "drafter", None),
            "update_dynamic_draft_vocab",
            None,
        )
        if update_dynamic_draft_vocab is None:
            raise RuntimeError(
                "Dynamic prefill bootstrap requires the GPU dynamic-vocab proposer."
            )

        request_id, candidate_ids = bootstrap
        update_dynamic_draft_vocab(candidate_ids, sampled_token_ids)
        self._dynamic_draft_vocab_prefill_bootstrap.mark_consumed(request_id)
        logger.info(
            "Applied one-shot target-logits dynamic-vocab prefill bootstrap: topk=%d.",
            self.dynamic_draft_vocab_prefill_topk,
        )

    def _sample(
        self,
        scheduler_output: "SchedulerOutput",
        logits: torch.Tensor | None,
        spec_decode_metadata: SpecDecodeMetadata | None,
        sample_hidden_states: torch.Tensor,
        logits_indices: torch.Tensor | None,
    ) -> SamplerOutput:
        # Sample the next token and get logprobs if needed.
        sampling_metadata = self.input_batch.sampling_metadata
        self._ddtree_accepted_rows_cpu_sidecar = None
        self._ddtree_sampled_token_counts_cpu_sidecar = None
        # Update output token ids with tokens sampled in last step
        # if async scheduling and required by current sampling params.
        self.input_batch.update_async_output_token_ids()
        _maybe_dump_sm70_sample_tensors(
            sample_hidden_states,
            logits,
            "pre_sample",
            self._make_sm70_sample_dump_metadata(logits_indices),
            diagnostics=self._diagnostics,
        )
        _maybe_dump_sm70_qwen_layer_graph_buffers(
            "pre_sample", diagnostics=self._diagnostics
        )
        _maybe_sync_sm70_sample_tensors(
            sample_hidden_states, diagnostics=self._diagnostics
        )
        if spec_decode_metadata is None:
            if logits is None and self._can_use_sm70_compact_topk20_tokens(
                scheduler_output, spec_decode_metadata
            ):
                topk_token_ids, topk_logits = self.model.get_topk_tokens_and_logits(
                    sample_hidden_states,
                    20,
                )
                compact_sampled = self.sampler.sm70_compact_topk20_pairs_sample(
                    topk_logits,
                    topk_token_ids,
                    sampling_metadata,
                )
                if compact_sampled is not None:
                    logger.info_once(
                        "SM70 TP-local exact top-k20 random sampling path enabled."
                    )
                    return SamplerOutput(
                        sampled_token_ids=compact_sampled.to(torch.int32).unsqueeze(-1),
                        logprobs_tensors=None,
                    )
            sampler_output = self._sample_greedy_token_fastpath(
                logits,
                sampling_metadata,
                sample_hidden_states,
            )
            if sampler_output is not None:
                return sampler_output
            if logits is None:
                logits = self.model.compute_logits(sample_hidden_states)
            assert logits is not None
            return self.sampler(
                logits=logits,
                sampling_metadata=sampling_metadata,
            )

        spec_config = self.speculative_config
        ddtree_payloads = scheduler_output.scheduled_ddtree_payloads or {}
        ddtree_tree_candidate = (
            spec_config is not None
            and spec_config.use_dflash_ddtree()
            and not spec_config.ddtree_disable_tree_verify
            and bool(ddtree_payloads)
        )
        ddtree_greedy_candidate = (
            ddtree_tree_candidate
            and self._ddtree_greedy_sampling_supported(sampling_metadata)
        )
        ddtree_stochastic_candidate = (
            ddtree_tree_candidate
            and self._ddtree_stochastic_sampling_supported(sampling_metadata)
        )
        if (
            ddtree_greedy_candidate
            and logits is None
            and self._can_use_ddtree_greedy_top_tokens(
                scheduler_output, spec_decode_metadata
            )
        ):
            ddtree_profile_enabled = _dflash_ddtree_worker_profile_enabled()
            top_tokens_t0 = time.perf_counter() if ddtree_profile_enabled else 0.0
            top_tokens_start_event = None
            top_tokens_end_event = None
            if ddtree_profile_enabled and sample_hidden_states.is_cuda:
                top_tokens_start_event = torch.cuda.Event(enable_timing=True)
                top_tokens_end_event = torch.cuda.Event(enable_timing=True)
                stream = torch.cuda.current_stream(sample_hidden_states.device)
                top_tokens_start_event.record(stream)
            top_tokens = self.model.get_top_tokens(sample_hidden_states)
            if top_tokens_end_event is not None:
                top_tokens_end_event.record(
                    torch.cuda.current_stream(sample_hidden_states.device)
                )
            top_tokens_enqueue_ms = (
                (time.perf_counter() - top_tokens_t0) * 1000.0
                if ddtree_profile_enabled
                else 0.0
            )
            sampler_t0 = time.perf_counter() if ddtree_profile_enabled else 0.0
            sampler_kind = "cpu"
            ddtree_result = None
            ddtree_sampler_output = None
            if (
                os.getenv("VLLM_DFLASH_DDTREE_GPU_SAMPLER", "1") != "0"
                and logits_indices is not None
                and self._ddtree_parent_metadata is not None
            ):
                ddtree_sampler_output = (
                    greedy_sample_ddtree_payloads_from_top_tokens_gpu(
                        compact_top_tokens=top_tokens,
                        compact_input_ids=self.input_ids.gpu[logits_indices],
                        parent_ids=self._ddtree_parent_metadata.parent_ids,
                        num_draft_tokens=spec_decode_metadata.num_draft_tokens,
                    )
                )
                if ddtree_sampler_output is not None:
                    sampler_kind = "gpu"
            if ddtree_sampler_output is None:
                ddtree_result = greedy_sample_ddtree_payloads_from_top_tokens(
                    req_ids=self.input_batch.req_ids[: self.input_batch.num_reqs],
                    payload_by_req_id=ddtree_payloads,
                    compact_top_tokens=top_tokens,
                    num_draft_tokens=spec_decode_metadata.num_draft_tokens,
                )
                if ddtree_result is not None:
                    ddtree_sampler_output = ddtree_result.sampler_output
                    self._cache_ddtree_accepted_rows_cpu(ddtree_result)
            if ddtree_profile_enabled:
                top_tokens_cuda_ms = -1.0
                if (
                    top_tokens_start_event is not None
                    and top_tokens_end_event is not None
                ):
                    try:
                        if top_tokens_end_event.query():
                            top_tokens_cuda_ms = top_tokens_start_event.elapsed_time(
                                top_tokens_end_event
                            )
                    except RuntimeError:
                        top_tokens_cuda_ms = -1.0
                logger.info(
                    "DFLASH_DDTREE_WORKER_PROFILE top_token_path "
                    "top_tokens_enqueue_ms=%.3f top_tokens_cuda_ms=%.3f "
                    "sampler_wall_ms=%.3f sampler_kind=%s "
                    "rows=%d reqs=%d device=%s dtype=%s",
                    top_tokens_enqueue_ms,
                    top_tokens_cuda_ms,
                    (time.perf_counter() - sampler_t0) * 1000.0,
                    sampler_kind,
                    int(top_tokens.shape[0]),
                    self.input_batch.num_reqs,
                    top_tokens.device,
                    top_tokens.dtype,
                )
            if ddtree_sampler_output is not None:
                return ddtree_sampler_output
            _dflash_ddtree_debug_log(
                "greedy top-token sampler returned None reqs=%d token_rows=%d "
                "num_draft_tokens=%s payloads=%d",
                self.input_batch.num_reqs,
                top_tokens.shape[0],
                list(spec_decode_metadata.num_draft_tokens),
                len(ddtree_payloads),
            )

        if (
            ddtree_stochastic_candidate
            and logits is None
            and spec_decode_metadata is not None
            and self._can_use_ddtree_stochastic_topk_tokens(
                scheduler_output, spec_decode_metadata
            )
        ):
            sampling_metadata = self.input_batch.sampling_metadata
            top_k_width = self._ddtree_stochastic_topk_width(sampling_metadata)
            assert top_k_width is not None
            ddtree_profile_enabled = _dflash_ddtree_worker_profile_enabled()
            topk_t0 = time.perf_counter() if ddtree_profile_enabled else 0.0
            topk_token_ids, topk_logits = self.model.get_topk_tokens_and_logits(
                sample_hidden_states,
                top_k_width,
            )
            topk_ms = (
                (time.perf_counter() - topk_t0) * 1000.0
                if ddtree_profile_enabled
                else 0.0
            )
            sampler_t0 = time.perf_counter() if ddtree_profile_enabled else 0.0
            ddtree_result = stochastic_sample_ddtree_payloads_from_topk(
                req_ids=self.input_batch.req_ids[: self.input_batch.num_reqs],
                payload_by_req_id=ddtree_payloads,
                target_topk_token_ids=topk_token_ids,
                target_topk_logits=topk_logits,
                num_draft_tokens=spec_decode_metadata.num_draft_tokens,
                temperature=sampling_metadata.temperature,
                top_k=sampling_metadata.top_k,
                top_p=sampling_metadata.top_p,
                generators=sampling_metadata.generators,
                top_k_cpu=sampling_metadata.top_k_cpu,
            )
            if ddtree_profile_enabled:
                logger.info(
                    "DFLASH_DDTREE_WORKER_PROFILE stochastic_topk_path "
                    "topk_wall_ms=%.3f sampler_wall_ms=%.3f rows=%d "
                    "top_k_width=%d reqs=%d device=%s dtype=%s",
                    topk_ms,
                    (time.perf_counter() - sampler_t0) * 1000.0,
                    int(topk_logits.shape[0]),
                    int(topk_logits.shape[1]),
                    self.input_batch.num_reqs,
                    topk_logits.device,
                    topk_logits.dtype,
                )
            if ddtree_result is not None:
                self._cache_ddtree_accepted_rows_cpu(ddtree_result)
                if _dflash_ddtree_debug_enabled():
                    first_result = (
                        ddtree_result.verification_results[0]
                        if ddtree_result.verification_results
                        else None
                    )
                    _dflash_ddtree_debug_log(
                        "stochastic top-k sampler used reqs=%d "
                        "first_accepted=%s first_output=%s",
                        len(ddtree_result.verification_results),
                        None
                        if first_result is None
                        else first_result.accepted_node_indices,
                        None if first_result is None else first_result.output_token_ids,
                    )
                return ddtree_result.sampler_output
            _dflash_ddtree_debug_log(
                "stochastic top-k sampler returned None reqs=%d rows=%d "
                "top_k_width=%d num_draft_tokens=%s payloads=%d",
                self.input_batch.num_reqs,
                topk_logits.shape[0],
                top_k_width,
                list(spec_decode_metadata.num_draft_tokens),
                len(ddtree_payloads),
            )

        if logits is None:
            logits = self.model.compute_logits(sample_hidden_states)
        assert logits is not None

        if ddtree_greedy_candidate and spec_decode_metadata is not None:
            if _dflash_ddtree_trace_path() is not None:
                trace_payload: dict[str, object] = {
                    "req_ids": list(
                        self.input_batch.req_ids[: self.input_batch.num_reqs]
                    ),
                    "num_draft_tokens": list(spec_decode_metadata.num_draft_tokens),
                    "query_start_loc": (
                        self.query_start_loc.gpu[: self.input_batch.num_reqs + 1]
                        .detach()
                        .cpu()
                        .tolist()
                    ),
                    "seq_lens": (
                        self.seq_lens[: self.input_batch.num_reqs]
                        .detach()
                        .cpu()
                        .tolist()
                    ),
                    "num_computed_tokens": (
                        self.num_computed_tokens[: self.input_batch.num_reqs]
                        .detach()
                        .cpu()
                        .tolist()
                    ),
                    "scheduled_spec_decode_tokens": {
                        req_id: list(tokens)
                        for req_id, tokens in (
                            scheduler_output.scheduled_spec_decode_tokens.items()
                        )
                    },
                }
                row_trace_enabled = _dflash_ddtree_verify_row_trace_enabled()
                if row_trace_enabled:
                    context_limit = _dflash_ddtree_verify_row_trace_context_limit()
                    context_rows: list[dict[str, object]] = []
                    req_ids = self.input_batch.req_ids[: self.input_batch.num_reqs]
                    for req_idx, req_id in enumerate(req_ids):
                        token_count = int(self.input_batch.num_tokens_no_spec[req_idx])
                        if context_limit < 0:
                            tail_start = 0
                        elif context_limit == 0:
                            tail_start = token_count
                        else:
                            tail_start = max(0, token_count - context_limit)
                        token_tail = self.input_batch.token_ids_cpu[
                            req_idx,
                            tail_start:token_count,
                        ].tolist()
                        context_rows.append(
                            {
                                "req_id": req_id,
                                "req_idx": req_idx,
                                "num_tokens_no_spec": token_count,
                                "token_ids_tail_start": tail_start,
                                "token_ids_tail": token_tail,
                                "context_is_full": tail_start == 0,
                            }
                        )
                    trace_payload["verify_row_trace_context_limit"] = context_limit
                    trace_payload["context_token_ids_by_req"] = context_rows
                    trace_payload["verify_row_trace_note"] = (
                        "For offline recompute, use each request context plus the "
                        "sampler_verify verifier_rows[path_token_ids]. Row 0 is "
                        "the root verifier row."
                    )
                if logits_indices is not None:
                    compact_input_ids = (
                        self.input_ids.gpu[logits_indices].detach().cpu().tolist()
                    )
                    compact_positions = (
                        self.positions[logits_indices].detach().cpu().tolist()
                    )
                    trace_payload["logits_indices"] = (
                        logits_indices.detach().cpu().tolist()
                    )
                    trace_payload["compact_input_ids"] = compact_input_ids
                    trace_payload["compact_positions"] = compact_positions
                    if self.uses_mrope:
                        trace_payload["compact_mrope_positions"] = (
                            self.mrope_positions.gpu[:, logits_indices]
                            .detach()
                            .cpu()
                            .tolist()
                        )
                    if row_trace_enabled:
                        compact_mrope_positions = trace_payload.get(
                            "compact_mrope_positions"
                        )
                        compact_rows_by_req: list[dict[str, object]] = []
                        row_offset = 0
                        for req_idx, (req_id, draft_len) in enumerate(
                            zip(
                                self.input_batch.req_ids[: self.input_batch.num_reqs],
                                spec_decode_metadata.num_draft_tokens,
                                strict=True,
                            )
                        ):
                            row_count = int(draft_len) + 1
                            row_end = row_offset + row_count
                            row_trace: dict[str, object] = {
                                "req_id": req_id,
                                "req_idx": req_idx,
                                "row_offset": row_offset,
                                "row_count": row_count,
                                "row_input_ids": compact_input_ids[row_offset:row_end],
                                "row_positions": compact_positions[row_offset:row_end],
                            }
                            if isinstance(compact_mrope_positions, list):
                                row_trace["row_mrope_positions"] = [
                                    dim_positions[row_offset:row_end]
                                    for dim_positions in compact_mrope_positions
                                    if isinstance(dim_positions, list)
                                ]
                            compact_rows_by_req.append(row_trace)
                            row_offset = row_end
                        trace_payload["compact_rows_by_req"] = compact_rows_by_req
                _dflash_ddtree_trace_event("ddtree_sample_inputs", trace_payload)
            ddtree_result = greedy_sample_ddtree_payloads(
                req_ids=self.input_batch.req_ids[: self.input_batch.num_reqs],
                payload_by_req_id=ddtree_payloads,
                compact_logits=logits,
                num_draft_tokens=spec_decode_metadata.num_draft_tokens,
            )
            if ddtree_result is not None:
                self._cache_ddtree_accepted_rows_cpu(ddtree_result)
                if _dflash_ddtree_debug_enabled():
                    first_result = (
                        ddtree_result.verification_results[0]
                        if ddtree_result.verification_results
                        else None
                    )
                    _dflash_ddtree_debug_log(
                        "greedy sampler used reqs=%d first_accepted=%s first_output=%s",
                        len(ddtree_result.verification_results),
                        None
                        if first_result is None
                        else first_result.accepted_node_indices,
                        None if first_result is None else first_result.output_token_ids,
                    )
                return ddtree_result.sampler_output
            _dflash_ddtree_debug_log(
                "greedy sampler returned None reqs=%d logits_rows=%d "
                "num_draft_tokens=%s payloads=%d",
                self.input_batch.num_reqs,
                logits.shape[0],
                list(spec_decode_metadata.num_draft_tokens),
                len(ddtree_payloads),
            )
            raise RuntimeError(
                "DDTree greedy sampler could not match scheduled tree "
                "payloads to verifier rows."
            )
        elif ddtree_stochastic_candidate and spec_decode_metadata is not None:
            ddtree_result = stochastic_sample_ddtree_payloads(
                req_ids=self.input_batch.req_ids[: self.input_batch.num_reqs],
                payload_by_req_id=ddtree_payloads,
                compact_logits=logits,
                num_draft_tokens=spec_decode_metadata.num_draft_tokens,
                temperature=sampling_metadata.temperature,
                top_k=sampling_metadata.top_k,
                top_p=sampling_metadata.top_p,
                generators=sampling_metadata.generators,
                top_k_cpu=sampling_metadata.top_k_cpu,
            )
            if ddtree_result is not None:
                self._cache_ddtree_accepted_rows_cpu(ddtree_result)
                if _dflash_ddtree_debug_enabled():
                    first_result = (
                        ddtree_result.verification_results[0]
                        if ddtree_result.verification_results
                        else None
                    )
                    _dflash_ddtree_debug_log(
                        "stochastic sampler used reqs=%d first_accepted=%s "
                        "first_output=%s",
                        len(ddtree_result.verification_results),
                        None
                        if first_result is None
                        else first_result.accepted_node_indices,
                        None if first_result is None else first_result.output_token_ids,
                    )
                return ddtree_result.sampler_output
            _dflash_ddtree_debug_log(
                "stochastic sampler returned None reqs=%d logits_rows=%d "
                "num_draft_tokens=%s payloads=%d",
                self.input_batch.num_reqs,
                logits.shape[0],
                list(spec_decode_metadata.num_draft_tokens),
                len(ddtree_payloads),
            )
            raise RuntimeError(
                "DDTree stochastic sampler could not match scheduled tree "
                "payloads to verifier rows."
            )
        elif ddtree_tree_candidate:
            _dflash_ddtree_debug_log(
                "DDTree sampler unsupported all_greedy=%s max_logprobs=%s "
                "logprob_token_ids=%s no_penalties=%s allowed_mask=%s "
                "bad_words=%s logitsprocs_non_argmax=%d "
                "logitsprocs_argmax=%d",
                sampling_metadata.all_greedy,
                sampling_metadata.max_num_logprobs,
                bool(sampling_metadata.logprob_token_ids),
                sampling_metadata.no_penalties,
                sampling_metadata.allowed_token_ids_mask is not None,
                bool(sampling_metadata.bad_words_token_ids),
                len(sampling_metadata.logitsprocs.non_argmax_invariant),
                len(sampling_metadata.logitsprocs.argmax_invariant),
            )
            raise RuntimeError(
                "dflash_ddtree supports stochastic sampling only for "
                "temperature/top_p/top_k/seed requests without logprobs, "
                "penalties, allowed/bad words, thinking budget, or logits "
                "processors. Disable dflash_ddtree for unsupported sampling "
                "features."
            )

        # Update spec_token_ids with real draft tokens from pre step only when
        # output_token_ids is needed (penalties or bad_words are in use).
        if self.use_async_scheduling and self._draft_token_req_ids is not None:
            draft_token_ids_cpu, draft_token_req_ids = self._get_draft_token_ids_cpu()
            self.input_batch.update_async_spec_token_ids(
                draft_token_ids_cpu,
                draft_token_req_ids,
            )

        draft_probs = self._get_spec_decode_draft_probs(spec_decode_metadata)
        draft_confidence_logits = self._get_spec_decode_confidence_logits(
            spec_decode_metadata
        )
        if (
            self.speculative_config is not None
            and self.speculative_config.method == "mtp"
            and self.speculative_config.draft_sample_method == "probabilistic"
            and not sampling_metadata.all_greedy
            and draft_probs is None
            and _non_greedy_rows_carry_drafts(sampling_metadata, spec_decode_metadata)
        ):
            raise RuntimeError(
                "MTP probabilistic draft sampling requires draft probability "
                "rows for exact rejection sampling. Missing draft_probs would "
                "silently fall back to an invalid no-draft-probability "
                "acceptance path and can corrupt output quality."
            )
        if _V41_TRUNC and len(spec_decode_metadata.num_draft_tokens) == 1:
            from vllm.model_executor.layers.quantization import gguf_shared_runtime

            trunc = gguf_shared_runtime.current_trunc(self.device)
            if trunc is not None:
                # Draft i is verify position i + 1; positions >= trunc were not
                # fully computed, so they can never be accepted.
                drafts = spec_decode_metadata.draft_token_ids
                index = torch.arange(drafts.numel(), device=drafts.device)
                spec_decode_metadata.draft_token_ids = torch.where(
                    index + 1 >= trunc, torch.full_like(drafts, -1), drafts
                )
        sampler_output = self.rejection_sampler(
            spec_decode_metadata,
            draft_probs,
            logits,
            sampling_metadata,
            draft_confidence_logits=draft_confidence_logits,
        )
        target_candidate_ids = self.rejection_sampler.take_last_target_candidate_ids()
        update_dynamic_draft_vocab = getattr(
            getattr(self, "drafter", None), "update_dynamic_draft_vocab", None
        )
        if target_candidate_ids is not None and update_dynamic_draft_vocab is not None:
            update_dynamic_draft_vocab(
                target_candidate_ids,
                sampler_output.sampled_token_ids,
            )
        if self._diagnostics.channels["mtp_step"].policy.directory:
            sampled_token_ids = sampler_output.sampled_token_ids
            valid_sampled_count = _count_contiguous_spec_tokens(sampled_token_ids)
            payload: dict[str, object] = {
                "req_ids": list(self.input_batch.req_ids[: self.input_batch.num_reqs]),
                "sampled_token_ids": sampled_token_ids,
                "valid_sampled_count": valid_sampled_count,
                "draft_token_ids": spec_decode_metadata.draft_token_ids,
                "num_draft_tokens": spec_decode_metadata.num_draft_tokens,
                "cu_num_draft_tokens": spec_decode_metadata.cu_num_draft_tokens,
                "cu_num_sampled_tokens": spec_decode_metadata.cu_num_sampled_tokens,
                "target_logits_indices": spec_decode_metadata.target_logits_indices,
                "bonus_logits_indices": spec_decode_metadata.bonus_logits_indices,
                "logits_indices": spec_decode_metadata.logits_indices,
                "num_computed_tokens_cpu": (
                    self.input_batch.num_computed_tokens_cpu_tensor[
                        : self.input_batch.num_reqs
                    ].clone()
                ),
                "num_tokens_no_spec": (
                    self.input_batch.num_tokens_no_spec[: self.input_batch.num_reqs]
                ),
                "num_prompt_tokens": (
                    self.input_batch.num_prompt_tokens_cpu_tensor[
                        : self.input_batch.num_reqs
                    ].clone()
                ),
            }
            logits_indices = spec_decode_metadata.logits_indices
            payload["sample_input_ids"] = self.input_ids.gpu[logits_indices]
            payload["sample_positions"] = self.positions[logits_indices]
            if self.valid_sampled_token_count_gpu is not None:
                payload["prev_valid_sampled_token_count_gpu"] = (
                    self.valid_sampled_token_count_gpu
                )
            _maybe_dump_sm70_mtp_step(
                "sample_output", payload, diagnostics=self._diagnostics
            )
        return sampler_output

    def _can_use_greedy_token_fastpath(
        self,
        scheduler_output: "SchedulerOutput",
        spec_decode_metadata: SpecDecodeMetadata | None,
    ) -> bool:
        if not self.sm70_greedy_token_fastpath:
            self._trace_greedy_token_fastpath("disabled")
            return False
        if spec_decode_metadata is not None:
            self._trace_greedy_token_fastpath("spec_decode")
            return False
        if self.is_pooling_model or self.broadcast_pp_output:
            self._trace_greedy_token_fastpath("pooling_or_pp_broadcast")
            return False
        if scheduler_output.has_structured_output_requests:
            self._trace_greedy_token_fastpath("structured_output")
            return False
        if self.device.type != "cuda":
            self._trace_greedy_token_fastpath("non_cuda")
            return False
        if torch.cuda.get_device_capability(self.device) != (7, 0):
            self._trace_greedy_token_fastpath("non_sm70")
            return False
        if not hasattr(self.model, "get_top_tokens"):
            self._trace_greedy_token_fastpath("missing_get_top_tokens")
            return False

        sampling_metadata = self.input_batch.sampling_metadata
        if not sampling_metadata.all_greedy:
            self._trace_greedy_token_fastpath("non_greedy")
            return False
        if sampling_metadata.max_num_logprobs is not None:
            self._trace_greedy_token_fastpath("logprobs")
            return False
        if sampling_metadata.logprob_token_ids:
            self._trace_greedy_token_fastpath("logprob_token_ids")
            return False
        if not sampling_metadata.no_penalties:
            self._trace_greedy_token_fastpath("penalties")
            return False
        if sampling_metadata.allowed_token_ids_mask is not None:
            self._trace_greedy_token_fastpath("allowed_token_ids")
            return False
        if sampling_metadata.bad_words_token_ids:
            self._trace_greedy_token_fastpath("bad_words")
            return False
        if not self._non_argmax_logits_processors_inactive(sampling_metadata):
            self._trace_greedy_token_fastpath("logits_processor")
            return False
        self._trace_greedy_token_fastpath("enabled")
        return True

    def _can_use_sm70_compact_topk20_tokens(
        self,
        scheduler_output: "SchedulerOutput",
        spec_decode_metadata: SpecDecodeMetadata | None,
    ) -> bool:
        if not self.vllm_config.kernel_config.layer_execution.value("compact_topk20"):
            return False
        if not self.vllm_config.kernel_config.layer_execution.value("tp_local_topk20"):
            return False
        if spec_decode_metadata is not None:
            return self._reject_sm70_compact_topk20_tokens("spec_decode")
        if self.is_pooling_model or self.broadcast_pp_output:
            return self._reject_sm70_compact_topk20_tokens("pooling_or_pp_broadcast")
        if scheduler_output.has_structured_output_requests:
            return self._reject_sm70_compact_topk20_tokens("structured_output")
        if self.device.type != "cuda":
            return self._reject_sm70_compact_topk20_tokens("non_cuda")
        if torch.cuda.get_device_capability(self.device) != (7, 0):
            return self._reject_sm70_compact_topk20_tokens("non_sm70")
        if self.model_config.get_vocab_size() != 248320:
            return self._reject_sm70_compact_topk20_tokens("vocab_size")
        if not hasattr(self.model, "get_topk_tokens_and_logits"):
            return self._reject_sm70_compact_topk20_tokens("missing_model_topk")
        if self.input_batch.num_reqs != 1:
            return self._reject_sm70_compact_topk20_tokens("batch_size")

        sampling_metadata = self.input_batch.sampling_metadata
        if not sampling_metadata.all_random or sampling_metadata.all_greedy:
            return self._reject_sm70_compact_topk20_tokens("sampling_mode")
        if sampling_metadata.max_num_logprobs is not None:
            return self._reject_sm70_compact_topk20_tokens("logprobs")
        if sampling_metadata.logprob_token_ids:
            return self._reject_sm70_compact_topk20_tokens("logprob_token_ids")
        if not sampling_metadata.no_penalties:
            return self._reject_sm70_compact_topk20_tokens("penalties")
        if sampling_metadata.allowed_token_ids_mask is not None:
            return self._reject_sm70_compact_topk20_tokens("allowed_token_ids")
        if sampling_metadata.bad_words_token_ids:
            return self._reject_sm70_compact_topk20_tokens("bad_words")
        holder = sampling_metadata.thinking_budget_state_holder
        if holder is not None and holder.has_tracked_requests():
            return self._reject_sm70_compact_topk20_tokens("thinking_budget")
        if not self._non_argmax_logits_processors_inactive(sampling_metadata):
            return self._reject_sm70_compact_topk20_tokens("logits_processor")
        if not self._sm70_argmax_logits_processors_inactive(sampling_metadata):
            return self._reject_sm70_compact_topk20_tokens(
                "argmax_invariant_logits_processor"
            )
        if sampling_metadata.top_k_cpu != (20,):
            return self._reject_sm70_compact_topk20_tokens("top_k")

        top_p_cpu = sampling_metadata.top_p_cpu
        if top_p_cpu is None or len(top_p_cpu) != 1 or abs(top_p_cpu[0] - 0.95) > 1e-6:
            return self._reject_sm70_compact_topk20_tokens("top_p")
        temperature_cpu = sampling_metadata.temperature_cpu
        if (
            temperature_cpu is None
            or len(temperature_cpu) != 1
            or abs(temperature_cpu[0] - 1.0) > 1e-6
        ):
            return self._reject_sm70_compact_topk20_tokens("temperature")
        return True

    @staticmethod
    def _reject_sm70_compact_topk20_tokens(reason: str) -> bool:
        logger.info_once("SM70 TP-local top-k20 route rejected: %s", reason)
        return False

    @staticmethod
    def _sm70_argmax_logits_processors_inactive(
        sampling_metadata: SamplingMetadata,
    ) -> bool:
        from vllm.v1.sample.logits_processor.builtin import MinPLogitsProcessor

        for processor in sampling_metadata.logitsprocs.argmax_invariant:
            if isinstance(processor, MinPLogitsProcessor):
                if processor.min_p_count:
                    return False
                continue
            return False
        return True

    def _trace_greedy_token_fastpath(self, reason: str) -> None:
        if not self.sm70_greedy_token_fastpath_trace:
            return
        if reason in self._sm70_greedy_token_fastpath_trace_seen:
            return
        self._sm70_greedy_token_fastpath_trace_seen.add(reason)
        logger.warning("SM70 greedy token fastpath trace: %s", reason)

    @staticmethod
    def _non_argmax_logits_processors_inactive(
        sampling_metadata: SamplingMetadata,
    ) -> bool:
        for logitproc in sampling_metadata.logitsprocs.non_argmax_invariant:
            min_toks = getattr(logitproc, "min_toks", None)
            if min_toks is not None:
                if min_toks:
                    return False
                continue
            biases = getattr(logitproc, "biases", None)
            if biases is not None:
                if biases:
                    return False
                continue
            return False
        return True

    def _sample_greedy_token_fastpath(
        self,
        logits: torch.Tensor | None,
        sampling_metadata: SamplingMetadata,
        sample_hidden_states: torch.Tensor,
    ) -> SamplerOutput | None:
        if logits is not None:
            return None
        if not sampling_metadata.all_greedy:
            return None
        if sampling_metadata.max_num_logprobs is not None:
            return None
        if sampling_metadata.logprob_token_ids:
            return None

        top_tokens = self.model.get_top_tokens(sample_hidden_states)
        sampled = top_tokens.to(torch.int32).unsqueeze(-1)
        return SamplerOutput(sampled_token_ids=sampled, logprobs_tensors=None)

    def _bookkeeping_sync(
        self,
        scheduler_output: "SchedulerOutput",
        sampler_output: SamplerOutput,
        logits: torch.Tensor | None,
        hidden_states: torch.Tensor,
        num_scheduled_tokens: int,
    ) -> tuple[
        dict[str, int],
        LogprobsLists | None,
        list[list[int]],
        dict[str, LogprobsTensors | None],
        list[str],
        dict[str, int],
        list[int],
    ]:
        num_nans_in_logits = {}
        if envs.VLLM_COMPUTE_NANS_IN_LOGITS and logits is not None:
            num_nans_in_logits = self._get_nans_in_logits(logits)

        num_reqs = self.input_batch.num_reqs
        discard_sampled_tokens_req_indices = np.nonzero(
            self.discard_request_mask.np[:num_reqs]
        )[0]
        for i in discard_sampled_tokens_req_indices:
            gen = self.input_batch.generators.get(int(i))
            if gen is not None:
                gen.set_offset(gen.get_offset() - 4)

        # Copy some objects so they don't get modified after returning.
        # This is important when using async scheduling.
        req_ids_output_copy = self.input_batch.req_ids.copy()
        req_id_to_index_output_copy = self.input_batch.req_id_to_index.copy()

        num_sampled_tokens = sampler_output.sampled_token_ids.shape[0]
        sampled_token_ids = sampler_output.sampled_token_ids
        logprobs_tensors = sampler_output.logprobs_tensors
        invalid_req_indices = []
        logprobs_lists = None
        if not self.use_async_scheduling:
            # Sync scheduling: issue routed experts D2H into the pinned
            # CPU buffer BEFORE ``_to_list`` below. ``_to_list`` does
            # ``event.synchronize()`` on the async copy stream which
            # waits for every D2H queued on the default stream since
            # the last sync, so this enqueue is naturally covered
            # without requiring its own synchronize.
            if self.routed_experts_initialized:
                buf = self.routed_experts_capturer.get_device_buffer()
                total = scheduler_output.total_num_scheduled_tokens
                self.routed_experts_cpu[:total].copy_(buf[:total], non_blocking=True)
                self.routed_experts_slot_mapping_cpu[:total].copy_(
                    self.routed_experts_slot_mapping_device[:total],
                    non_blocking=True,
                )

            # Get the valid generated tokens.
            max_gen_len = sampled_token_ids.shape[-1]
            if max_gen_len == 1:
                # No spec decode tokens.
                valid_sampled_token_ids = self._to_list(sampled_token_ids)
                # Mask out the sampled tokens that should not be sampled.
                for i in discard_sampled_tokens_req_indices:
                    valid_sampled_token_ids[int(i)].clear()

                if logprobs_tensors is not None:
                    logprobs_lists = logprobs_tensors.tolists()
            else:
                # Includes spec decode tokens.
                valid_sampled_token_ids, logprobs_lists = RejectionSampler.parse_output(
                    sampled_token_ids,
                    self.input_batch.vocab_size,
                    discard_sampled_tokens_req_indices,
                    logprobs_tensors=logprobs_tensors,
                )
        else:
            valid_sampled_token_ids = []
            invalid_req_indices = discard_sampled_tokens_req_indices.tolist()
            invalid_req_indices_set = set(invalid_req_indices)

            # Cache the sampled tokens on the GPU and avoid CPU sync.
            # These will be copied into input_ids in the next step
            # when preparing inputs.
            # With spec decoding, this is done in propose_draft_token_ids().
            if self.input_batch.prev_sampled_token_ids is None:
                assert sampled_token_ids.shape[-1] == 1
                self.input_batch.prev_sampled_token_ids = sampled_token_ids
            self.input_batch.prev_req_id_to_index = {
                req_id: i
                for i, req_id in enumerate(self.input_batch.req_ids)
                if i not in invalid_req_indices_set
            }

        # Cache the sampled tokens in the model runner, so that the scheduler
        # doesn't need to send them back.
        # NOTE(woosuk): As an exception, when using PP, the scheduler sends
        # the sampled tokens back, because there's no direct communication
        # between the first-stage worker and the last-stage worker.
        req_ids = self.input_batch.req_ids
        for req_idx in range(num_sampled_tokens):
            if self.use_async_scheduling:
                sampled_ids = [-1] if req_idx not in invalid_req_indices_set else None
            else:
                sampled_ids = valid_sampled_token_ids[req_idx]

            num_sampled_ids: int = len(sampled_ids) if sampled_ids else 0

            if not sampled_ids:
                continue

            start_idx = self.input_batch.num_tokens_no_spec[req_idx]
            end_idx = start_idx + num_sampled_ids
            assert end_idx <= self.max_model_len, (
                "Sampled token IDs exceed the max model length. "
                f"Total number of tokens: {end_idx} > max_model_len: "
                f"{self.max_model_len}"
            )

            self.input_batch.token_ids_cpu[req_idx, start_idx:end_idx] = sampled_ids
            self.input_batch.is_token_ids[req_idx, start_idx:end_idx] = True
            self.input_batch.num_tokens_no_spec[req_idx] = end_idx

            req_id = req_ids[req_idx]
            req_state = self.requests[req_id]
            req_state.output_token_ids.extend(sampled_ids)

        # Compute prompt logprobs if needed.
        prompt_logprobs_dict = self._get_prompt_logprobs_dict(
            hidden_states[:num_scheduled_tokens],
            scheduler_output.num_scheduled_tokens,
        )

        return (
            num_nans_in_logits,
            logprobs_lists,
            valid_sampled_token_ids,
            prompt_logprobs_dict,
            req_ids_output_copy,
            req_id_to_index_output_copy,
            invalid_req_indices,
        )

    def synchronize_input_prep(self, skip_sync: bool = False):
        return self._input_transfer.prepare(
            skip_sync=skip_sync,
            # Retain the deferred tree diagnostic override at its existing boundary.
            trace_override=_dflash_ddtree_worker_profile_enabled(),
        )

    def _model_forward(
        self,
        input_ids: torch.Tensor | None = None,
        positions: torch.Tensor | None = None,
        intermediate_tensors: IntermediateTensors | None = None,
        inputs_embeds: torch.Tensor | None = None,
        **model_kwargs: dict[str, Any],
    ) -> Any:
        """Helper method to call the model forward pass.

        This method can be overridden by subclasses for model execution.
        Motivation: We can inspect only this method versus
        the whole execute_model, which has additional logic.

        Args:
            input_ids: Input token IDs
            positions: Token positions
            intermediate_tensors: Tensors from previous pipeline stages
            inputs_embeds: Input embeddings (alternative to input_ids)
            **model_kwargs: Additional model arguments

        Returns:
            Model output tensor
        """
        return self.model(
            input_ids=input_ids,
            positions=positions,
            intermediate_tensors=intermediate_tensors,
            inputs_embeds=inputs_embeds,
            **model_kwargs,
        )

    @staticmethod
    def _is_uniform_decode(
        max_num_scheduled_tokens: int,
        uniform_decode_query_len: int,
        num_tokens: int,
        num_reqs: int,
        force_uniform_decode: bool | None = None,
    ) -> bool:
        """
        Checks if it's a decode batch with same amount scheduled tokens
        across all requests.
        """
        return (
            (
                (max_num_scheduled_tokens == uniform_decode_query_len)
                and (num_tokens == max_num_scheduled_tokens * num_reqs)
            )
            if force_uniform_decode is None
            else force_uniform_decode
        )

    def _compute_force_uniform_decode(
        self,
        scheduler_output: "SchedulerOutput",
    ) -> bool | None:
        """Reject uniform-decode dispatch for hybrid-model prefills.

        A prefill can have the same shape as a uniform decode batch, notably
        when its scheduled token count equals ``1 + num_speculative_tokens``.
        Hybrid backends keep recurrent state and must run that row through the
        prefill path. Derive the phase from this iteration's scheduler output
        rather than ``input_batch`` so the early PP+SP caller observes the
        current step as well.

        ``None`` preserves the normal shape heuristic. ``False`` is only
        returned when a hybrid batch contains an unfinished prompt.
        """
        if not self.model_config.is_hybrid:
            return None

        for new_req in scheduler_output.scheduled_new_reqs:
            num_prompt_tokens = length_from_prompt_token_ids_or_embeds(
                new_req.prompt_token_ids,
                new_req.prompt_embeds,
            )
            if new_req.num_computed_tokens < num_prompt_tokens:
                return False

        cached_reqs = scheduler_output.scheduled_cached_reqs
        for req_id, num_computed_tokens in zip(
            cached_reqs.req_ids,
            cached_reqs.num_computed_tokens,
            strict=True,
        ):
            if num_computed_tokens < self.requests[req_id].num_prompt_tokens:
                return False

        return None

    def _determine_batch_execution_and_padding(
        self,
        num_tokens: int,
        num_reqs: int,
        num_scheduled_tokens_np: np.ndarray,
        max_num_scheduled_tokens: int,
        use_cascade_attn: bool,
        allow_microbatching: bool = True,
        force_eager: bool = False,
        # For cudagraph capture TODO(lucas): Refactor how we capture cudagraphs (will
        # be improved in model runner v2)
        force_uniform_decode: bool | None = None,
        force_has_lora: bool | None = None,
        force_num_active_loras: int | None = None,
        num_encoder_reqs: int = 0,
        attention_context_len: int | None = None,
    ) -> tuple[
        CUDAGraphMode,
        BatchDescriptor,
        bool,
        torch.Tensor | None,
        CUDAGraphStat | None,
    ]:
        uniform_decode = self._is_uniform_decode(
            max_num_scheduled_tokens=max_num_scheduled_tokens,
            uniform_decode_query_len=self.uniform_decode_query_len,
            num_tokens=num_tokens,
            num_reqs=num_reqs,
            force_uniform_decode=force_uniform_decode,
        )
        # Encoder-decoder models only support CG for decoder_step > 0 (no enc_output
        # is present). Also, chunked-prefill is disabled, so batch are uniform.
        has_encoder_output = (
            self.model_config.is_encoder_decoder and num_encoder_reqs > 0
        )

        # Compute LoRA state for cudagraph dispatch
        num_active_loras = (
            force_num_active_loras
            if force_num_active_loras is not None
            else len(self.input_batch.lora_id_to_lora_request)
        )
        has_lora = num_active_loras > 0 if force_has_lora is None else force_has_lora

        if (
            attention_context_len is None
            and uniform_decode
            and num_reqs > 0
            and self.cudagraph_dispatcher.has_attention_context_specialization
        ):
            attention_context_len = int(
                self.optimistic_seq_lens_cpu[:num_reqs].max().item()
            )

        num_tokens_padded = self._pad_for_sequence_parallelism(num_tokens)
        disable_full_for_sm70_gdn_spec_decode = (
            self.vllm_config.compilation_config.runtime.gdn_spec_piecewise
            and self.speculative_config is not None
            and self.uniform_decode_query_len > 1
            and uniform_decode
            and force_uniform_decode is None
            and self.cache_config.mamba_cache_mode == "align"
            and self.kv_cache_config is not None
            and self.kv_cache_config.has_mamba_layers
            and current_platform.is_device_capability(70)
        )
        disable_full_cudagraph = (
            use_cascade_attn
            or has_encoder_output
            or disable_full_for_sm70_gdn_spec_decode
        )
        if disable_full_for_sm70_gdn_spec_decode:
            logger.info_once(
                "Dispatching SM70 active-MTP Mamba/GDN verifier decode "
                "batches through PIECEWISE CUDA graphs by excluding FULL "
                "runtime replay."
            )

        def dispatch_cudagraph(num_tokens, disable_full=False, valid_modes=None):
            return self.cudagraph_dispatcher.dispatch(
                num_tokens=num_tokens,
                has_lora=has_lora,
                uniform_decode=uniform_decode,
                num_active_loras=num_active_loras,
                attention_context_len=attention_context_len,
                valid_modes={CUDAGraphMode.NONE} if force_eager else valid_modes,
                invalid_modes={CUDAGraphMode.FULL} if disable_full else None,
            )

        def validate_attention_context_bucket(
            batch_descriptor: BatchDescriptor,
        ) -> None:
            bucket = batch_descriptor.attention_context_bucket
            if bucket is None:
                return
            if attention_context_len is None or attention_context_len > bucket:
                raise RuntimeError(
                    "Refusing to replay a bounded CUDA graph outside its "
                    f"attention context capacity: context={attention_context_len}, "
                    f"bucket={bucket}, descriptor={batch_descriptor}"
                )

        cudagraph_mode, batch_descriptor = dispatch_cudagraph(
            num_tokens_padded, disable_full=disable_full_cudagraph
        )
        validate_attention_context_bucket(batch_descriptor)
        if disable_full_for_sm70_gdn_spec_decode:
            logger.info_once(
                "SM70 active-MTP Mamba/GDN verifier CUDA graph dispatch "
                "selected runtime=%s descriptor=%s.",
                cudagraph_mode,
                batch_descriptor,
            )
        num_tokens_padded = batch_descriptor.num_tokens
        if self.compilation_config.pass_config.enable_sp:
            assert (
                batch_descriptor.num_tokens
                % self.vllm_config.parallel_config.tensor_parallel_size
                == 0
            ), (
                "Sequence parallelism requires num_tokens to be "
                "a multiple of tensor parallel size"
            )

        # Extra coordination when running data-parallel since we need to coordinate
        # across ranks
        should_ubatch, num_tokens_across_dp = False, None
        if self.vllm_config.parallel_config.data_parallel_size > 1:
            should_ubatch, num_tokens_across_dp, synced_cudagraph_mode = (
                coordinate_batch_across_dp(
                    num_tokens_unpadded=num_tokens,
                    parallel_config=self.parallel_config,
                    allow_microbatching=allow_microbatching,
                    num_tokens_padded=num_tokens_padded,
                    uniform_decode=uniform_decode,
                    cudagraph_mode=cudagraph_mode.value,
                )
            )

            # Extract DP-synced values
            if num_tokens_across_dp is not None:
                dp_rank = self.parallel_config.data_parallel_rank
                num_tokens_padded = int(num_tokens_across_dp[dp_rank].item())
                # Re-dispatch with DP padding so we have the correct batch_descriptor
                cudagraph_mode, batch_descriptor = dispatch_cudagraph(
                    num_tokens_padded,
                    disable_full=disable_full_cudagraph,
                    valid_modes={CUDAGraphMode(synced_cudagraph_mode)},
                )
                validate_attention_context_bucket(batch_descriptor)
                # Assert to make sure the agreed upon token count is correct otherwise
                # num_tokens_across_dp will no-longer be valid
                assert batch_descriptor.num_tokens == num_tokens_padded

        cudagraph_stats = None
        if self.vllm_config.observability_config.cudagraph_metrics:
            cudagraph_stats = CUDAGraphStat(
                num_unpadded_tokens=num_tokens,
                num_padded_tokens=batch_descriptor.num_tokens,
                num_paddings=batch_descriptor.num_tokens - num_tokens,
                runtime_mode=str(cudagraph_mode),
            )

        return (
            cudagraph_mode,
            batch_descriptor,
            should_ubatch,
            num_tokens_across_dp,
            cudagraph_stats,
        )

    def _register_layerwise_nvtx_hooks(self) -> None:
        """
        Register layerwise NVTX hooks if --enable-layerwise-nvtx-tracing is enabled
        to trace detailed information of each layer or module in the model.
        """

        if (
            self.vllm_config.observability_config.enable_layerwise_nvtx_tracing
            and not self.layerwise_nvtx_hooks_registered
        ):
            if self.compilation_config.cudagraph_mode != CUDAGraphMode.NONE:
                logger.debug_once(
                    "layerwise NVTX tracing is not supported when CUDA graph is "
                    "turned off; you may observe part or all of the model "
                    "missing NVTX markers"
                )

            # In STOCK_TORCH_COMPILE mode, after registering hooks here,
            # the __call__ function of nn.module will be recompiled with
            # fullgraph=True. Since nvtx.range_push/pop are not traceable
            # by torch dynamo, we can't register hook functions here
            # because hook functions will also be traced by torch dynamo.
            if (
                self.vllm_config.compilation_config.mode
                == CompilationMode.STOCK_TORCH_COMPILE
            ):
                logger.debug_once(
                    "layerwise NVTX tracing is not supported when "
                    "CompilationMode is STOCK_TORCH_COMPILE, skipping "
                    "function hooks registration"
                )
            else:
                pyt_hooks = PytHooks()
                pyt_hooks.register_hooks(self.model, self.model.__class__.__name__)
                self.layerwise_nvtx_hooks_registered = True

    def _get_slot_mappings(
        self,
        num_tokens_padded: int,
        num_reqs_padded: int,
        num_tokens_unpadded: int,
        ubatch_slices: "UBatchSlices | None" = None,
    ) -> tuple[
        dict[int, torch.Tensor] | None,
        dict[str, torch.Tensor] | list[dict[str, torch.Tensor]] | None,
    ]:
        """
        Build slot mappings in both formats needed by the system.

        Args:
            num_tokens_padded: Total number of tokens (padded)
            num_reqs_padded: Total number of requests (padded)
            num_tokens_unpadded: Actual number of tokens (unpadded)
            ubatch_slices: Optional ubatch slicing info for DBO

        Returns:
            A tuple of:
            - slot_mappings_by_gid: dict[int, torch.Tensor] for attention metadata
            - slot_mappings_by_layer: dict[str, torch.Tensor] or list for ForwardContext
        """
        if not (
            hasattr(self, "kv_cache_config")
            and self.kv_cache_config is not None
            and len(self.kv_cache_config.kv_cache_groups) > 0
        ):
            return None, None

        def _get_slot_mapping(kv_cache_gid: int):
            assert num_reqs_padded is not None and num_tokens_padded is not None
            kv_cache_spec = self.kv_cache_config.kv_cache_groups[
                kv_cache_gid
            ].kv_cache_spec
            if isinstance(kv_cache_spec, EncoderOnlyAttentionSpec):
                slot_mapping = torch.zeros(
                    (num_tokens_padded,),
                    dtype=torch.int64,
                    device=self.device,
                )
            else:
                blk_table = self.input_batch.block_table[kv_cache_gid]
                slot_mapping = blk_table.slot_mapping.gpu[:num_tokens_padded]

            # Fill unused with -1. Needed for reshape_and_cache in full cuda
            # graph mode. `blk_table_tensor` -1 to match mamba PAD_SLOT_ID
            slot_mapping[num_tokens_unpadded:num_tokens_padded].fill_(-1)

            return slot_mapping

        slot_mappings_by_gid = {
            gid: _get_slot_mapping(gid)
            for gid, _ in enumerate(self.kv_cache_config.kv_cache_groups)
        }

        slot_mappings_by_layer: dict[str, torch.Tensor] = {}
        for gid, kv_cache_group in enumerate(self.kv_cache_config.kv_cache_groups):
            slot_mapping = slot_mappings_by_gid[gid]
            for layer_name in kv_cache_group.layer_names:
                slot_mappings_by_layer[layer_name] = slot_mapping

        if ubatch_slices is not None:
            result: list[dict[str, torch.Tensor]] = []
            for ubatch in ubatch_slices:
                sliced_mappings: dict[str, torch.Tensor] = {}
                for layer_name, slot_mapping in slot_mappings_by_layer.items():
                    sliced_mappings[layer_name] = slot_mapping[ubatch.token_slice]
                result.append(sliced_mappings)
            return slot_mappings_by_gid, result

        return slot_mappings_by_gid, slot_mappings_by_layer

    def _is_all_reqs_chunked_prefill(self) -> bool:
        """Check if all scheduled requests are marked to discard sampled tokens.

        This is true when `discard_request_mask` is set for every scheduled
        request (e.g., for chunked prefill requests that are not the last
        prefill chunk)."""
        num_reqs = self.input_batch.num_reqs
        return bool(self.discard_request_mask.np[:num_reqs].all())

    @torch.inference_mode()
    def execute_model(
        self,
        scheduler_output: "SchedulerOutput",
        intermediate_tensors: IntermediateTensors | None = None,
    ) -> ModelRunnerOutput | AsyncModelRunnerOutput | IntermediateTensors | None:
        if self.execute_model_state is not None:
            raise RuntimeError(
                "State error: sample_tokens() must be called "
                "after execute_model() returns None."
            )

        if self.device.type == "cuda":
            self.mixed_prefill_timer.begin(scheduler_output)
        if _V41_TRUNC_CUTOFF:
            from vllm.model_executor.layers.quantization import gguf_shared_runtime

            # Exact only for greedy rows of a single request (positions = rows).
            single = self.input_batch.num_reqs == 1
            greedy = bool(getattr(self.input_batch, "all_greedy", False))
            gguf_shared_runtime.set_trunc_cutoff(
                _V41_TRUNC_CUTOFF if single and greedy else 0
            )

        trace_enabled = (
            bool(self._runtime_trace.async_cpu and self.use_async_scheduling)
            or _dflash_ddtree_worker_profile_enabled()
        )
        trace_step = self._sm70_async_worker_execute_trace_step
        trace_log = trace_enabled and (trace_step % self._async_trace_every == 0)
        if trace_enabled:
            self._sm70_async_worker_execute_trace_step += 1
        trace_t0 = time.perf_counter() if trace_log else 0.0
        trace_preprocess_ms = 0.0
        trace_forward_submit_ms = 0.0
        trace_postprocess_ms = 0.0
        trace_update_states_ms = 0.0
        trace_prepare_inputs_ms = 0.0
        trace_batch_desc_ms = 0.0
        trace_mamba_preprocess_ms = 0.0
        trace_slot_mapping_ms = 0.0
        trace_attn_metadata_ms = 0.0
        trace_model_preprocess_ms = 0.0

        if self.routed_experts_initialized:
            self.routed_experts_capturer.clear_buffer()

        # If ngram_gpu is used, we need to copy the scheduler_output to avoid
        # the modification has influence on the scheduler_output in engine core process.
        # The replace is much faster than deepcopy.
        if (
            self.speculative_config is not None
            and self.speculative_config.use_ngram_gpu()
        ):
            num_scheduled_tokens_copy = scheduler_output.num_scheduled_tokens.copy()
            spec_decode_tokens_copy = (
                scheduler_output.scheduled_spec_decode_tokens.copy()
            )
            scheduler_output = replace(
                scheduler_output,
                num_scheduled_tokens=num_scheduled_tokens_copy,
                scheduled_spec_decode_tokens=spec_decode_tokens_copy,
            )

        if has_kv_transfer_group():
            kv_connector_metadata = scheduler_output.kv_connector_metadata
            assert kv_connector_metadata is not None
            get_kv_transfer_group().handle_preemptions(kv_connector_metadata)

        num_scheduled_tokens = scheduler_output.total_num_scheduled_tokens
        staged_input_prep = self._can_use_sm70_staged_input_prep(scheduler_output)
        trace_preprocess_t0 = time.perf_counter() if trace_log else 0.0
        with (
            record_function_or_nullcontext("gpu_model_runner: preprocess"),
            self.synchronize_input_prep(skip_sync=staged_input_prep),
        ):
            # Update persistent batch states.
            trace_update_states_t0 = time.perf_counter() if trace_log else 0.0
            deferred_state_corrections_fn = self._update_states(scheduler_output)
            if trace_log:
                trace_update_states_ms = (
                    time.perf_counter() - trace_update_states_t0
                ) * 1000.0

            if has_ec_transfer() and not get_ec_transfer().is_consumer:
                with self.maybe_get_ec_connector_output(
                    scheduler_output,
                    encoder_cache=self.encoder_cache,
                ) as ec_connector_output:
                    self._execute_mm_encoder(scheduler_output)
                    return make_empty_encoder_model_runner_output(scheduler_output)

            if not num_scheduled_tokens:
                if (
                    self.parallel_config.distributed_executor_backend
                    == "external_launcher"
                    and self.parallel_config.data_parallel_size > 1
                ):
                    # this is a corner case when both external launcher
                    # and DP are enabled, num_scheduled_tokens could be
                    # 0, and has_unfinished_requests in the outer loop
                    # returns True. before returning early here we call
                    # dummy run to ensure coordinate_batch_across_dp
                    # is called into to avoid out of sync issues.
                    self._dummy_run(1)
                if not has_kv_transfer_group():
                    # Return empty ModelRunnerOutput if no work to do.
                    if trace_log:
                        logger.info(
                            "SM70 async worker trace kind=execute step=%d "
                            "mode=empty total_ms=%.3f scheduled_tokens=%d",
                            trace_step,
                            (time.perf_counter() - trace_t0) * 1000.0,
                            num_scheduled_tokens,
                        )
                    return EMPTY_MODEL_RUNNER_OUTPUT
                return self.kv_connector_no_forward(scheduler_output, self.vllm_config)

            if self.cache_config.kv_sharing_fast_prefill:
                assert not self.num_prompt_logprobs, (
                    "--kv-sharing-fast-prefill produces incorrect "
                    "logprobs for prompt tokens, tokens, please disable "
                    "it when the requests need prompt logprobs"
                )

            if not get_pp_group().is_last_rank:
                self._pp_stage_before_forward()

            num_reqs = self.input_batch.num_reqs
            req_ids = self.input_batch.req_ids
            tokens = [scheduler_output.num_scheduled_tokens[i] for i in req_ids]
            num_scheduled_tokens_np = np.array(tokens, dtype=np.int32)
            max_num_scheduled_tokens = int(num_scheduled_tokens_np.max())
            num_tokens_unpadded = scheduler_output.total_num_scheduled_tokens

            trace_prepare_inputs_t0 = time.perf_counter() if trace_log else 0.0
            logits_indices, spec_decode_metadata = self._prepare_inputs(
                scheduler_output,
                num_scheduled_tokens_np,
            )
            # VLLM_V41_VISION: whether this step holds image-span tokens.
            set_vision = getattr(self.get_model(), "v41_set_vision", None)
            if set_vision is not None:
                set_vision(
                    self.input_ids.np[: scheduler_output.total_num_scheduled_tokens]
                )
            if trace_log:
                trace_prepare_inputs_ms = (
                    time.perf_counter() - trace_prepare_inputs_t0
                ) * 1000.0

            cascade_attn_prefix_lens = None
            # Disable cascade attention when using microbatching (DBO)
            if self.cascade_attn_enabled and not self.parallel_config.use_ubatching:
                # Pre-compute cascade attention prefix lengths
                cascade_attn_prefix_lens = self._compute_cascade_attn_prefix_lens(
                    num_scheduled_tokens_np,
                    self.input_batch.num_computed_tokens_cpu[:num_reqs],
                    scheduler_output.num_common_prefix_blocks,
                )

            trace_batch_desc_t0 = time.perf_counter() if trace_log else 0.0
            (
                cudagraph_mode,
                batch_desc,
                should_ubatch,
                num_tokens_across_dp,
                cudagraph_stats,
            ) = self._determine_batch_execution_and_padding(
                num_tokens=num_tokens_unpadded,
                num_reqs=num_reqs,
                num_scheduled_tokens_np=num_scheduled_tokens_np,
                max_num_scheduled_tokens=max_num_scheduled_tokens,
                use_cascade_attn=cascade_attn_prefix_lens is not None,
                force_uniform_decode=self._compute_force_uniform_decode(
                    scheduler_output
                ),
                num_encoder_reqs=len(scheduler_output.scheduled_encoder_inputs),
            )
            if trace_log:
                trace_batch_desc_ms = (
                    time.perf_counter() - trace_batch_desc_t0
                ) * 1000.0

            logger.debug(
                "Running batch with cudagraph_mode: %s, batch_descriptor: %s, "
                "should_ubatch: %s, num_tokens_across_dp: %s",
                cudagraph_mode,
                batch_desc,
                should_ubatch,
                num_tokens_across_dp,
            )

            num_tokens_padded = batch_desc.num_tokens
            num_reqs_padded = (
                batch_desc.num_reqs if batch_desc.num_reqs is not None else num_reqs
            )
            ubatch_slices, ubatch_slices_padded = maybe_create_ubatch_slices(
                should_ubatch,
                num_scheduled_tokens_np,
                num_tokens_padded,
                num_reqs_padded,
                self.parallel_config.num_ubatches,
            )

            logger.debug(
                "ubatch_slices: %s, ubatch_slices_padded: %s",
                ubatch_slices,
                ubatch_slices_padded,
            )

            # True if any attention backend handles KV cache update separately
            # from forward() (i.e., forward_includes_kv_cache_update=False). When true,
            # slot_mappings must use padded dimensions to match the key/value tensors.
            has_separate_kv_update = not all(
                all(
                    g.backend.forward_includes_kv_cache_update
                    for g in self.attn_groups[id]
                )
                for id, spec in enumerate(self.kv_cache_config.kv_cache_groups)
                if not isinstance(spec.kv_cache_spec, EncoderOnlyAttentionSpec)
            )
            pad_attn = cudagraph_mode == CUDAGraphMode.FULL

            if self.cache_config.mamba_cache_mode == "align":
                trace_mamba_t0 = time.perf_counter() if trace_log else 0.0
                # preprocess_mamba reads req_state.num_computed_tokens (CPU)
                # to decide copy operations, so we must apply deferred
                # corrections before it runs.
                if deferred_state_corrections_fn:
                    deferred_state_corrections_fn()
                    deferred_state_corrections_fn = None
                mamba_bufs = self._get_mamba_bufs()
                mamba_utils.preprocess_mamba(
                    scheduler_output,
                    self.kv_cache_config,
                    self.cache_config,
                    self.mamba_state_idx,
                    self.input_batch,
                    self.requests,
                    self.compilation_config.static_forward_context,
                    self.model.get_mamba_state_copy_func(),
                    mamba_bufs.preprocess,
                )
                # preprocess_mamba resets num_accepted_tokens_cpu to 1
                # for requests whose state was copied to a new block.
                # Re-sync to GPU so the mamba kernel reads from the
                # correct initial state slot (init_token_idx = 0).
                self.num_accepted_tokens.np[:num_reqs] = (
                    self.input_batch.num_accepted_tokens_cpu[:num_reqs]
                )
                self.spec_state_slot_selectors.np[:num_reqs] = (
                    self.input_batch.spec_num_accepted_tokens_cpu[:num_reqs]
                )
                self._copy_buffer_to_gpu(self.num_accepted_tokens, num_reqs)
                self._copy_buffer_to_gpu(self.spec_state_slot_selectors, num_reqs)
                if trace_log:
                    trace_mamba_preprocess_ms = (
                        time.perf_counter() - trace_mamba_t0
                    ) * 1000.0

            use_spec_decode = len(scheduler_output.scheduled_spec_decode_tokens) > 0
            ubatch_slices_attn = ubatch_slices_padded if pad_attn else ubatch_slices

            trace_slot_mapping_t0 = time.perf_counter() if trace_log else 0.0
            slot_mappings_by_group, slot_mappings = self._get_slot_mappings(
                num_tokens_padded=num_tokens_padded
                if pad_attn or has_separate_kv_update
                else num_tokens_unpadded,
                num_reqs_padded=(
                    num_reqs_padded if pad_attn or has_separate_kv_update else num_reqs
                ),
                num_tokens_unpadded=num_tokens_unpadded,
                ubatch_slices=ubatch_slices_padded,
            )
            if trace_log:
                trace_slot_mapping_ms = (
                    time.perf_counter() - trace_slot_mapping_t0
                ) * 1000.0

            trace_attn_metadata_t0 = time.perf_counter() if trace_log else 0.0
            attn_metadata, spec_decode_common_attn_metadata = (
                self._build_attention_metadata(
                    num_tokens=num_tokens_unpadded,
                    num_tokens_padded=num_tokens_padded if pad_attn else None,
                    num_reqs=num_reqs,
                    num_reqs_padded=num_reqs_padded if pad_attn else None,
                    max_query_len=max_num_scheduled_tokens,
                    ubatch_slices=ubatch_slices_attn,
                    logits_indices=logits_indices,
                    use_spec_decode=use_spec_decode,
                    num_scheduled_tokens=scheduler_output.num_scheduled_tokens,
                    cascade_attn_prefix_lens=cascade_attn_prefix_lens,
                    slot_mappings=slot_mappings_by_group,
                    ddtree_parent_metadata=self._ddtree_parent_metadata,
                )
            )
            if trace_log:
                trace_attn_metadata_ms = (
                    time.perf_counter() - trace_attn_metadata_t0
                ) * 1000.0

            trace_model_preprocess_t0 = time.perf_counter() if trace_log else 0.0
            (
                input_ids,
                inputs_embeds,
                positions,
                intermediate_tensors,
                model_kwargs,
                ec_connector_output,
            ) = self._preprocess(
                scheduler_output,
                num_tokens_padded,
                num_reqs,
                num_reqs_padded,
                intermediate_tensors,
            )
            if trace_log:
                trace_model_preprocess_ms = (
                    time.perf_counter() - trace_model_preprocess_t0
                ) * 1000.0
            _sm70_dump_compile_graph_inputs(
                input_ids=input_ids,
                positions=positions,
                logits_indices=logits_indices,
                attn_metadata=attn_metadata,
                cudagraph_mode=cudagraph_mode,
                batch_desc=batch_desc,
                num_reqs=num_reqs,
                num_reqs_padded=num_reqs_padded,
                num_tokens_unpadded=num_tokens_unpadded,
                num_tokens_padded=num_tokens_padded,
                num_scheduled_tokens_np=num_scheduled_tokens_np,
                req_ids=self.input_batch.req_ids,
                query_start_loc=self.query_start_loc,
                seq_lens=self.seq_lens,
                num_computed_tokens=self.num_computed_tokens,
                input_batch=self.input_batch,
                diagnostics=self._diagnostics,
            )

        if trace_log:
            trace_preprocess_ms = (time.perf_counter() - trace_preprocess_t0) * 1000.0

        # Set cudagraph mode to none if calc_kv_scales is true.
        # KV scales calculation involves dynamic operations that are incompatible
        # with CUDA graph capture.
        if self.calculate_kv_scales:
            cudagraph_mode = CUDAGraphMode.NONE
            # Mark KV scales as calculated after the first forward pass
            self.calculate_kv_scales = False

        # Encoder-decoder models can only compile the pure decode steps where no
        # encoder inputs are present. Use eager for the first pass.
        num_encoder_reqs = len(scheduler_output.scheduled_encoder_inputs)
        has_encoder_input = (
            self.model_config.is_encoder_decoder and num_encoder_reqs > 0
        )

        # Run the model.
        # Use persistent buffers for CUDA graphs.
        # When spec decode is enabled, defer connector finalization
        # (wait_for_save + clear metadata) until after draft model runs.
        defer_kv_connector_finalize = self.speculative_config is not None
        if cudagraph_mode != CUDAGraphMode.NONE:
            self.mixed_prefill_timer.mark_cuda_graph()
        _sync_sm70_before_compile_graph_forward(
            cudagraph_mode, diagnostics=self._diagnostics
        )
        mtp_profile_events: (
            list[tuple[str, torch.cuda.Event, torch.cuda.Event]] | None
        ) = (
            ([])
            if (
                self._step_profiler.enabled
                or (
                    self.speculative_config is not None
                    and self.speculative_config.use_dflash_ddtree()
                    and self.device.type == "cuda"
                    and _dflash_ddtree_profile_enabled()
                )
            )
            else None
        )
        mtp_forward_start = self._step_profiler.start(mtp_profile_events)
        trace_forward_t0 = time.perf_counter() if trace_log else 0.0
        if self._ple_offload_connector is not None:
            self._ple_offload_connector.prepare_forward(
                num_reqs,
                num_tokens_padded,
                dummy_run=False,
            )
        with (
            self._dflash_ddtree_target_forward_profile_scope(
                use_spec_decode=use_spec_decode,
                num_tokens=num_tokens_unpadded,
                num_reqs=num_reqs,
                cudagraph_mode=cudagraph_mode,
            ),
            set_forward_context(
                attn_metadata,
                self.vllm_config,
                num_tokens=num_tokens_padded,
                num_tokens_across_dp=num_tokens_across_dp,
                cudagraph_runtime_mode=cudagraph_mode,
                batch_descriptor=batch_desc,
                ubatch_slices=ubatch_slices_padded,
                slot_mapping=slot_mappings,
                skip_compiled=has_encoder_input,
            ),
            record_function_or_nullcontext("gpu_model_runner: forward"),
            self.maybe_get_kv_connector_output(
                scheduler_output,
                defer_finalize=defer_kv_connector_finalize,
            ) as kv_connector_output,
        ):
            model_output = self._model_forward(
                input_ids=input_ids,
                positions=positions,
                intermediate_tensors=intermediate_tensors,
                inputs_embeds=inputs_embeds,
                **model_kwargs,
            )
        if self._ple_offload_connector is not None:
            self._ple_offload_connector.release_outputs()
        if trace_log:
            trace_forward_submit_ms = (time.perf_counter() - trace_forward_t0) * 1000.0
        self._step_profiler.finish(
            mtp_profile_events, "target_forward", mtp_forward_start
        )

        trace_postprocess_t0 = time.perf_counter() if trace_log else 0.0
        with record_function_or_nullcontext("gpu_model_runner: postprocess"):
            if self.use_aux_hidden_state_outputs:
                # True when EAGLE 3 is used.
                hidden_states, aux_hidden_states = model_output
            else:
                # Common case.
                hidden_states = model_output
                aux_hidden_states = None

            if not get_pp_group().is_last_rank:
                self._pp_stage_after_forward()

            if not self.broadcast_pp_output:
                # Common case.
                if not get_pp_group().is_last_rank:
                    # Return the intermediate tensors.
                    assert isinstance(hidden_states, IntermediateTensors)
                    self.kv_connector_output = kv_connector_output
                    self._pp_nonlast_scheduler_output = scheduler_output
                    return hidden_states

                if self.is_pooling_model:
                    # Return the pooling output.
                    return self._pool(
                        hidden_states,
                        num_scheduled_tokens,
                        num_scheduled_tokens_np,
                        kv_connector_output,
                    )

                sample_hidden_states = hidden_states[logits_indices]
                mtp_logits_start = self._step_profiler.start(mtp_profile_events)
                if (
                    self._can_use_greedy_token_fastpath(
                        scheduler_output, spec_decode_metadata
                    )
                    or self._can_use_sm70_compact_topk20_tokens(
                        scheduler_output, spec_decode_metadata
                    )
                    or self._can_use_ddtree_greedy_top_tokens(
                        scheduler_output, spec_decode_metadata
                    )
                    or self._can_use_ddtree_stochastic_topk_tokens(
                        scheduler_output, spec_decode_metadata
                    )
                ):
                    logits = None
                else:
                    logits = self.model.compute_logits(sample_hidden_states)
                self._step_profiler.finish(
                    mtp_profile_events, "target_logits", mtp_logits_start
                )
            else:
                # Rare case.
                assert not self.is_pooling_model

                sample_hidden_states = hidden_states[logits_indices]
                mtp_logits_start = self._step_profiler.start(mtp_profile_events)
                if not get_pp_group().is_last_rank:
                    all_gather_tensors = {
                        "residual": not is_residual_scattered_for_sp(
                            self.vllm_config, num_tokens_padded
                        )
                    }
                    get_pp_group().send_tensor_dict(
                        hidden_states.tensors,
                        all_gather_group=get_tp_group(),
                        all_gather_tensors=all_gather_tensors,
                    )
                    logits = None
                else:
                    logits = self.model.compute_logits(sample_hidden_states)

                model_output_broadcast_data: dict[str, Any] = {}
                if logits is not None:
                    model_output_broadcast_data["logits"] = logits.contiguous()

                broadcasted = get_pp_group().broadcast_tensor_dict(
                    model_output_broadcast_data, src=len(get_pp_group().ranks) - 1
                )
                assert broadcasted is not None
                logits = broadcasted["logits"]
                self._step_profiler.finish(
                    mtp_profile_events, "target_logits", mtp_logits_start
                )

        if trace_log:
            trace_postprocess_ms = (time.perf_counter() - trace_postprocess_t0) * 1000.0

        sample_hidden_ready_event = _record_sm70_sample_hidden_ready_event(
            sample_hidden_states, cudagraph_mode
        )
        self._sm70_mtp_runner_profile_pending = (
            {
                "events": mtp_profile_events,
                "cpu_ms": {},
                "has_spec_decode_metadata": spec_decode_metadata is not None,
                "num_tokens": num_tokens_unpadded,
                "num_reqs": self.input_batch.num_reqs,
            }
            if mtp_profile_events is not None
            else None
        )

        self.execute_model_state = ExecuteModelState(
            scheduler_output,
            logits,
            spec_decode_metadata,
            spec_decode_common_attn_metadata,
            hidden_states,
            sample_hidden_states,
            logits_indices,
            cudagraph_mode,
            sample_hidden_ready_event,
            aux_hidden_states,
            ec_connector_output,
            cudagraph_stats,
            slot_mappings_by_group,
            slot_mappings,
        )
        self.kv_connector_output = kv_connector_output

        # Now the batch has been launched we can wait for corrections from the
        # previous model forward without breaking async scheduling.
        if deferred_state_corrections_fn:
            deferred_state_corrections_fn()

        if trace_log:
            logger.info(
                "SM70 async worker trace kind=execute step=%d mode=state_ready "
                "total_ms=%.3f preprocess_ms=%.3f forward_submit_ms=%.3f "
                "postprocess_ms=%.3f update_states_ms=%.3f "
                "prepare_inputs_ms=%.3f batch_desc_ms=%.3f "
                "mamba_preprocess_ms=%.3f slot_mapping_ms=%.3f "
                "attn_metadata_ms=%.3f model_preprocess_ms=%.3f "
                "scheduled_tokens=%d cudagraph_mode=%s",
                trace_step,
                (time.perf_counter() - trace_t0) * 1000.0,
                trace_preprocess_ms,
                trace_forward_submit_ms,
                trace_postprocess_ms,
                trace_update_states_ms,
                trace_prepare_inputs_ms,
                trace_batch_desc_ms,
                trace_mamba_preprocess_ms,
                trace_slot_mapping_ms,
                trace_attn_metadata_ms,
                trace_model_preprocess_ms,
                num_scheduled_tokens,
                cudagraph_mode,
            )

        return None

    @torch.inference_mode
    def sample_tokens(
        self, grammar_output: "GrammarOutput | None"
    ) -> ModelRunnerOutput | AsyncModelRunnerOutput | IntermediateTensors:
        trace_enabled = (
            bool(self._runtime_trace.async_cpu and self.use_async_scheduling)
            or _dflash_ddtree_worker_profile_enabled()
        )
        trace_step = getattr(self, "_sm70_async_worker_sample_trace_step", 0)
        trace_log = trace_enabled and (trace_step % self._async_trace_every == 0)
        if trace_enabled:
            self._sm70_async_worker_sample_trace_step = trace_step + 1
        trace_t0 = time.perf_counter() if trace_log else 0.0
        trace_wait_hidden_ms = 0.0
        trace_logits_ms = 0.0
        trace_sample_ms = 0.0
        trace_state_update_ms = 0.0
        trace_ddtree_validate_ms = 0.0
        trace_ddtree_attn_compact_ms = 0.0
        trace_ddtree_mamba_compact_ms = 0.0
        trace_update_states_inner_ms = 0.0
        trace_ddtree_drafter_context_ms = 0.0
        trace_draft_ms = 0.0
        trace_bookkeeping_ms = 0.0
        trace_finalize_ms = 0.0
        trace_output_ms = 0.0
        trace_async_output_ms = 0.0
        trace_set_async_ids_ms = 0.0

        if self.execute_model_state is None:
            kv_connector_output = self.kv_connector_output
            self.kv_connector_output = None
            # receive sampled token ids from the last PP rank.
            if self.use_async_scheduling and not get_pp_group().is_last_rank:
                self._pp_receive_prev_sampled_token_ids_to_input_batch()
            # In case of PP with kv transfer, we need to pass through the
            # kv_connector_output
            if trace_log:
                logger.info(
                    "SM70 async worker trace kind=sample step=%d mode=no_state "
                    "total_ms=%.3f",
                    trace_step,
                    (time.perf_counter() - trace_t0) * 1000.0,
                )
            return ModelRunnerOutput.with_kv_conn_output_only(kv_connector_output)

        # Unpack ephemeral state.
        (
            scheduler_output,
            logits,
            spec_decode_metadata,
            spec_decode_common_attn_metadata,
            hidden_states,
            sample_hidden_states,
            logits_indices,
            cudagraph_mode,
            sample_hidden_ready_event,
            aux_hidden_states,
            ec_connector_output,
            cudagraph_stats,
            slot_mappings_by_group,
            slot_mappings,
        ) = self.execute_model_state
        # Clear ephemeral state.
        self.execute_model_state = None
        mtp_profile_ctx = getattr(self, "_sm70_mtp_runner_profile_pending", None)
        self._sm70_mtp_runner_profile_pending = None

        trace_wait_hidden_t0 = time.perf_counter() if trace_log else 0.0
        _wait_sm70_sample_hidden_ready_event(
            sample_hidden_states, sample_hidden_ready_event
        )
        if trace_log:
            trace_wait_hidden_ms = (time.perf_counter() - trace_wait_hidden_t0) * 1000.0

        trace_logits_t0 = time.perf_counter() if trace_log else 0.0
        if grammar_output is not None and logits is None:
            logits = self.model.compute_logits(sample_hidden_states)

        # Apply structured output bitmasks if present.
        if grammar_output is not None:
            assert logits is not None
            apply_grammar_bitmask(
                scheduler_output, grammar_output, self.input_batch, logits
            )
        if trace_log:
            trace_logits_ms = (time.perf_counter() - trace_logits_t0) * 1000.0

        prefill_bootstrap = self._prepare_dynamic_draft_vocab_prefill_bootstrap(
            scheduler_output,
            logits,
            spec_decode_metadata,
        )
        with record_function_or_nullcontext("gpu_model_runner: sample"):
            trace_sample_t0 = time.perf_counter() if trace_log else 0.0
            mtp_sample_start = self._step_profiler.start(
                None if mtp_profile_ctx is None else mtp_profile_ctx["events"]
            )
            sampler_output = self._sample(
                scheduler_output,
                logits,
                spec_decode_metadata,
                sample_hidden_states,
                logits_indices,
            )
            sampler_output = self._clamp_ddtree_sampler_output_to_request_limits(
                sampler_output
            )
            self._commit_dynamic_draft_vocab_prefill_bootstrap(
                prefill_bootstrap,
                sampler_output.sampled_token_ids,
            )
            ddtree_copy_plan = self._ddtree_accepted_copy_plan(
                sampler_output, scheduler_output
            )
            self._step_profiler.finish(
                None if mtp_profile_ctx is None else mtp_profile_ctx["events"],
                "target_rejection_sample"
                if spec_decode_metadata is not None
                else "target_sample_no_spec",
                mtp_sample_start,
            )
            if trace_log:
                trace_sample_ms = (time.perf_counter() - trace_sample_t0) * 1000.0

        trace_state_update_t0 = time.perf_counter() if trace_log else 0.0
        mtp_state_update_wall_start = (
            time.perf_counter() if mtp_profile_ctx is not None else 0.0
        )
        trace_ddtree_validate_t0 = time.perf_counter() if trace_log else 0.0
        mtp_state_update_validate_start = (
            time.perf_counter() if mtp_profile_ctx is not None else 0.0
        )
        self._validate_ddtree_hybrid_state_path(
            sampler_output,
            scheduler_output,
            ddtree_copy_plan,
        )
        self._step_profiler.add_cpu_context(
            mtp_profile_ctx,
            "state_update_validate_cpu",
            mtp_state_update_validate_start,
        )
        if trace_log:
            trace_ddtree_validate_ms = (
                time.perf_counter() - trace_ddtree_validate_t0
            ) * 1000.0
        trace_ddtree_attn_compact_t0 = time.perf_counter() if trace_log else 0.0
        mtp_state_update_attn_compact_start = (
            time.perf_counter() if mtp_profile_ctx is not None else 0.0
        )
        self._compact_ddtree_accepted_attention_kv(
            sampler_output,
            scheduler_output,
            slot_mappings_by_group,
            ddtree_copy_plan,
        )
        self._step_profiler.add_cpu_context(
            mtp_profile_ctx,
            "state_update_attn_compact_cpu",
            mtp_state_update_attn_compact_start,
        )
        if trace_log:
            trace_ddtree_attn_compact_ms = (
                time.perf_counter() - trace_ddtree_attn_compact_t0
            ) * 1000.0
        trace_ddtree_mamba_compact_t0 = time.perf_counter() if trace_log else 0.0
        mtp_state_update_mamba_compact_start = (
            time.perf_counter() if mtp_profile_ctx is not None else 0.0
        )
        ddtree_mamba_state_compacted = self._compact_ddtree_accepted_mamba_state(
            sampler_output,
            scheduler_output,
            ddtree_copy_plan,
        )
        self._step_profiler.add_cpu_context(
            mtp_profile_ctx,
            "state_update_mamba_compact_cpu",
            mtp_state_update_mamba_compact_start,
        )
        if trace_log:
            trace_ddtree_mamba_compact_ms = (
                time.perf_counter() - trace_ddtree_mamba_compact_t0
            ) * 1000.0
        trace_update_states_inner_t0 = time.perf_counter() if trace_log else 0.0
        mtp_state_update_input_batch_start = (
            time.perf_counter() if mtp_profile_ctx is not None else 0.0
        )
        self._update_states_after_model_execute(
            sampler_output.sampled_token_ids,
            scheduler_output,
            sampler_output.ddtree_accepted_node_indices,
            ddtree_mamba_state_compacted,
        )
        self._step_profiler.add_cpu_context(
            mtp_profile_ctx,
            "state_update_input_batch_cpu",
            mtp_state_update_input_batch_start,
        )
        if trace_log:
            trace_update_states_inner_ms = (
                time.perf_counter() - trace_update_states_inner_t0
            ) * 1000.0
        trace_ddtree_drafter_context_t0 = time.perf_counter() if trace_log else 0.0
        mtp_state_update_drafter_context_start = (
            time.perf_counter() if mtp_profile_ctx is not None else 0.0
        )
        self._compact_ddtree_drafter_context(
            hidden_states,
            aux_hidden_states,
            sampler_output,
            scheduler_output,
            ddtree_copy_plan,
        )
        self._step_profiler.add_cpu_context(
            mtp_profile_ctx,
            "state_update_drafter_context_cpu",
            mtp_state_update_drafter_context_start,
        )
        if trace_log:
            trace_ddtree_drafter_context_ms = (
                time.perf_counter() - trace_ddtree_drafter_context_t0
            ) * 1000.0
        self._step_profiler.add_cpu_context(
            mtp_profile_ctx, "state_update_wall_cpu", mtp_state_update_wall_start
        )
        if self.use_async_scheduling:
            pp = get_pp_group()
            # For torchrun external_launcher PP mode with broadcast_pp_output=True,
            # PP outputs have been broadcasted to all ranks at logits computation.
            # Therefore, here is no need to send sampled token ids again in this case.
            if not self.broadcast_pp_output and pp.world_size > 1 and pp.is_last_rank:
                self._pp_broadcast_prev_sampled_token_ids(
                    sampler_output.sampled_token_ids,
                    sample_hidden_states if logits is None else logits,
                )

        self._draft_token_ids = None
        self._draft_probs = None
        self._draft_prob_req_ids = None
        self._draft_prob_token_ids = None
        self._draft_confidence_logits = None
        self._draft_confidence_req_ids = None
        self._draft_confidence_token_ids = None
        self._dspark_verification_lengths = None
        self._dflash_ddtree_payloads = None
        self._ddtree_parent_metadata = None
        self._ddtree_accepted_rows_cpu_sidecar = None
        self._ddtree_sampled_token_counts_cpu_sidecar = None
        self._draft_token_req_ids = None
        self.valid_sampled_token_count_gpu = None
        self.input_batch.prev_sampled_token_ids = None
        if trace_log:
            trace_state_update_ms = (
                time.perf_counter() - trace_state_update_t0
            ) * 1000.0
            if _dflash_ddtree_worker_profile_enabled():
                logger.info(
                    "DFLASH_DDTREE_WORKER_PROFILE state_update_split "
                    "total_ms=%.3f validate_ms=%.3f "
                    "attn_compact_ms=%.3f mamba_compact_ms=%.3f "
                    "update_states_ms=%.3f drafter_context_ms=%.3f",
                    trace_state_update_ms,
                    trace_ddtree_validate_ms,
                    trace_ddtree_attn_compact_ms,
                    trace_ddtree_mamba_compact_ms,
                    trace_update_states_inner_ms,
                    trace_ddtree_drafter_context_ms,
                )

        def propose_draft_token_ids(sampled_token_ids):
            nonlocal trace_draft_ms
            assert spec_decode_common_attn_metadata is not None
            with record_function_or_nullcontext("gpu_model_runner: draft"):
                trace_draft_t0 = time.perf_counter() if trace_log else 0.0
                mtp_draft_wall_start = (
                    time.perf_counter() if mtp_profile_ctx is not None else 0.0
                )
                mtp_draft_start = self._step_profiler.start(
                    None if mtp_profile_ctx is None else mtp_profile_ctx["events"]
                )
                self._draft_token_ids = self.propose_draft_token_ids(
                    scheduler_output,
                    sampled_token_ids,
                    self.input_batch.sampling_metadata,
                    hidden_states,
                    sample_hidden_states,
                    aux_hidden_states,
                    spec_decode_metadata,
                    spec_decode_common_attn_metadata,
                    slot_mappings,
                )
                self._step_profiler.finish(
                    None if mtp_profile_ctx is None else mtp_profile_ctx["events"],
                    "draft_total",
                    mtp_draft_start,
                )
                self._step_profiler.add_cpu_context(
                    mtp_profile_ctx, "draft_wall_cpu", mtp_draft_wall_start
                )
                self._copy_draft_token_ids_to_cpu(scheduler_output)
                if trace_log:
                    trace_draft_ms += (time.perf_counter() - trace_draft_t0) * 1000.0

        spec_config = self.speculative_config
        propose_drafts_after_bookkeeping = False
        if spec_config is not None:
            # Decide whether to run the drafter or zero out draft tokens.
            input_fits_in_drafter = spec_decode_common_attn_metadata is not None and (
                spec_decode_common_attn_metadata.max_seq_len + self.num_spec_tokens
                <= self.effective_drafter_max_model_len
            )
            use_gpu_toks = (
                spec_config.use_eagle()
                or spec_config.uses_draft_model()
                or spec_config.uses_extract_hidden_states()
            ) and not spec_config.disable_padded_drafter_batch
            if use_gpu_toks:
                # EAGLE/DraftModel speculative decoding can use the GPU sampled tokens
                # as inputs, and does not need to wait for bookkeeping to finish.
                assert isinstance(
                    self.drafter,
                    EagleProposer
                    | DFlashProposer
                    | DraftModelProposer
                    | ExtractHiddenStatesProposer
                    | Gemma4Proposer,
                )
                sampled_token_ids = sampler_output.sampled_token_ids
                if input_fits_in_drafter:
                    propose_draft_token_ids(sampled_token_ids)
                elif self.valid_sampled_token_count_event is not None:
                    assert spec_decode_common_attn_metadata is not None
                    next_token_ids, valid_sampled_tokens_count = (
                        self.drafter.prepare_next_token_ids_padded(
                            sampled_token_ids,
                            self.requests,
                            self.input_batch,
                            self.discard_request_mask.gpu,
                        )
                    )
                    self._copy_valid_sampled_token_count(
                        next_token_ids, valid_sampled_tokens_count
                    )
            elif (
                spec_config.use_ngram_gpu()
                and not spec_config.disable_padded_drafter_batch
            ):
                assert isinstance(self.drafter, NgramProposerGPU)
                sampled_token_ids = sampler_output.sampled_token_ids
                if input_fits_in_drafter:
                    propose_draft_token_ids(sampled_token_ids)
                elif self.valid_sampled_token_count_event is not None:
                    assert spec_decode_common_attn_metadata is not None
                    next_token_ids, valid_sampled_tokens_count, _ = (
                        self.drafter.update_token_ids_ngram(
                            sampled_token_ids,
                            self.input_batch,
                            self.token_ids_gpu_tensor,
                            self.num_tokens_no_spec_gpu,
                            self.discard_request_mask.gpu,
                        )
                    )
                    self._copy_valid_sampled_token_count(
                        next_token_ids, valid_sampled_tokens_count
                    )
            else:
                propose_drafts_after_bookkeeping = input_fits_in_drafter

            if not input_fits_in_drafter:
                # Do not schedule any new drafts once the drafter cannot cover
                # the current context. Returning zero-filled draft rows would
                # make token id 0 look like a real speculative token to the
                # scheduler and verifier.
                logger.warning_once(
                    "Skipping speculative drafts after reaching the drafter "
                    "context limit: num_spec_tokens=%s, "
                    "effective_drafter_max_model_len=%s. Future over-limit "
                    "batches are suppressed.",
                    self.num_spec_tokens,
                    self.effective_drafter_max_model_len,
                    scope="global",
                )
                self._draft_token_ids = [[] for _ in self.input_batch.req_ids]
                self._draft_probs = None
                self._draft_prob_req_ids = None
                self._draft_prob_token_ids = None
                self._draft_confidence_logits = None
                self._draft_confidence_req_ids = None
                self._draft_confidence_token_ids = None
                self._dspark_verification_lengths = None
                self._copy_draft_token_ids_to_cpu(scheduler_output)

        with record_function_or_nullcontext("gpu_model_runner: bookkeep"):
            trace_bookkeeping_t0 = time.perf_counter() if trace_log else 0.0
            mtp_bookkeeping_wall_start = (
                time.perf_counter() if mtp_profile_ctx is not None else 0.0
            )
            mtp_bookkeeping_start = self._step_profiler.start(
                None if mtp_profile_ctx is None else mtp_profile_ctx["events"]
            )
            (
                num_nans_in_logits,
                logprobs_lists,
                valid_sampled_token_ids,
                prompt_logprobs_dict,
                req_ids_output_copy,
                req_id_to_index_output_copy,
                invalid_req_indices,
            ) = self._bookkeeping_sync(
                scheduler_output,
                sampler_output,
                logits,
                hidden_states,
                scheduler_output.total_num_scheduled_tokens,
            )
            self._step_profiler.finish(
                None if mtp_profile_ctx is None else mtp_profile_ctx["events"],
                "bookkeeping",
                mtp_bookkeeping_start,
            )
            self._step_profiler.add_cpu_context(
                mtp_profile_ctx,
                "bookkeeping_wall_cpu",
                mtp_bookkeeping_wall_start,
            )
            if trace_log:
                trace_bookkeeping_ms = (
                    time.perf_counter() - trace_bookkeeping_t0
                ) * 1000.0

        if propose_drafts_after_bookkeeping:
            # ngram and other speculative decoding methods use the sampled
            # tokens on the CPU, so they are run after bookkeeping.
            propose_draft_token_ids(valid_sampled_token_ids)

        if (
            spec_config is not None
            and self.use_async_scheduling
            and not self.broadcast_pp_output
            and get_pp_group().world_size > 1
            and get_pp_group().is_last_rank
        ):
            self._pp_broadcast_draft_token_ids()

        # Finalize KV connector (wait_for_save + clear metadata) after
        # draft model runs. Deferred from target model forward to allow
        # draft model to also save its KV cache.
        if spec_config is not None:
            trace_finalize_t0 = time.perf_counter() if trace_log else 0.0
            self.finalize_kv_connector()
            if trace_log:
                trace_finalize_ms = (time.perf_counter() - trace_finalize_t0) * 1000.0

        with record_function_or_nullcontext("gpu_model_runner: eplb"):
            self.eplb_step()

        # self.kv_connector_output may be modified during drafting
        kv_connector_output = self.kv_connector_output
        self.kv_connector_output = None

        with record_function_or_nullcontext("gpu_model_runner: ModelRunnerOutput"):
            trace_output_t0 = time.perf_counter() if trace_log else 0.0
            output = ModelRunnerOutput(
                req_ids=req_ids_output_copy,
                mixed_prefill_timing=self.mixed_prefill_timer.finish(),
                req_id_to_index=req_id_to_index_output_copy,
                sampled_token_ids=valid_sampled_token_ids,
                logprobs=logprobs_lists,
                prompt_logprobs_dict=prompt_logprobs_dict,
                kv_connector_output=kv_connector_output,
                ec_connector_output=ec_connector_output
                if self.supports_mm_inputs
                else None,
                num_nans_in_logits=num_nans_in_logits,
                cudagraph_stats=cudagraph_stats,
                routed_experts=None,
            )
            if trace_log:
                trace_output_ms = (time.perf_counter() - trace_output_t0) * 1000.0

        if not self.use_async_scheduling:
            if self.routed_experts_initialized:
                # Sync path: D2H was issued in ``_bookkeeping_sync`` and
                # synchronized by ``_to_list``'s event.synchronize(), so
                # the pinned buffers are ready to be wrapped as numpy.
                total = scheduler_output.total_num_scheduled_tokens
                output.routed_experts = RoutedExpertsLists(
                    routing_data=self.routed_experts_cpu[:total].numpy(),
                    slot_mapping=self.routed_experts_slot_mapping_cpu[:total].numpy(),
                )
            self._step_profiler.report(mtp_profile_ctx)
            if trace_log:
                logger.info(
                    "SM70 async worker trace kind=sample step=%d mode=sync_output "
                    "total_ms=%.3f wait_hidden_ms=%.3f logits_ms=%.3f "
                    "sample_ms=%.3f state_update_ms=%.3f draft_ms=%.3f "
                    "bookkeeping_ms=%.3f finalize_ms=%.3f output_ms=%.3f "
                    "scheduled_tokens=%d",
                    trace_step,
                    (time.perf_counter() - trace_t0) * 1000.0,
                    trace_wait_hidden_ms,
                    trace_logits_ms,
                    trace_sample_ms,
                    trace_state_update_ms,
                    trace_draft_ms,
                    trace_bookkeeping_ms,
                    trace_finalize_ms,
                    trace_output_ms,
                    scheduler_output.total_num_scheduled_tokens,
                )
            return output

        with record_function_or_nullcontext(
            "gpu_model_runner: AsyncGPUModelRunnerOutput"
        ):
            trace_async_output_t0 = time.perf_counter() if trace_log else 0.0
            # Async path: produce a device-side snapshot that the async
            # copy stream can D2H later. Both tensors must be private
            # clones because:
            #   - ``routing_data`` source is the shared capturer buffer,
            #     which is ``clear_buffer()``-ed at the start of the
            #     next step on the default stream.
            #   - ``slot_mapping`` source is our own
            #     ``routed_experts_slot_mapping_device``, which the
            #     next ``_prepare_inputs`` overwrites on the default
            #     stream while the D2H is still pending on the copy
            #     stream.
            # Without clones, the copy stream would read torn data.
            routed_experts_snapshot = None
            if self.routed_experts_initialized:
                buf = self.routed_experts_capturer.get_device_buffer()
                total = scheduler_output.total_num_scheduled_tokens
                routed_experts_snapshot = RoutedExpertsTensors(
                    routing_data=buf[:total].clone(),
                    slot_mapping=self.routed_experts_slot_mapping_device[
                        :total
                    ].clone(),
                )

            async_output = AsyncGPUModelRunnerOutput(
                synchronize=self._event_tracer.synchronize,
                model_runner_output=output,
                sampled_token_ids=sampler_output.sampled_token_ids,
                logprobs_tensors=sampler_output.logprobs_tensors,
                invalid_req_indices=invalid_req_indices,
                async_output_copy_stream=self._get_or_create_async_output_copy_stream(),
                vocab_size=self.input_batch.vocab_size,
                routed_experts=routed_experts_snapshot,
            )
            if trace_log:
                trace_async_output_ms = (
                    time.perf_counter() - trace_async_output_t0
                ) * 1000.0
        with record_function_or_nullcontext(
            "gpu_model_runner: set_async_sampled_token_ids"
        ):
            trace_set_async_t0 = time.perf_counter() if trace_log else 0.0
            # Save ref of sampled_token_ids CPU tensor if the batch contains
            # any requests with sampling params that require output ids.
            self.input_batch.set_async_sampled_token_ids(
                async_output.sampled_token_ids_cpu,
                async_output.async_copy_ready_event,
            )
            if trace_log:
                trace_set_async_ids_ms = (
                    time.perf_counter() - trace_set_async_t0
                ) * 1000.0

        self._step_profiler.report(mtp_profile_ctx)
        if trace_log:
            logger.info(
                "SM70 async worker trace kind=sample step=%d mode=async_output "
                "total_ms=%.3f wait_hidden_ms=%.3f logits_ms=%.3f "
                "sample_ms=%.3f state_update_ms=%.3f draft_ms=%.3f "
                "bookkeeping_ms=%.3f finalize_ms=%.3f output_ms=%.3f "
                "async_output_ms=%.3f set_async_ids_ms=%.3f "
                "scheduled_tokens=%d",
                trace_step,
                (time.perf_counter() - trace_t0) * 1000.0,
                trace_wait_hidden_ms,
                trace_logits_ms,
                trace_sample_ms,
                trace_state_update_ms,
                trace_draft_ms,
                trace_bookkeeping_ms,
                trace_finalize_ms,
                trace_output_ms,
                trace_async_output_ms,
                trace_set_async_ids_ms,
                scheduler_output.total_num_scheduled_tokens,
            )
        return async_output

    def _pp_stage_before_forward(self) -> None:
        """Non-last PP stage, before its forward.

        A model whose per-step state lives on this stage commits the previous
        forward's deferred count here, since this stage never samples
        (DeepSeek-V4.1: models/deepseek_v41/pp_commit.py).
        """
        hook = getattr(self.get_model(), "pp_before_forward", None)
        if hook is not None:
            num_reqs = self.input_batch.num_reqs
            hook(
                self.input_batch.req_ids[:num_reqs],
                self.input_batch.num_computed_tokens_cpu[:num_reqs].tolist(),
            )

    def _pp_stage_after_forward(self) -> None:
        """Non-last PP stage, after its forward: commit it now or arm it."""
        hook = getattr(self.get_model(), "pp_after_forward", None)
        if hook is not None:
            num_reqs = self.input_batch.num_reqs
            hook(
                self.input_batch.req_ids[:num_reqs],
                self.input_batch.num_computed_tokens_cpu[:num_reqs].tolist(),
                self.input_batch.num_prompt_tokens[:num_reqs].tolist(),
            )

    def _pp_broadcast_prev_sampled_token_ids(
        self, sampled_token_ids: torch.Tensor, sampler_input: torch.Tensor
    ) -> None:
        """Broadcast sampled token ids (GPU) from last PP stage.

        `sampler_input` is what the sampler drew from (logits, or the hidden
        states when it computed the logits itself); only read to explain an
        invalid sample."""
        pp = get_pp_group()
        assert pp.is_last_rank
        # Skip for chunked prefill: sampled tokens are dummy
        # and will be discarded, no need to broadcast.
        if self._is_all_reqs_chunked_prefill():
            return
        # The receiver sizes its buffer from its own input_batch.num_reqs.
        # Both come from the same scheduler output; a divergence has to raise
        # here instead of hanging every rank in an unmatched collective.
        assert sampled_token_ids.shape[0] == self.input_batch.num_reqs
        if self.num_spec_tokens:
            # Speculative decoding: the non-last ranks derive the next token
            # ids, the accepted counts and the hybrid-state update from the
            # full sampled matrix. The sampler emits fewer columns in rounds
            # with fewer or no scheduled drafts, so pad to the static wire
            # shape [num_reqs, num_spec_tokens + 1] with the rejection
            # sampler's -1 placeholder.
            payload = torch.full(
                (sampled_token_ids.shape[0], self.num_spec_tokens + 1),
                -1,
                dtype=torch.int32,
                device=sampled_token_ids.device,
            )
            payload[:, : sampled_token_ids.shape[1]] = sampled_token_ids
            payload_cpu = payload.cpu()
            self._pp_check_token_ids(
                "sampled",
                payload_cpu,
                skip_discarded=True,
                sampler_input=sampler_input,
            )
            # The speculative round state goes over the gloo cpu_group. An
            # NCCL broadcast on the device_group shares the communicator with
            # the pipeline's send/recv; with five stages the two interleave
            # and the first request hangs (ranks 0-2 in the broadcast, ranks
            # 3-4 in irecv). A CPU rendezvous has no stream ordering to
            # violate, and the payload is [num_reqs, num_spec_tokens + 1]
            # int32.
            torch.distributed.broadcast(payload_cpu, src=pp.rank, group=pp.cpu_group)
            return
        # `prev_sampled_token_ids` is expected to have shape [num_reqs, 1].
        assert sampled_token_ids.dim() == 2 and sampled_token_ids.shape[-1] == 1, (
            "PP+async expects sampled_token_ids to have shape [num_reqs, 1]"
        )
        torch.distributed.broadcast(
            sampled_token_ids, src=pp.rank, group=pp.device_group
        )

    def _pp_broadcast_draft_token_ids(self) -> None:
        """Broadcast this step's draft token ids from the last PP stage.

        Under async scheduling the scheduler only carries placeholder draft
        slots; the non-last ranks need the real draft ids for their
        input_ids scatter in the next step.
        """
        pp = get_pp_group()
        assert pp.is_last_rank
        if self._is_all_reqs_chunked_prefill():
            return
        num_reqs = self.input_batch.num_reqs
        drafts = self._draft_token_ids
        if isinstance(drafts, torch.Tensor) and drafts.shape[0] >= num_reqs:
            payload = drafts[:num_reqs].to(dtype=torch.int32).contiguous()
        else:
            # Drafter skipped, or list-form drafts (ngram): the scheduler
            # schedules no GPU-resident spec slots from these, so the zeros
            # are never read on the receiving rank.
            payload = torch.zeros(
                (num_reqs, self.num_spec_tokens),
                dtype=torch.int32,
                device=self.device,
            )
        payload_cpu = payload.cpu()
        self._pp_check_token_ids("draft", payload_cpu, skip_discarded=False)
        torch.distributed.broadcast(payload_cpu, src=pp.rank, group=pp.cpu_group)

    def _pp_check_token_ids(
        self,
        kind: str,
        token_ids: torch.Tensor,
        skip_discarded: bool,
        sampler_input: torch.Tensor | None = None,
    ) -> None:
        """Token ids the last PP stage hands to the others feed their embedding
        lookup. An id outside the vocabulary would surface there as an
        anonymous device-side assert that takes the engine down, so check the
        payload while it is in host memory anyway: on the last stage before it
        is sent (where the cause can still be named), and on arrival. A
        discarded request's sampled token is never read."""
        invalid = (token_ids < 0) | (token_ids >= self.input_batch.vocab_size)
        if kind == "sampled":
            # Only the contiguous accepted prefix is consumed. Later -1
            # entries are padding; an active request still needs a first token.
            consumed = (token_ids != -1).to(torch.int32).cumprod(dim=1).bool()
            invalid &= consumed
            invalid[:, 0] |= token_ids[:, 0] < 0
        if skip_discarded:
            num_reqs = token_ids.shape[0]
            discarded = torch.from_numpy(self.discard_request_mask.np[:num_reqs])
            invalid &= ~discarded[:, None]
        if invalid.any():
            num_reqs = token_ids.shape[0]
            cause = ""
            if sampler_input is not None:
                metadata = self.input_batch.sampling_metadata
                temperature = metadata.temperature
                cause = (
                    f"; non-finite values per sampler input row "
                    f"{(~torch.isfinite(sampler_input)).sum(dim=-1).tolist()} of "
                    f"{tuple(sampler_input.shape)}, all_greedy={metadata.all_greedy}, "
                    f"all_random={metadata.all_random}, temperature="
                    f"{None if temperature is None else temperature.tolist()}, "
                    f"num_computed_tokens="
                    f"{self.input_batch.num_computed_tokens_cpu[:num_reqs].tolist()}, "
                    f"step input_ids="
                    f"{self.input_ids.gpu[: sampler_input.shape[0]].tolist()}, "
                    f"positions={self.positions[: sampler_input.shape[0]].tolist()}"
                )
            raise RuntimeError(
                f"PP spec decode: invalid {kind} token ids from the last stage: "
                f"{token_ids.tolist()} for requests "
                f"{self.input_batch.req_ids[:num_reqs]}, discarded="
                f"{self.discard_request_mask.np[:num_reqs].tolist()}{cause}"
            )

    def _pp_receive_spec_decode_state(self, num_reqs: int) -> None:
        """Receive the speculative round state from the last PP stage.

        Wire format, two broadcasts of statically known shape:
          1. the sampled token matrix [num_reqs, num_spec_tokens + 1], -1 padded
          2. the draft token ids [num_reqs, num_spec_tokens]
        The next token ids, the accepted counts and the hybrid (GDN/mamba)
        state update are derived locally from the matrix, as the last rank
        does in its full sample_tokens() path.
        """
        pp = get_pp_group()
        sampled_cpu = torch.empty(
            (num_reqs, self.num_spec_tokens + 1), dtype=torch.int32
        )
        torch.distributed.broadcast(sampled_cpu, src=pp.last_rank, group=pp.cpu_group)
        self._pp_check_token_ids("sampled", sampled_cpu, skip_discarded=True)
        sampled = sampled_cpu.to(self.device, non_blocking=True)
        valid_counts = _count_contiguous_spec_tokens(sampled)
        next_token_ids = sampled.gather(
            1, (valid_counts.to(torch.int64) - 1).clamp_(min=0).unsqueeze(1)
        ).squeeze(1)
        assert self.valid_sampled_token_count_event is not None
        self._copy_valid_sampled_token_count(next_token_ids, valid_counts)

        drafts_cpu = torch.empty((num_reqs, self.num_spec_tokens), dtype=torch.int32)
        torch.distributed.broadcast(drafts_cpu, src=pp.last_rank, group=pp.cpu_group)
        self._pp_check_token_ids("draft", drafts_cpu, skip_discarded=False)
        self._draft_token_ids = drafts_cpu.to(self.device, non_blocking=True)

        scheduler_output = self._pp_nonlast_scheduler_output
        self._pp_nonlast_scheduler_output = None
        if scheduler_output is None:
            raise RuntimeError(
                "PP speculative decoding: this non-last rank has no stashed "
                "scheduler_output for the hybrid-state update."
            )
        self._update_states_after_model_execute(sampled, scheduler_output)

    def _pp_receive_prev_sampled_token_ids_to_input_batch(self) -> None:
        """Receive sampled token ids broadcast from last PP stage"""
        pp = get_pp_group()
        assert not pp.is_last_rank
        num_reqs = self.input_batch.num_reqs
        if self.num_spec_tokens and not self._is_all_reqs_chunked_prefill():
            self._pp_receive_spec_decode_state(num_reqs)
        else:
            # `prev_sampled_token_ids` is expected to have shape [num_reqs, 1].
            recv = torch.empty((num_reqs, 1), dtype=torch.int32, device=self.device)
            # skip for chunked prefill.
            if not self._is_all_reqs_chunked_prefill():
                torch.distributed.broadcast(
                    recv, src=pp.last_rank, group=pp.device_group
                )
            self.input_batch.prev_sampled_token_ids = recv

        # construct `prev_req_id_to_index` here so `_prepare_input_ids`
        # can map req_id -> previous batch row
        discard_req_indices = np.nonzero(self.discard_request_mask.np[:num_reqs])[0]
        discard_req_indices_set = set(discard_req_indices)
        prev_req_id_to_index: dict[str, int] = {}
        for i, req_id in enumerate(self.input_batch.req_ids):
            if i in discard_req_indices_set:
                continue
            prev_req_id_to_index[req_id] = i
            # PP+async scheduling: advance per-request local cached output length by
            # appending a placeholder (-1) token id.
            if (req_state := self.requests.get(req_id)) is not None:
                req_state.output_token_ids.append(-1)
            pos = self.input_batch.num_tokens_no_spec[i]
            self.input_batch.is_token_ids[i, pos] = True
            self.input_batch.num_tokens_no_spec[i] = pos + 1
        self.input_batch.prev_req_id_to_index = prev_req_id_to_index

    def take_draft_token_ids(self) -> DraftTokenIds | None:
        if not self.num_spec_tokens or not self._draft_token_req_ids:
            _dflash_ddtree_debug_log(
                "take draft none num_spec=%s req_ids=%s payloads=%s",
                self.num_spec_tokens,
                len(self._draft_token_req_ids)
                if self._draft_token_req_ids is not None
                else None,
                self._dflash_ddtree_payloads is not None,
            )
            return None
        draft_token_ids, req_ids = self._get_draft_token_ids_cpu()
        ddtree_payloads = None
        if self._dflash_ddtree_payloads is not None:
            payloads = list(self._dflash_ddtree_payloads)
            ddtree_payloads = [
                payloads[idx] if idx < len(payloads) else None
                for idx in range(len(req_ids))
            ]
        _dflash_ddtree_debug_log(
            "take draft reqs=%d rows=%d payload_tuple=%s payload_rows=%s",
            len(req_ids),
            len(draft_token_ids),
            len(self._dflash_ddtree_payloads)
            if self._dflash_ddtree_payloads is not None
            else None,
            sum(payload is not None for payload in ddtree_payloads)
            if ddtree_payloads is not None
            else None,
        )
        return DraftTokenIds(req_ids, draft_token_ids, ddtree_payloads)

    def take_dflash_ddtree_payloads(
        self,
    ) -> tuple[DDTreeDraftPayload, ...] | None:
        return self._dflash_ddtree_payloads

    def _copy_draft_token_ids_to_cpu(
        self, scheduler_output: "SchedulerOutput", zeros_only: bool = False
    ) -> None:
        # Check if we need to copy draft tokens to CPU. In async scheduling,
        # we only copy when needed for structured output, penalties or bad_words.
        if self.use_async_scheduling and not (
            scheduler_output.has_structured_output_requests
            or self.input_batch.sampling_metadata.output_token_ids
        ):
            return
        # We must also set the corresponding request ids.
        self._draft_token_req_ids = self.input_batch.req_ids.copy()

        draft_token_ids: torch.Tensor = self._draft_token_ids
        if not torch.is_tensor(draft_token_ids):
            return
        assert self.draft_token_ids_event is not None
        assert self.draft_token_ids_copy_stream is not None
        assert self.draft_token_ids_cpu is not None
        default_stream = torch.cuda.current_stream()
        num_reqs = draft_token_ids.shape[0]
        with torch.cuda.stream(self.draft_token_ids_copy_stream):
            if not zeros_only:
                # Trigger async copy of draft token ids to cpu.
                self.draft_token_ids_copy_stream.wait_stream(default_stream)
                self.draft_token_ids_cpu[:num_reqs].copy_(
                    draft_token_ids, non_blocking=True
                )
                if self.dspark_confidence_scheduling:
                    lengths = self._dspark_verification_lengths
                    lengths_cpu = self._dspark_verification_lengths_cpu
                    if lengths is None or lengths_cpu is None:
                        raise RuntimeError(
                            "DSpark confidence scheduling is enabled but the "
                            "proposer did not return verification lengths."
                        )
                    lengths_cpu[:num_reqs].copy_(lengths[:num_reqs], non_blocking=True)
            else:
                # No copy needed, just zero-out cpu tensor.
                self.draft_token_ids_cpu[:num_reqs] = 0
            self.draft_token_ids_event.record()

    def _get_draft_token_ids_cpu(self) -> tuple[list[list[int]], list[str]]:
        if isinstance(self._draft_token_ids, list):
            req_ids = self._draft_token_req_ids
            if req_ids is None:
                req_ids = self.input_batch.req_ids.copy()
            return self._draft_token_ids, req_ids
        req_ids = self._draft_token_req_ids
        if req_ids is None:
            return [], []
        assert self.draft_token_ids_event is not None
        assert self.draft_token_ids_cpu is not None
        self._event_tracer.synchronize(
            self.draft_token_ids_event,
            "GPUModelRunner.draft_token_ids_event.synchronize",
        )
        draft_token_ids = self.draft_token_ids_cpu[: len(req_ids)].tolist()
        if self.dspark_confidence_scheduling:
            lengths_cpu = self._dspark_verification_lengths_cpu
            assert lengths_cpu is not None
            lengths = lengths_cpu[: len(req_ids)].tolist()
            draft_token_ids = [
                token_ids[: max(0, min(int(length), len(token_ids)))]
                for token_ids, length in zip(draft_token_ids, lengths, strict=True)
            ]
        return draft_token_ids, req_ids

    def _copy_valid_sampled_token_count(
        self, next_token_ids: torch.Tensor, valid_sampled_tokens_count: torch.Tensor
    ) -> None:
        if self.valid_sampled_token_count_event is None:
            return

        default_stream = torch.cuda.current_stream()
        # Initialize a new stream to overlap the copy operation with
        # prepare_input of draft model.
        with torch.cuda.stream(self.valid_sampled_token_count_copy_stream):
            self.valid_sampled_token_count_copy_stream.wait_stream(default_stream)  # type: ignore
            counts = valid_sampled_tokens_count
            counts_cpu = self.valid_sampled_token_count_cpu
            assert counts_cpu is not None
            counts_cpu[: counts.shape[0]].copy_(counts, non_blocking=True)
            self.valid_sampled_token_count_event.record()

        if self.use_async_spec_decode:
            # Stash for GPU-side correction in _prepare_inputs.
            self.valid_sampled_token_count_gpu = valid_sampled_tokens_count
        self.input_batch.prev_sampled_token_ids = next_token_ids.unsqueeze(1)

    def _get_valid_sampled_token_count(self) -> list[int]:
        # Wait until valid_sampled_tokens_count is copied to cpu,
        prev_sampled_token_ids = self.input_batch.prev_sampled_token_ids
        sampled_count_event = self.valid_sampled_token_count_event
        if sampled_count_event is None or prev_sampled_token_ids is None:
            return []

        counts_cpu = self.valid_sampled_token_count_cpu
        assert counts_cpu is not None
        self._event_tracer.synchronize(
            sampled_count_event,
            "GPUModelRunner.valid_sampled_token_count_event.synchronize",
        )
        return counts_cpu[: prev_sampled_token_ids.shape[0]].tolist()

    def _get_spec_decode_draft_probs(
        self, spec_decode_metadata: SpecDecodeMetadata
    ) -> torch.Tensor | None:
        return get_aligned_draft_probs(
            req_ids=self.input_batch.req_ids,
            draft_probs=self._draft_probs,
            draft_prob_req_ids=self._draft_prob_req_ids,
            draft_prob_token_ids=self._draft_prob_token_ids,
            spec_decode_metadata=spec_decode_metadata,
        )

    def _get_spec_decode_confidence_logits(
        self, spec_decode_metadata: SpecDecodeMetadata
    ) -> torch.Tensor | None:
        # Alignment has a small but non-zero launch/copy cost. Keep it out of
        # ordinary serving until confidence scheduling is explicitly enabled;
        # alignment dumps are the calibration path used before that gate.
        if not self._diagnostics.sampling.value("alignment"):
            return None
        return get_aligned_draft_scalar_values(
            req_ids=self.input_batch.req_ids,
            values=self._draft_confidence_logits,
            value_req_ids=self._draft_confidence_req_ids,
            value_token_ids=self._draft_confidence_token_ids,
            spec_decode_metadata=spec_decode_metadata,
        )

    def propose_draft_token_ids(
        self,
        scheduler_output: "SchedulerOutput",
        sampled_token_ids: torch.Tensor | list[list[int]],
        sampling_metadata: SamplingMetadata,
        hidden_states: torch.Tensor,
        sample_hidden_states: torch.Tensor,
        aux_hidden_states: list[torch.Tensor] | None,
        spec_decode_metadata: SpecDecodeMetadata | None,
        common_attn_metadata: CommonAttentionMetadata,
        slot_mappings: dict[str, torch.Tensor] | list[dict[str, torch.Tensor]] | None,
    ) -> list[list[int]] | torch.Tensor:
        num_scheduled_tokens = scheduler_output.total_num_scheduled_tokens
        spec_config = self.speculative_config
        assert spec_config is not None
        self._draft_probs = None
        self._draft_prob_req_ids = None
        self._draft_prob_token_ids = None
        self._draft_confidence_logits = None
        self._draft_confidence_req_ids = None
        self._draft_confidence_token_ids = None
        self._dspark_verification_lengths = None
        self._dflash_ddtree_payloads = None
        self._ddtree_parent_metadata = None
        self._ddtree_accepted_rows_cpu_sidecar = None
        self._ddtree_sampled_token_counts_cpu_sidecar = None
        if spec_config.method == "ngram":
            from vllm.v1.spec_decode.ngram_proposer import NgramProposer

            assert isinstance(sampled_token_ids, list)
            assert isinstance(self.drafter, NgramProposer)
            draft_token_ids = self.drafter.propose(
                sampled_token_ids,
                self.input_batch.num_tokens_no_spec,
                self.input_batch.token_ids_cpu,
                slot_mappings=slot_mappings,
            )
        elif spec_config.method == "custom_class":
            assert isinstance(sampled_token_ids, list)
            draft_token_ids = cast(Any, self.drafter).propose(
                sampled_token_ids,
                self.input_batch.num_tokens_no_spec,
                self.input_batch.token_ids_cpu,
                slot_mappings=slot_mappings,
            )
        elif spec_config.use_ngram_gpu():
            assert isinstance(self.drafter, NgramProposerGPU)
            (
                next_token_ids,
                valid_sampled_tokens_count,
                valid_sampled_token_ids_gpu,
            ) = self.drafter.update_token_ids_ngram(
                sampled_token_ids,
                self.input_batch,
                self.token_ids_gpu_tensor,
                self.num_tokens_no_spec_gpu,
                self.discard_request_mask.gpu,
            )
            self._copy_valid_sampled_token_count(
                next_token_ids, valid_sampled_tokens_count
            )

            batch_size = next_token_ids.shape[0]

            draft_token_ids, num_valid_draft_tokens = self.drafter.propose(
                self.num_tokens_no_spec_gpu[:batch_size],
                self.token_ids_gpu_tensor[:batch_size],
                valid_sampled_token_ids_gpu,
                valid_sampled_tokens_count,
            )

            # Cache valid draft counts for scheduler-side trimming.
            self._num_valid_draft_tokens = num_valid_draft_tokens

            # Async D2H copy on a dedicated stream.
            copy_num_valid_draft_tokens(
                self._num_valid_draft_tokens_cpu,
                self._num_valid_draft_tokens_copy_stream,
                self._num_valid_draft_tokens_event,
                self._num_valid_draft_tokens,
                self.input_batch.num_reqs,
            )
        elif spec_config.method == "suffix":
            assert isinstance(sampled_token_ids, list)
            assert isinstance(self.drafter, SuffixDecodingProposer)
            draft_token_ids = self.drafter.propose(
                self.input_batch, sampled_token_ids, slot_mappings=slot_mappings
            )
        elif spec_config.method == "medusa":
            assert isinstance(sampled_token_ids, list)
            assert isinstance(self.drafter, MedusaProposer)

            if sample_hidden_states.shape[0] == len(sampled_token_ids):
                # The input to the target model does not include draft tokens.
                hidden_states = sample_hidden_states
            else:
                indices = []
                offset = 0
                assert spec_decode_metadata is not None, (
                    "No spec decode metadata for medusa"
                )
                for num_draft, tokens in zip(
                    spec_decode_metadata.num_draft_tokens, sampled_token_ids
                ):
                    indices.append(offset + len(tokens) - 1)
                    offset += num_draft + 1
                indices = torch.tensor(indices, device=self.device)
                hidden_states = sample_hidden_states[indices]

            draft_token_ids = self.drafter.propose(
                target_hidden_states=hidden_states,
                sampling_metadata=sampling_metadata,
                slot_mappings=slot_mappings,
            )
        elif spec_config.uses_extract_hidden_states():
            assert isinstance(self.drafter, ExtractHiddenStatesProposer)
            assert isinstance(sampled_token_ids, torch.Tensor), (
                "sampled_token_ids should be a torch.Tensor for "
                "extract_hidden_states method."
            )
            if not self.use_aux_hidden_state_outputs or aux_hidden_states is None:
                raise ValueError(
                    "aux_hidden_states are required when using `extract_hidden_states`"
                )
            target_hidden_states = [h[:num_scheduled_tokens] for h in aux_hidden_states]

            draft_token_ids = self.drafter.propose(
                sampled_token_ids=sampled_token_ids,
                target_hidden_states=target_hidden_states,
                common_attn_metadata=common_attn_metadata,
                slot_mappings=slot_mappings,
            )
            next_token_ids, valid_sampled_tokens_count = (
                self.drafter.prepare_next_token_ids_padded(
                    sampled_token_ids,
                    self.requests,
                    self.input_batch,
                    self.discard_request_mask.gpu,
                )
            )
            self._copy_valid_sampled_token_count(
                next_token_ids, valid_sampled_tokens_count
            )

        elif (
            spec_config.use_eagle()
            or spec_config.use_dflash_ddtree()
            or spec_config.uses_draft_model()
        ):
            assert isinstance(
                self.drafter,
                EagleProposer | DFlashProposer | DraftModelProposer | Gemma4Proposer,
            )

            if spec_config.disable_padded_drafter_batch:
                # When padded-batch is disabled, the sampled_token_ids should be
                # the cpu-side list[list[int]] of valid sampled tokens for each
                # request, with invalid requests having empty lists.
                assert isinstance(sampled_token_ids, list), (
                    "sampled_token_ids should be a python list when"
                    "padded-batch is disabled."
                )
                next_token_ids = self.drafter.prepare_next_token_ids_cpu(
                    sampled_token_ids,
                    self.requests,
                    self.input_batch,
                    scheduler_output.num_scheduled_tokens,
                )
            else:
                # When using padded-batch, the sampled_token_ids should be
                # the gpu tensor of sampled tokens for each request, of shape
                # (num_reqs, num_spec_tokens + 1) with rejected tokens having
                # value -1.
                assert isinstance(sampled_token_ids, torch.Tensor), (
                    "sampled_token_ids should be a torch.Tensor when"
                    "padded-batch is enabled."
                )
                next_token_ids, valid_sampled_tokens_count = (
                    self.drafter.prepare_next_token_ids_padded(
                        sampled_token_ids,
                        self.requests,
                        self.input_batch,
                        self.discard_request_mask.gpu,
                    )
                )
                self._copy_valid_sampled_token_count(
                    next_token_ids, valid_sampled_tokens_count
                )

            # Let the target override the hidden state fed to the drafter
            # (e.g. DeepSeek V4 MTP needs the pre-hc_head residual). Safe to
            # rebind here: hidden_states was already consumed for sampling
            # above and is not used again in this branch.
            alt = getattr(
                self.get_model(), "get_mtp_target_hidden_states", lambda: None
            )()
            if alt is not None:
                hidden_states = alt

            num_rejected_tokens_gpu = None
            if spec_decode_metadata is None:
                token_indices_to_sample = None
                # input_ids can be None for multimodal models.
                target_token_ids = self.input_ids.gpu[:num_scheduled_tokens]
                target_positions = self._get_positions(num_scheduled_tokens)
                if self.use_aux_hidden_state_outputs:
                    assert aux_hidden_states is not None
                    target_hidden_states = torch.cat(
                        [h[:num_scheduled_tokens] for h in aux_hidden_states], dim=-1
                    )
                else:
                    target_hidden_states = hidden_states[:num_scheduled_tokens]
            else:
                if spec_config.disable_padded_drafter_batch:
                    token_indices_to_sample = None
                    common_attn_metadata, token_indices = self.drafter.prepare_inputs(
                        common_attn_metadata,
                        sampled_token_ids,
                        spec_decode_metadata.num_draft_tokens,
                    )
                    target_token_ids = self.input_ids.gpu[token_indices]
                    target_positions = self._get_positions(token_indices)
                    if self.use_aux_hidden_state_outputs:
                        assert aux_hidden_states is not None
                        target_hidden_states = torch.cat(
                            [h[token_indices] for h in aux_hidden_states], dim=-1
                        )
                    else:
                        target_hidden_states = hidden_states[token_indices]
                else:
                    (
                        common_attn_metadata,
                        token_indices_to_sample,
                        num_rejected_tokens_gpu,
                    ) = self.drafter.prepare_inputs_padded(
                        common_attn_metadata,
                        spec_decode_metadata,
                        valid_sampled_tokens_count,
                    )
                    total_num_tokens = common_attn_metadata.num_actual_tokens
                    # When padding the batch, token_indices is just a range
                    target_token_ids = self.input_ids.gpu[:total_num_tokens]
                    target_positions = self._get_positions(total_num_tokens)
                    if self.use_aux_hidden_state_outputs:
                        assert aux_hidden_states is not None
                        target_hidden_states = torch.cat(
                            [h[:total_num_tokens] for h in aux_hidden_states], dim=-1
                        )
                    else:
                        target_hidden_states = hidden_states[:total_num_tokens]

            if (
                self._diagnostics.channels["mtp_step"].policy.directory
                and spec_config.method == "mtp"
            ):
                payload = {
                    "req_ids": list(
                        self.input_batch.req_ids[: self.input_batch.num_reqs]
                    ),
                    "sampled_token_ids": sampled_token_ids,
                    "next_token_ids": next_token_ids,
                    "token_indices_to_sample": token_indices_to_sample,
                    "num_rejected_tokens_gpu": num_rejected_tokens_gpu,
                    "target_token_ids": target_token_ids,
                    "target_positions": target_positions,
                    "target_hidden_shape": tuple(target_hidden_states.shape),
                    "common_query_start_loc": common_attn_metadata.query_start_loc,
                    "common_query_start_loc_cpu": (
                        common_attn_metadata.query_start_loc_cpu
                    ),
                    "common_seq_lens": common_attn_metadata.seq_lens,
                    "common_seq_lens_cpu": common_attn_metadata._seq_lens_cpu,
                    "common_seq_lens_cpu_upper_bound": (
                        common_attn_metadata.seq_lens_cpu_upper_bound
                    ),
                    "common_num_computed_tokens_cpu": (
                        common_attn_metadata._num_computed_tokens_cpu
                    ),
                    "common_max_query_len": common_attn_metadata.max_query_len,
                    "common_max_seq_len": common_attn_metadata.max_seq_len,
                    "common_slot_mapping": common_attn_metadata.slot_mapping,
                }
                if spec_decode_metadata is not None:
                    payload.update(
                        {
                            "spec_num_draft_tokens": (
                                spec_decode_metadata.num_draft_tokens
                            ),
                            "spec_cu_num_draft_tokens": (
                                spec_decode_metadata.cu_num_draft_tokens
                            ),
                            "spec_draft_token_ids": (
                                spec_decode_metadata.draft_token_ids
                            ),
                        }
                    )
                if "valid_sampled_tokens_count" in locals():
                    payload["valid_sampled_tokens_count"] = valid_sampled_tokens_count
                _maybe_dump_sm70_mtp_step(
                    "draft_input", payload, diagnostics=self._diagnostics
                )

            if self.supports_mm_inputs and self.drafter.supports_mm_inputs:
                mm_embed_inputs = self._gather_mm_embeddings(
                    scheduler_output,
                    shift_computed_tokens=1,
                )
            else:
                mm_embed_inputs = None

            draft_token_ids = self.drafter.propose(
                target_token_ids=target_token_ids,
                target_positions=target_positions,
                target_hidden_states=target_hidden_states,
                next_token_ids=next_token_ids,
                token_indices_to_sample=token_indices_to_sample,
                sampling_metadata=sampling_metadata,
                common_attn_metadata=common_attn_metadata,
                mm_embed_inputs=mm_embed_inputs,
                num_rejected_tokens_gpu=num_rejected_tokens_gpu,
                slot_mappings=slot_mappings,
            )
            if (
                self._diagnostics.channels["mtp_step"].policy.directory
                and spec_config.method == "mtp"
            ):
                _maybe_dump_sm70_mtp_step(
                    "draft_output",
                    {
                        "req_ids": list(
                            self.input_batch.req_ids[: self.input_batch.num_reqs]
                        ),
                        "draft_token_ids": draft_token_ids,
                        "num_rejected_tokens_gpu": num_rejected_tokens_gpu,
                        "token_indices_to_sample": token_indices_to_sample,
                        "next_token_ids": next_token_ids,
                    },
                    diagnostics=self._diagnostics,
                )
            if hasattr(self.drafter, "take_last_draft_probs"):
                draft_probs = self.drafter.take_last_draft_probs()
                if draft_probs is not None:
                    self._draft_probs = draft_probs
                    self._draft_prob_req_ids = self.input_batch.req_ids.copy()
                    self._draft_prob_token_ids = clone_draft_prob_token_ids(
                        draft_token_ids
                    )
            if hasattr(self.drafter, "take_last_confidence_logits"):
                confidence_logits = self.drafter.take_last_confidence_logits()
                if confidence_logits is not None:
                    self._draft_confidence_logits = confidence_logits
                    self._draft_confidence_req_ids = self.input_batch.req_ids.copy()
                    self._draft_confidence_token_ids = clone_draft_prob_token_ids(
                        draft_token_ids
                    )
            if hasattr(self.drafter, "take_last_verification_lengths"):
                verification_lengths = self.drafter.take_last_verification_lengths()
                if verification_lengths is not None:
                    self._dspark_verification_lengths = verification_lengths
            if hasattr(self.drafter, "take_last_ddtree_payloads"):
                self._dflash_ddtree_payloads = self.drafter.take_last_ddtree_payloads()
                first_payload = (
                    self._dflash_ddtree_payloads[0]
                    if self._dflash_ddtree_payloads
                    else None
                )
                _dflash_ddtree_debug_log(
                    "proposal payloads=%s first_flat=%s first_tree=%s",
                    len(self._dflash_ddtree_payloads)
                    if self._dflash_ddtree_payloads is not None
                    else None,
                    len(first_payload.flat_draft_token_ids)
                    if first_payload is not None
                    else None,
                    len(first_payload.tree_token_ids)
                    if first_payload is not None
                    else None,
                )

        return draft_token_ids

    def update_config(self, overrides: dict[str, Any]) -> None:
        allowed_config_names = {"load_config", "model_config"}
        for config_name, config_overrides in overrides.items():
            assert config_name in allowed_config_names, (
                f"Config `{config_name}` not supported. "
                f"Allowed configs: {allowed_config_names}"
            )
            config = getattr(self, config_name)
            new_config = update_config(config, config_overrides)
            setattr(self, config_name, new_config)

    @instrument(span_name="Loading (GPU)")
    def load_model(self, load_dummy_weights: bool = False) -> None:
        """
        Args:
            load_dummy_weights: load dummy weights instead of real weights.
        """
        logger.info_once(
            "Starting to load model %s...",
            self.model_config.model,
            scope="global",
        )

        if self.parallel_config.enable_eplb:
            self.eplb_state = EplbState(self.parallel_config, self.device)
            eplb_models = 0

        try:
            with DeviceMemoryProfiler() as m:
                time_before_load = time.perf_counter()
                if load_dummy_weights:
                    self.load_config.load_format = "dummy"
                model_loader = get_model_loader(self.load_config)
                self.model = model_loader.load_model(
                    vllm_config=self.vllm_config, model_config=self.model_config
                )
                if self.lora_config:
                    self.model = self.load_lora_model(
                        self.model, self.vllm_config, self.device
                    )
                if (drafter := getattr(self, "drafter", None)) is not None:
                    logger.info_once("Loading drafter model...")
                    if hasattr(drafter, "load_model"):
                        drafter.load_model(self.model)
                    if (
                        hasattr(drafter, "model")
                        and is_mixture_of_experts(drafter.model)
                        and self.parallel_config.enable_eplb
                    ):
                        assert not self.parallel_config.enable_elastic_ep, (
                            "Elastic EP is not supported with drafter model."
                        )
                        spec_config = self.vllm_config.speculative_config
                        assert spec_config is not None
                        assert spec_config.draft_model_config is not None
                        logger.info_once(
                            "EPLB is enabled for drafter model %s.",
                            spec_config.draft_model_config.model,
                        )
                        if self.eplb_state is None:
                            self.eplb_state = EplbState(
                                self.parallel_config, self.device
                            )
                        self.eplb_state.add_model(
                            drafter.model,
                            spec_config.draft_model_config,
                        )
                        eplb_models += 1

                self._setup_eagle3_aux_hidden_state_outputs()

                # Resolve the MoE model, unwrapping VLM wrappers if needed.
                # VLM models (e.g. KimiK25ForConditionalGeneration) wrap the
                # actual MoE language model but don't implement
                # MixtureOfExperts themselves.
                moe_candidate = self.model
                if not is_mixture_of_experts(moe_candidate) and isinstance(
                    moe_candidate, SupportsMultiModal
                ):
                    moe_candidate = moe_candidate.get_language_model()
                if is_mixture_of_experts(moe_candidate):
                    self._moe_model = moe_candidate

                if (
                    self._moe_model is not None
                    and self.parallel_config.enable_eplb
                    and not load_dummy_weights
                ):
                    logger.info_once(
                        "EPLB is enabled for model %s.",
                        self.model_config.model,
                    )
                    assert self.eplb_state is not None
                    self.eplb_state.add_model(
                        self._moe_model,
                        self.model_config,
                    )
                    eplb_models += 1

                time_after_load = time.perf_counter()
            self.model_memory_usage = m.consumed_memory
        except torch.cuda.OutOfMemoryError as e:
            msg = (
                "Failed to load model - not enough GPU memory. "
                "Try lowering --gpu-memory-utilization to free memory for weights, "
                "increasing --tensor-parallel-size, or using --quantization. "
                "See https://docs.vllm.ai/en/latest/configuration/conserving_memory/ "
                "for more tips."
            )
            combined_msg = f"{msg} (original error: {e})"
            logger.error(combined_msg)
            raise e
        logger.info_once(
            "Model loading took %s GiB memory and %.6f seconds",
            format_gib(self.model_memory_usage),
            time_after_load - time_before_load,
        )
        if not load_dummy_weights:
            prepare_communication_buffer_for_model(self.model)
            if (drafter := getattr(self, "drafter", None)) and (
                drafter_model := getattr(drafter, "model", None)
            ):
                prepare_communication_buffer_for_model(drafter_model)
        mm_config = self.model_config.multimodal_config
        self.is_multimodal_pruning_enabled = (
            supports_multimodal_pruning(self.get_model())
            and mm_config is not None
            and mm_config.is_multimodal_pruning_enabled()
        )
        self.requires_sequential_video_encoding = hasattr(
            self.get_model(), "requires_sequential_video_encoding"
        )  # Temporary hack for dynamic res video w/o support for bs>1 yet

        if (
            self._moe_model is not None
            and self.parallel_config.enable_eplb
            and not load_dummy_weights
            and self.eplb_state is not None
            and self.eplb_state.is_async
        ):
            self.eplb_state.start_async_loop()

        if (
            self.vllm_config.compilation_config.mode
            == CompilationMode.STOCK_TORCH_COMPILE
        ):
            from vllm.env_override import _apply_constrain_to_fx_strides_patch

            _apply_constrain_to_fx_strides_patch()
            backend = self.vllm_config.compilation_config.init_backend(self.vllm_config)
            compilation_counter.stock_torch_compile_count += 1
            self.model.compile(fullgraph=True, backend=backend)
            return
        # for other compilation modes, cudagraph behavior is controlled by
        # CudagraphWrapper and CudagraphDispatcher of vllm.

        # wrap the model with full cudagraph wrapper if needed.
        cudagraph_mode = self.compilation_config.cudagraph_mode
        assert cudagraph_mode is not None
        if (
            is_breakable_cudagraph_enabled()
            and cudagraph_mode != CUDAGraphMode.NONE
            and not self.parallel_config.use_ubatching
        ):
            self.model = BreakableCUDAGraphWrapper(self.model, self.vllm_config)
            drafter = getattr(self, "drafter", None)
            if drafter is not None and hasattr(drafter, "model"):
                drafter.model = BreakableCUDAGraphWrapper(
                    drafter.model, self.vllm_config
                )
        elif (
            cudagraph_mode.has_full_cudagraphs()
            and not self.parallel_config.use_ubatching
        ):
            self.model = CUDAGraphWrapper(
                self.model, self.vllm_config, runtime_mode=CUDAGraphMode.FULL
            )
        elif self.parallel_config.use_ubatching:
            if cudagraph_mode.has_full_cudagraphs():
                self.model = UBatchWrapper(
                    self.model, self.vllm_config, CUDAGraphMode.FULL, self.device
                )
            else:
                self.model = UBatchWrapper(
                    self.model, self.vllm_config, CUDAGraphMode.NONE, self.device
                )

        get_offloader().post_init()

    def _setup_eagle3_aux_hidden_state_outputs(self) -> None:
        if not self.use_aux_hidden_state_outputs:
            return

        if not supports_eagle3(self.get_model()):
            raise RuntimeError(
                "Model does not support EAGLE3 interface but "
                "aux_hidden_state_outputs was requested"
            )
        # Try to get auxiliary layers from speculative config,
        # otherwise use model's default layers
        aux_layers = self._get_eagle3_aux_layers_from_config()
        if aux_layers:
            logger.info(
                "Using auxiliary layers from speculative config: %s", aux_layers
            )
        else:
            aux_layers = self.model.get_eagle3_default_aux_hidden_state_layers()

        self.model.set_aux_hidden_state_layers(aux_layers)

    def _get_eagle3_aux_layers_from_config(self) -> tuple[int, ...] | None:
        """Extract Eagle3 auxiliary layer indices from speculative config.

        These indices specify which hidden states from the base model should
        be used as auxiliary inputs for the Eagle3 drafter model during
        speculative decoding.

        Returns:
            Tuple of layer indices if found in draft model config,
            None otherwise.
        """
        if not (self.speculative_config and self.speculative_config.draft_model_config):
            return None

        hf_config = self.speculative_config.draft_model_config.hf_config

        layer_ids = getattr(hf_config, "eagle_aux_hidden_state_layer_ids", None)
        if not layer_ids:
            dflash_config = getattr(hf_config, "dflash_config", None)
            eagle_config = getattr(hf_config, "eagle_config", None)

            if dflash_config and isinstance(dflash_config, dict):
                # DFlash target_layer_ids are already in the aux hidden
                # state layer numbering used by the target model.
                layer_ids = dflash_config.get("target_layer_ids")

            if eagle_config and isinstance(eagle_config, dict):
                layer_ids = eagle_config.get("eagle_aux_hidden_state_layer_ids")

        if not layer_ids:
            dspark_layer_ids = getattr(hf_config, "dspark_target_layer_ids", None)
            if dspark_layer_ids:
                # DSpark config uses zero-based decoder-layer IDs; the target
                # model's capture interface numbers outputs after each layer.
                layer_ids = [layer_id + 1 for layer_id in dspark_layer_ids]

        if layer_ids and isinstance(layer_ids, (list, tuple)):
            return tuple(layer_ids)

        return None

    def reload_weights(
        self,
        weights_iterator: Iterable[tuple[str, torch.Tensor]] | None = None,
        weights_path: str | None = None,
        is_checkpoint_format: bool = True,
    ) -> None:
        """
        Reload weights from a weights iterator or from disk

        :param weights_iterator: weights to load into model
        :param weights_path: path to load weights from if weights_iterator is not
            provided. Use path of original model if neither is provided.
        :param is_checkpoint_format: set to False if weights have already been processed
            into kernel format (repacking, renaming, etc.)
        """
        # TODO(@kylesayrs): generalize to all runners and loaders
        # argument validation
        if weights_iterator is None and not is_checkpoint_format:
            logger.warning(
                "Reloading from disk means that weights will be in checkpoint format. "
                "Please use `is_checkpoint_format=True` "
                "to avoid weight reloading errors"
            )

        model = self.get_model()
        weights_to_load = {name for name, _ in model.named_parameters()}
        counter_before_reloading = time.perf_counter()

        # load weights from disk if none are provided
        if weights_iterator is None:
            model_loader = get_model_loader(self.load_config)
            if not hasattr(model_loader, "get_all_weights"):
                raise NotImplementedError(
                    f"Model reloading with `{self.load_config.load_format}` format"
                )

            if weights_path is not None:
                self.model_config.model = weights_path
            weights_iterator = model_loader.get_all_weights(self.model_config, model)
            weights_iterator = cast(
                Iterable[tuple[str, torch.Tensor]], weights_iterator
            )

        # begin loading weights
        logger.info_once("Reloading weights inplace...")
        if is_checkpoint_format:
            # load weights from checkpoint/ original model format
            initialize_layerwise_reload(model)
            loaded_weights = model.load_weights(weights_iterator)
            finalize_layerwise_reload(model, self.model_config)

        else:
            # load weights from kernel format
            logger.warning_once(
                "Reloading with `is_checkpoint_format=True` requires that "
                "weights be in kernel format and already sharded",
            )
            loaded_weights = set()
            for name, loaded_weight in weights_iterator:
                param = model.get_parameter(name)  # TODO: buffers?
                param.copy_(loaded_weight)
                loaded_weights.add(name)

        # logging and validation
        counter_after_reloading = time.perf_counter()
        diff_seconds = counter_after_reloading - counter_before_reloading
        logger.info_once(
            "Reloading and processing weights took %.2f seconds",
            diff_seconds,
        )
        if self.model_config.quantization is None and loaded_weights is not None:
            weights_not_loaded = weights_to_load - loaded_weights
            if weights_not_loaded:
                logger.warning(
                    "Following weights were not loaded from checkpoint: %s",
                    weights_not_loaded,
                )

    def _get_prompt_logprobs_dict(
        self,
        hidden_states: torch.Tensor,
        num_scheduled_tokens: dict[str, int],
    ) -> dict[str, LogprobsTensors | None]:
        num_prompt_logprobs_dict = self.num_prompt_logprobs
        if not num_prompt_logprobs_dict:
            return {}

        prompt_logprobs_dict: dict[str, LogprobsTensors | None] = {}

        # Since prompt logprobs are a rare feature, prioritize simple,
        # maintainable loop over optimal performance.
        completed_prefill_reqs = []
        for req_id, num_prompt_logprobs in num_prompt_logprobs_dict.items():
            num_tokens = num_scheduled_tokens.get(req_id)
            if num_tokens is None:
                # This can happen if the request was preempted in prefill stage.
                continue

            # Get metadata for this request.
            request = self.requests[req_id]
            if request.prompt_token_ids is None:
                # Prompt logprobs is incompatible with prompt embeddings
                continue

            num_prompt_tokens = len(request.prompt_token_ids)
            prompt_token_ids = torch.tensor(request.prompt_token_ids).to(
                self.device, non_blocking=True
            )

            # Set up target LogprobsTensors object.
            logprobs_tensors = request.in_progress_prompt_logprobs_cpu
            if logprobs_tensors is None:
                # Create empty logprobs CPU tensors for the entire prompt.
                # If chunked, we'll copy in slice by slice.
                logprobs_tensors = LogprobsTensors.empty_cpu(
                    num_prompt_tokens - 1, num_prompt_logprobs + 1
                )
                request.in_progress_prompt_logprobs_cpu = logprobs_tensors

            # Determine number of logits to retrieve.
            start_idx = request.num_computed_tokens
            start_tok = start_idx + 1
            num_remaining_tokens = num_prompt_tokens - start_tok
            if num_tokens <= num_remaining_tokens:
                # This is a chunk, more tokens remain.
                # In the == case, there are no more prompt logprobs to produce
                # but we want to defer returning them to the next step where we
                # have new generated tokens to return.
                num_logits = num_tokens
            else:
                # This is the last chunk of prompt tokens to return.
                num_logits = num_remaining_tokens
                completed_prefill_reqs.append(req_id)
                prompt_logprobs_dict[req_id] = logprobs_tensors

            if num_logits <= 0:
                # This can happen for the final chunk if we prefilled exactly
                # (num_prompt_tokens - 1) tokens for this request in the prior
                # step. There are no more prompt logprobs to produce.
                continue

            # Get the logits corresponding to this req's prompt tokens.
            # If this is a partial request (i.e. chunked prefill),
            # then there is prompt logprob generated for each index.
            req_idx = self.input_batch.req_id_to_index[req_id]
            offset = self.query_start_loc.np[req_idx].item()
            prompt_hidden_states = hidden_states[offset : offset + num_logits]
            logits = self.model.compute_logits(prompt_hidden_states)

            # Get the "target" tokens for each index. For prompt at index i,
            # the token at prompt index i+1 is the "sampled" token we want
            # to gather the logprob for.
            tgt_token_ids = prompt_token_ids[start_tok : start_tok + num_logits]

            # Compute prompt logprobs.
            logprobs = self.sampler.compute_logprobs(logits)
            token_ids, logprobs, ranks, _ = self.sampler.gather_logprobs(
                logprobs, num_prompt_logprobs, tgt_token_ids
            )

            # Transfer GPU->CPU async.
            chunk_slice = slice(start_idx, start_idx + num_logits)
            logprobs_tensors.logprob_token_ids[chunk_slice].copy_(
                token_ids, non_blocking=True
            )
            logprobs_tensors.logprobs[chunk_slice].copy_(logprobs, non_blocking=True)
            logprobs_tensors.selected_token_ranks[chunk_slice].copy_(
                ranks, non_blocking=True
            )

        # Remove requests that have completed prefill from the batch
        # num_prompt_logprobs_dict.
        for req_id in completed_prefill_reqs:
            del num_prompt_logprobs_dict[req_id]
            self.requests[req_id].in_progress_prompt_logprobs_cpu = None

        # Must synchronize the non-blocking GPU->CPU transfers.
        if prompt_logprobs_dict:
            self._sync_device()

        return prompt_logprobs_dict

    def _get_nans_in_logits(
        self,
        logits: torch.Tensor | None,
    ) -> dict[str, int]:
        try:
            if logits is None:
                return {req_id: 0 for req_id in self.input_batch.req_ids}

            num_nans_in_logits = {}
            num_nans_for_index = logits.isnan().sum(dim=-1).cpu().numpy()
            for req_id in self.input_batch.req_ids:
                req_index = self.input_batch.req_id_to_index[req_id]
                num_nans_in_logits[req_id] = (
                    int(num_nans_for_index[req_index])
                    if num_nans_for_index is not None and req_index < logits.shape[0]
                    else 0
                )
            return num_nans_in_logits
        except IndexError:
            return {}

    @contextmanager
    def maybe_randomize_inputs(
        self, input_ids: torch.Tensor | None, inputs_embeds: torch.Tensor | None
    ):
        """
        Randomize input_ids if VLLM_RANDOMIZE_DP_DUMMY_INPUTS is set.
        This is to help balance expert-selection
         - during profile_run
         - during DP rank dummy run
        """

        dp_size = self.vllm_config.parallel_config.data_parallel_size
        randomize_inputs = envs.VLLM_RANDOMIZE_DP_DUMMY_INPUTS and dp_size > 1
        if not randomize_inputs:
            yield
        elif input_ids is not None:

            @functools.cache
            def rand_input_ids() -> torch.Tensor:
                return torch.randint_like(
                    self.input_ids.gpu,
                    low=0,
                    high=self.model_config.get_vocab_size(),
                )

            logger.debug_once("Randomizing dummy input_ids for DP Rank")
            input_ids.copy_(rand_input_ids()[: input_ids.size(0)], non_blocking=True)
            yield
            input_ids.fill_(0)
        else:

            @functools.cache
            def rand_inputs_embeds() -> torch.Tensor:
                return torch.randn_like(
                    self.inputs_embeds.gpu,
                )

            assert inputs_embeds is not None
            logger.debug_once("Randomizing dummy inputs_embeds for DP Rank")
            inputs_embeds.copy_(
                rand_inputs_embeds()[: inputs_embeds.size(0)], non_blocking=True
            )
            yield
            inputs_embeds.fill_(0)

    def _get_mm_dummy_batch(
        self,
        modality: str,
        max_items_per_batch: int,
    ) -> BatchedTensorInputs:
        """Dummy data for profiling and precompiling multimodal models."""
        assert self.mm_budget is not None

        # Don't use `max_items_per_batch` here to avoid redundant computation
        dummy_mm_inputs = self.mm_registry.get_dummy_mm_inputs(
            self.model_config,
            mm_counts={modality: 1},
            cache=self.mm_budget.cache,
        )
        dummy_mm_item = dummy_mm_inputs["mm_kwargs"][modality][0]

        # We use the cache so that the item is saved to the cache,
        # but not read from the cache
        assert dummy_mm_item is not None, "Item should not already be cached"

        return next(
            mm_kwargs_batch
            for _, _, mm_kwargs_batch in group_and_batch_mm_kwargs(
                [(modality, dummy_mm_item)] * max_items_per_batch,
                device=self.device,
                pin_memory=self.pin_memory,
            )
        )

    @torch.inference_mode()
    def _dummy_run(
        self,
        num_tokens: int,
        cudagraph_runtime_mode: CUDAGraphMode | None = None,
        force_attention: bool = False,
        uniform_decode: bool = False,
        allow_microbatching: bool = True,
        skip_eplb: bool = False,
        is_profile: bool = False,
        create_mixed_batch: bool = False,
        remove_lora: bool = True,
        is_graph_capturing: bool = False,
        num_active_loras: int = 0,
        profile_seq_lens: int | None = None,
        batch_descriptor_override: BatchDescriptor | None = None,
    ) -> tuple[
        torch.Tensor | IntermediateTensors,
        torch.Tensor | None,
    ]:
        """
        Run a dummy forward pass to warm up/profile run or capture the
        CUDA graph for the model.

        Args:
            num_tokens: Number of tokens to run the dummy forward pass.
            cudagraph_runtime_mode: used to control the behavior.
                - if not set will determine the cudagraph mode based on using
                    the self.cudagraph_dispatcher.
                - CUDAGraphMode.NONE: No cudagraph, for warm up and profile run
                - CUDAGraphMode.PIECEWISE: Piecewise cudagraph.
                - CUDAGraphMode.FULL: Full cudagraph, attention metadata is
                    needed.
            force_attention: If True, always create attention metadata. Used to
                warm up attention backend when mode is NONE.
            uniform_decode: If True, the batch is a uniform decode batch.
            skip_eplb: If True, skip EPLB state update.
            is_profile: If True, this is a profile run.
            create_mixed_batch: If True, create a mixed batch with both decode
                (1 token) and prefill (multiple tokens) requests.
            remove_lora: If False, dummy LoRAs are not destroyed after the run
            num_active_loras: Number of distinct active LoRAs to capture for.
                LoRA is activated when num_active_loras > 0.
            profile_seq_lens: If provided, use this value for seq_lens instead
                of max_query_len. Used to profile attention workspace that
                scales with context length.
            batch_descriptor_override: Exact descriptor being captured. This
                keeps graph-wrapper keys aligned with a context-specialized
                capture even though a dummy batch has no live request state.
        """
        mm_config = self.vllm_config.model_config.multimodal_config
        if mm_config and mm_config.mm_encoder_only:
            # The current dummy run only covers LM execution, so we can skip it.
            # mm encoder dummy run may need to add in the future.
            return torch.tensor([]), torch.tensor([])

        _sm70_profile_trace(
            "_dummy_run start num_tokens=%s mode=%s force_attention=%s "
            "uniform_decode=%s is_profile=%s is_graph_capturing=%s "
            "profile_seq_lens=%s",
            num_tokens,
            cudagraph_runtime_mode,
            force_attention,
            uniform_decode,
            is_profile,
            is_graph_capturing,
            profile_seq_lens,
        )
        skip_compiled_profile = (
            is_profile
            and bool(graph_policy().compile_graph)
            and bool(self.vllm_config.compilation_config.runtime.eager_profile_run)
            and current_platform.is_device_capability(70)
        )

        assert (
            cudagraph_runtime_mode is None
            or cudagraph_runtime_mode.is_valid_runtime_mode()
        )

        # If cudagraph_mode.decode_mode() == FULL and
        # cudagraph_mode.separate_routine(). This means that we are using
        # different graphs and/or modes for mixed prefill-decode batches vs.
        # uniform decode batches. A uniform decode batch means that all
        # requests have identical query length, except a potential virtual
        # request (shorter) in the batch account for padding.
        # Uniform decode batch could either be common pure decode, where
        # max_query_len == 1, or speculative decode, where
        # max_query_len == 1 + num_spec_decode_tokens.

        # When setting max_query_len = 1, we switch to and capture the optimized
        # routine of FA2 for pure decode, i.e., Flashdecode + an optimization
        # for GQA/MQA.
        max_query_len = self.uniform_decode_query_len if uniform_decode else num_tokens

        # Set num_scheduled_tokens based on num_tokens and max_num_seqs
        # for dummy run with LoRA so that the num_reqs collectively
        # has num_tokens in total.
        assert num_tokens <= self.max_num_tokens
        max_num_reqs = self.scheduler_config.max_num_seqs
        if create_mixed_batch:
            assert not uniform_decode
            # Create mixed batch:
            # first half decode tokens, second half one prefill
            num_decode_tokens = min(max_num_reqs - 1, num_tokens // 2)
            num_prefill_tokens = num_tokens - num_decode_tokens
            num_reqs = num_decode_tokens + 1

            # Create decode requests (1 token each) followed by prefill request
            num_scheduled_tokens_list = [1] * num_decode_tokens + [num_prefill_tokens]
            # Note: Overriding max_query_len to be the prefill tokens
            max_query_len = num_prefill_tokens
        elif uniform_decode:
            assert not create_mixed_batch
            num_reqs = min(max_num_reqs, cdiv(num_tokens, max_query_len))
            num_scheduled_tokens_list = [max_query_len] * num_reqs
            if num_tokens % max_query_len != 0:
                num_scheduled_tokens_list[-1] = num_tokens % max_query_len
        else:
            num_reqs = min(num_tokens, max_num_reqs)
            min_tokens_per_req = num_tokens // num_reqs
            num_scheduled_tokens_list = [min_tokens_per_req] * num_reqs
            num_scheduled_tokens_list[-1] += num_tokens % num_reqs

        assert sum(num_scheduled_tokens_list) == num_tokens
        assert len(num_scheduled_tokens_list) == num_reqs
        num_scheduled_tokens = np.array(num_scheduled_tokens_list, dtype=np.int32)
        num_tokens_unpadded = int(num_scheduled_tokens.sum())

        num_sampled_tokens = np.ones(num_reqs, dtype=np.int32)

        _cudagraph_mode, batch_desc, should_ubatch, num_tokens_across_dp, _ = (
            self._determine_batch_execution_and_padding(
                num_tokens=num_tokens_unpadded,
                num_reqs=num_reqs,
                num_scheduled_tokens_np=num_scheduled_tokens,
                max_num_scheduled_tokens=max_query_len,
                use_cascade_attn=False,
                allow_microbatching=allow_microbatching,
                force_eager=is_profile
                or (cudagraph_runtime_mode == CUDAGraphMode.NONE),
                # `force_uniform_decode` is used for cudagraph capture; because for
                # capturing mixed prefill-decode batches, we sometimes use
                # num_tokens == num_reqs which looks like a uniform decode batch to the
                # dispatcher; but we actually want to capture a piecewise cudagraph
                force_uniform_decode=uniform_decode,
                # `force_has_lora` is used for cudagraph capture; because LoRA is
                # activated later in the context manager, but we need to know the
                # LoRA state when determining the batch descriptor for capture
                force_has_lora=num_active_loras > 0,
                # `force_num_active_loras` is used for cudagraph capture; because we
                # need to capture graphs for specific num_active_loras counts
                force_num_active_loras=num_active_loras,
                attention_context_len=(
                    batch_descriptor_override.attention_context_bucket
                    if batch_descriptor_override is not None
                    else profile_seq_lens
                ),
            )
        )

        if cudagraph_runtime_mode is None:
            cudagraph_runtime_mode = _cudagraph_mode
        else:
            assert cudagraph_runtime_mode == _cudagraph_mode, (
                f"Cudagraph runtime mode mismatch in dummy_run. "
                f"Expected {_cudagraph_mode}, but got {cudagraph_runtime_mode}."
            )

        if batch_descriptor_override is not None:
            if _cudagraph_mode != CUDAGraphMode.NONE:
                assert (
                    batch_descriptor_override.num_tokens == batch_desc.num_tokens
                    and batch_descriptor_override.num_reqs == batch_desc.num_reqs
                    and batch_descriptor_override.uniform == batch_desc.uniform
                    and batch_descriptor_override.has_lora == batch_desc.has_lora
                    and batch_descriptor_override.num_active_loras
                    == batch_desc.num_active_loras
                ), (
                    "Context-specialized CUDA graph descriptor does not match its "
                    f"dummy batch: {batch_descriptor_override=} {batch_desc=}"
                )
            batch_desc = batch_descriptor_override

        num_tokens_padded = batch_desc.num_tokens
        num_reqs_padded = (
            batch_desc.num_reqs if batch_desc.num_reqs is not None else num_reqs
        )
        _sm70_profile_trace(
            "_dummy_run batch num_reqs=%s num_tokens_unpadded=%s "
            "num_tokens_padded=%s num_reqs_padded=%s max_query_len=%s "
            "runtime_mode=%s should_ubatch=%s",
            num_reqs,
            num_tokens_unpadded,
            num_tokens_padded,
            num_reqs_padded,
            max_query_len,
            cudagraph_runtime_mode,
            should_ubatch,
        )
        ubatch_slices, ubatch_slices_padded = maybe_create_ubatch_slices(
            should_ubatch,
            num_scheduled_tokens,
            num_tokens_padded,
            num_reqs_padded,
            self.vllm_config.parallel_config.num_ubatches,
        )
        logger.debug(
            "ubatch_slices: %s, ubatch_slices_padded: %s",
            ubatch_slices,
            ubatch_slices_padded,
        )

        attn_metadata: PerLayerAttnMetadata | None = None

        slot_mappings_by_group, slot_mappings = self._get_slot_mappings(
            num_tokens_padded=num_tokens_padded,
            num_reqs_padded=num_reqs_padded,
            num_tokens_unpadded=num_tokens_unpadded,
            ubatch_slices=ubatch_slices_padded,
        )

        # Dummy runs have no real slot assignments — fill with -1 so
        # concat_and_cache kernels skip the KV write.
        if slot_mappings_by_group is not None:
            for sm in slot_mappings_by_group.values():
                sm.fill_(-1)

        # _dummy_run shares pinned CPU buffers (seq_lens, query_start_loc,
        # etc.) with execute_model.  It must participate in the same event
        # protocol so that back-to-back dummy/real steps don't overwrite
        # pinned memory while a prior non_blocking H2D DMA is still reading.
        with self.synchronize_input_prep():
            # If force_attention is True, we always capture attention.
            # Otherwise, it only happens for cudagraph_runtime_mode=FULL.
            if force_attention or cudagraph_runtime_mode == CUDAGraphMode.FULL:
                if profile_seq_lens is not None:
                    seq_lens = profile_seq_lens  # type: ignore[assignment]
                elif create_mixed_batch:
                    # In the mixed batch mode (used for FI warmup), we use
                    # shorter sequence lengths to run faster.
                    # TODO(luka) better system for describing dummy batches
                    seq_lens = torch.tensor(  # type: ignore[assignment]
                        [1] * num_decode_tokens + [num_prefill_tokens + 1],
                        dtype=torch.int,
                    )
                else:
                    seq_lens = max_query_len  # type: ignore[assignment]
                self.optimistic_seq_lens_cpu[:num_reqs] = seq_lens
                self.optimistic_seq_lens_cpu[num_reqs:].fill_(0)
                self.seq_lens.copy_(self.optimistic_seq_lens_cpu, non_blocking=True)

                cum_num_tokens = self._get_cumsum_and_arange(
                    num_scheduled_tokens, self.query_pos.np
                )
                self.query_start_loc.np[1 : num_reqs + 1] = cum_num_tokens
                self.query_start_loc.np[num_reqs + 1 :].fill(cum_num_tokens[-1])
                self._copy_buffer_to_gpu(self.query_start_loc)

                # Sync block table CPU->GPU so cleared rows from
                # remove_request() are visible to the attention metadata
                # builder. Without this, stale block IDs from finished
                # requests can corrupt Mamba state.
                self._commit_block_table_to_gpu(num_reqs_padded)

                force_spec_graph_metadata = (
                    self.speculative_config is not None
                    and uniform_decode
                    and max_query_len > 1
                    and force_attention
                    and bool(self.vllm_config.kernel_config.gdn.state.spec_core)
                    and current_platform.is_device_capability(70)
                )
                # SM70 Qwen GDN split spec-core is part of the compiled FULL
                # graph. Its first AOT warmup must see the same active-spec
                # tensor shapes as replay; otherwise empty metadata tensors get
                # frozen into the graph before CUDA graph capture.
                build_for_capture = is_graph_capturing or force_spec_graph_metadata
                dummy_ddtree_parent_metadata = None
                if (
                    build_for_capture
                    and self.speculative_config is not None
                    and self.speculative_config.use_dflash_ddtree()
                    and not self.speculative_config.ddtree_disable_tree_verify
                ):
                    dummy_ddtree_parent_metadata = self._dummy_ddtree_parent_metadata(
                        num_reqs=num_reqs,
                        num_reqs_padded=num_reqs_padded,
                    )
                pad_attn = cudagraph_runtime_mode == CUDAGraphMode.FULL
                attn_metadata, _ = self._build_attention_metadata(
                    num_tokens=num_tokens_unpadded,
                    num_tokens_padded=num_tokens_padded if pad_attn else None,
                    num_reqs=num_reqs,
                    num_reqs_padded=num_reqs_padded if pad_attn else None,
                    max_query_len=max_query_len,
                    ubatch_slices=(ubatch_slices_padded if pad_attn else ubatch_slices),
                    for_cudagraph_capture=build_for_capture,
                    is_dummy_batch=True,
                    slot_mappings=slot_mappings_by_group,
                    use_spec_decode=self.speculative_config is not None,
                    ddtree_parent_metadata=dummy_ddtree_parent_metadata,
                    cudagraph_capture_max_seq_len=(
                        batch_desc.attention_context_bucket
                        if is_graph_capturing
                        else None
                    ),
                    cudagraph_graph_variant=(
                        batch_desc.graph_variant
                        if batch_descriptor_override is not None
                        else None
                    ),
                )
                _sm70_profile_trace(
                    "_dummy_run attention metadata built num_tokens=%s "
                    "num_tokens_padded=%s num_reqs=%s max_query_len=%s "
                    "num_reqs_padded=%s pad_attn=%s capture=%s",
                    num_tokens_unpadded,
                    num_tokens_padded if pad_attn else None,
                    num_reqs,
                    max_query_len,
                    num_reqs_padded if pad_attn else None,
                    pad_attn,
                    is_graph_capturing,
                )

        with self.maybe_dummy_run_with_lora(
            self.lora_config,
            num_scheduled_tokens,
            num_sampled_tokens,
            remove_lora,
            num_active_loras,
        ):
            # Make sure padding doesn't exceed max_num_tokens
            assert num_tokens_padded <= self.max_num_tokens
            model_kwargs = self._init_model_kwargs()
            if self.supports_mm_inputs and not self.model_config.is_encoder_decoder:
                input_ids, inputs_embeds = self._prepare_mm_inputs(num_tokens_padded)

                model_kwargs = {
                    **model_kwargs,
                    **self._dummy_mm_kwargs(num_reqs),
                }
            elif self.enable_prompt_embeds:
                input_ids = None
                inputs_embeds = self.inputs_embeds.gpu[:num_tokens_padded]
                model_kwargs = self._init_model_kwargs()
            else:
                input_ids = self.input_ids.gpu[:num_tokens_padded]
                inputs_embeds = None

            self._maybe_add_ngram_kwargs(
                model_kwargs,
                num_reqs=num_reqs,
                num_reqs_padded=num_reqs_padded,
                is_first_rank=get_pp_group().is_first_rank,
                is_encoder_decoder=self.model_config.is_encoder_decoder,
                use_dummy_context=True,
                num_scheduled_tokens=num_scheduled_tokens,
            )

            if self._ple_offload_connector is not None:
                self._ple_offload_connector.prepare_forward(
                    num_reqs,
                    num_tokens_padded,
                    dummy_run=True,
                )

            if self.uses_mrope:
                positions = self.mrope_positions.gpu[:, :num_tokens_padded]
            elif self.uses_xdrope_dim > 0:
                positions = self.xdrope_positions.gpu[:, :num_tokens_padded]
            else:
                # A dummy batch can hold more tokens than one sequence may
                # (max_num_batched_tokens > max_model_len); wrap so every
                # position stays inside the model's position table.
                self.positions[:num_tokens_padded].copy_(
                    torch.arange(
                        num_tokens_padded,
                        dtype=torch.int64,
                        device=self.device,
                    )
                    % self.max_model_len
                )
                positions = self.positions[:num_tokens_padded]

            if get_pp_group().is_first_rank:
                intermediate_tensors = None
            else:
                if self.intermediate_tensors is None:
                    self.intermediate_tensors = (
                        self.model.make_empty_intermediate_tensors(
                            batch_size=self.max_num_tokens,
                            dtype=self.model_config.dtype,
                            device=self.device,
                        )
                    )

                intermediate_tensors = self.sync_and_gather_intermediate_tensors(
                    num_tokens_padded, None, False
                )

            if ubatch_slices_padded is not None:
                # Adjust values to reflect a single ubatch.
                # TODO(sage,lucas): this is cruft that should be addressed in
                #  the padding refactor.
                num_tokens_padded = ubatch_slices_padded[0].num_tokens
                if num_tokens_across_dp is not None:
                    num_tokens_across_dp[:] = num_tokens_padded

            with (
                self.maybe_randomize_inputs(input_ids, inputs_embeds),
                set_forward_context(
                    attn_metadata,
                    self.vllm_config,
                    num_tokens=num_tokens_padded,
                    num_tokens_across_dp=num_tokens_across_dp,
                    cudagraph_runtime_mode=cudagraph_runtime_mode,
                    batch_descriptor=batch_desc,
                    ubatch_slices=ubatch_slices_padded,
                    slot_mapping=slot_mappings,
                    skip_compiled=skip_compiled_profile,
                    is_dummy_run=True,
                ),
            ):
                _sm70_profile_trace(
                    "_dummy_run model forward enter num_tokens_padded=%s "
                    "runtime_mode=%s attn_metadata=%s skip_compiled=%s",
                    num_tokens_padded,
                    cudagraph_runtime_mode,
                    type(attn_metadata).__name__ if attn_metadata is not None else None,
                    skip_compiled_profile,
                )
                outputs = self.model(
                    input_ids=input_ids,
                    positions=positions,
                    intermediate_tensors=intermediate_tensors,
                    inputs_embeds=inputs_embeds,
                    **model_kwargs,
                )
                _sm70_profile_trace("_dummy_run model forward exit")
            if self._ple_offload_connector is not None:
                self._ple_offload_connector.release_outputs()

            if self.use_aux_hidden_state_outputs:
                hidden_states, _ = outputs
            else:
                hidden_states = outputs

            if isinstance(hidden_states, IntermediateTensors):
                assert not get_pp_group().is_last_rank
                # Non-last PP ranks return intermediate tensors instead of
                # logits-bearing hidden states. Dummy-run callers only need a
                # tensor to preserve the profiling/capture return contract.
                hidden_states = _unwrap_pipeline_intermediate_hidden_states(
                    hidden_states
                )

            if (
                self.speculative_config
                and get_pp_group().is_last_rank
                and (
                    self.speculative_config.use_eagle()
                    or self.speculative_config.uses_draft_model()
                    or self.speculative_config.uses_extract_hidden_states()
                )
            ):
                assert isinstance(
                    self.drafter,
                    EagleProposer
                    | DFlashProposer
                    | DraftModelProposer
                    | ExtractHiddenStatesProposer
                    | Gemma4Proposer,
                )
                assert self.speculative_config is not None
                # PIECEWISE drafters are captured while the target PIECEWISE
                # graph is being captured. FULL drafters, if enabled in future,
                # must be captured separately after target capture.
                use_cudagraphs = (
                    (
                        is_graph_capturing
                        and cudagraph_runtime_mode == CUDAGraphMode.PIECEWISE
                    )
                    or (
                        not is_graph_capturing
                        and cudagraph_runtime_mode != CUDAGraphMode.NONE
                    )
                ) and not self.speculative_config.enforce_eager

                # Note(gnovack) - We need to disable cudagraphs for one of the two
                # lora cases when cudagraph_specialize_lora is enabled. This is a
                # short term mitigation for issue mentioned in
                # https://github.com/vllm-project/vllm/issues/28334
                if (
                    self.compilation_config.cudagraph_specialize_lora
                    and num_active_loras > 0
                ):
                    use_cudagraphs = False

                self.drafter.dummy_run(
                    num_tokens,
                    use_cudagraphs=use_cudagraphs,
                    is_graph_capturing=is_graph_capturing,
                    slot_mappings=slot_mappings,
                )

        # We register layerwise NVTX hooks here after the first dynamo tracing is
        # done to avoid nvtx operations in hook functions being traced by
        # torch dynamo and causing graph breaks.
        # Note that for DYNAMO_ONCE and VLLM_COMPILE mode,
        # compiled model's dynamo tracing is only done once and the compiled model's
        # __call__ function is replaced by calling the compiled function.
        # So it's safe to register hooks here. Hooks will be registered to
        # both compiled and uncompiled models but they will never
        # be called on the compiled model execution path.
        self._register_layerwise_nvtx_hooks()

        # This is necessary to avoid blocking DP.
        # For dummy runs, we typically skip EPLB since we don't have any real
        # requests to process.
        # However, in DP settings, there may be cases when some DP ranks do
        # not have any requests to process, so they're executing dummy batches.
        # In such cases, we still have to trigger EPLB to make sure
        # ranks execute the rearrangement in synchronization.
        if not skip_eplb:
            _sm70_profile_trace("_dummy_run eplb enter is_profile=%s", is_profile)
            self.eplb_step(is_dummy=True, is_profile=is_profile)
            _sm70_profile_trace("_dummy_run eplb exit")

        sample_hidden_states = _select_dummy_sample_hidden_states(
            hidden_states, num_scheduled_tokens, self.device
        )
        _sm70_profile_trace(
            "_dummy_run return hidden_type=%s sampled_shape=%s",
            type(hidden_states).__name__,
            (
                tuple(sample_hidden_states.shape)
                if sample_hidden_states is not None
                else None
            ),
        )
        return hidden_states, sample_hidden_states

    @torch.inference_mode()
    def _dummy_sampler_run(
        self,
        hidden_states: torch.Tensor,
    ) -> torch.Tensor:
        # The dummy hidden states may contain special values,
        # like `inf` or `nan`.
        # To avoid breaking the sampler, we use a random tensor here instead.

        mm_config = self.vllm_config.model_config.multimodal_config
        if mm_config and mm_config.mm_encoder_only:
            # MM Encoder only model no need to run sampler.
            return torch.tensor([])

        hidden_states = torch.rand_like(hidden_states)

        logits = self.model.compute_logits(hidden_states)
        num_reqs = logits.size(0)

        dummy_tensors = lambda v: torch.full((num_reqs,), v, device=self.device)

        dummy_metadata = SamplingMetadata(
            temperature=dummy_tensors(0.5),
            all_greedy=False,
            all_random=False,
            top_p=dummy_tensors(0.9),
            top_k=dummy_tensors(logits.size(1) - 1),
            generators={},
            max_num_logprobs=None,
            logprob_token_ids=None,
            no_penalties=True,
            prompt_token_ids=None,
            frequency_penalties=dummy_tensors(0.1),
            presence_penalties=dummy_tensors(0.1),
            repetition_penalties=dummy_tensors(0.1),
            output_token_ids=[[] for _ in range(num_reqs)],
            spec_token_ids=[[] for _ in range(num_reqs)],
            allowed_token_ids_mask=None,
            bad_words_token_ids={},
            logitsprocs=LogitsProcessors(),
        )
        try:
            sampler_output = self.sampler(
                logits=logits, sampling_metadata=dummy_metadata
            )
            # Also warm forward_native (taken when generators dict is non-empty),
            # but skip the extra call in 'processed_logits' / 'processed_logprobs'
            # modes — there TopKTopPSampler binds forward = forward_native at
            # init time, so the warmup call is redundant and only inflates peak
            # memory during profile_run.
            # No .clone() of logits: warmup output is discarded, so any in-place
            # mutation by forward_native does not affect correctness.
            if self.sampler.logprobs_mode not in (
                "processed_logits",
                "processed_logprobs",
            ):
                self.sampler(
                    logits=logits,
                    sampling_metadata=replace(
                        dummy_metadata,
                        generators={
                            0: torch.Generator(device=self.device).manual_seed(0)
                        },
                    ),
                )
        except RuntimeError as e:
            if "out of memory" in str(e):
                raise RuntimeError(
                    "CUDA out of memory occurred when warming up sampler with "
                    f"{num_reqs} dummy requests. Please try lowering "
                    "`max_num_seqs` or `gpu_memory_utilization` when "
                    "initializing the engine."
                ) from e
            else:
                raise e
        if self.speculative_config:
            num_dummy_draft_tokens = max(1, self.num_spec_tokens)
            draft_token_ids = [[0] * num_dummy_draft_tokens for _ in range(num_reqs)]
            dummy_spec_decode_metadata = SpecDecodeMetadata.make_dummy(
                draft_token_ids, self.device
            )

            num_tokens = sum(len(ids) for ids in draft_token_ids)
            draft_probs = None
            if (
                self.speculative_config.rejection_sample_method == "standard"
                and self.speculative_config.draft_sample_method == "probabilistic"
            ):
                draft_probs = torch.rand(
                    num_tokens,
                    logits.shape[-1],
                    device=self.device,
                    dtype=torch.float32,
                )
                draft_probs = torch.softmax(draft_probs, dim=-1)
            logits = torch.randn(
                num_tokens + num_reqs,
                logits.shape[-1],
                device=self.device,
                dtype=logits.dtype,
            )
            self.rejection_sampler(
                dummy_spec_decode_metadata,
                draft_probs,
                logits,
                dummy_metadata,
            )
            # The mixed-sampling warmup above passes a non-null is_greedy
            # tensor. Pure greedy serving passes None and otherwise triggers a
            # separate Triton compile during the first decode verifier step.
            greedy_metadata = replace(
                dummy_metadata,
                temperature=torch.zeros_like(dummy_metadata.temperature),
                all_greedy=True,
                all_random=False,
            )
            self.rejection_sampler(
                dummy_spec_decode_metadata,
                None,
                logits,
                greedy_metadata,
            )
        return sampler_output

    def _dummy_pooler_run_task(
        self,
        hidden_states: torch.Tensor,
        task: PoolingTask,
    ) -> PoolerOutput:
        num_tokens = hidden_states.shape[0]
        max_num_reqs = self.scheduler_config.max_num_seqs
        num_reqs = min(num_tokens, max_num_reqs)
        min_tokens_per_req = num_tokens // num_reqs
        num_scheduled_tokens_np = np.full(num_reqs, min_tokens_per_req)
        num_scheduled_tokens_np[-1] += num_tokens % num_reqs
        assert np.sum(num_scheduled_tokens_np) == num_tokens
        assert len(num_scheduled_tokens_np) == num_reqs

        req_num_tokens = num_tokens // num_reqs

        dummy_prompt_lens = torch.from_numpy(num_scheduled_tokens_np)
        dummy_token_ids = torch.zeros(
            (num_reqs, req_num_tokens), dtype=torch.int32, device=self.device
        )

        model = cast(VllmModelForPooling, self.get_model())
        dummy_pooling_params = PoolingParams(task=task)
        dummy_pooling_params.verify(self.model_config)
        to_update = model.pooler.get_pooling_updates(task)
        to_update.apply(dummy_pooling_params)

        dummy_metadata = PoolingMetadata(
            prompt_lens=dummy_prompt_lens,
            prompt_token_ids=dummy_token_ids,
            prompt_token_ids_cpu=dummy_token_ids.cpu(),
            pooling_params=[dummy_pooling_params] * num_reqs,
            pooling_states=[PoolingStates() for i in range(num_reqs)],
        )

        dummy_metadata.build_pooling_cursor(
            num_scheduled_tokens_np,
            seq_lens_cpu=dummy_prompt_lens,
            device=hidden_states.device,
        )

        try:
            return model.pooler(
                hidden_states=hidden_states, pooling_metadata=dummy_metadata
            )
        except RuntimeError as e:
            if "out of memory" in str(e):
                raise RuntimeError(
                    "CUDA out of memory occurred when warming up pooler "
                    f"({task=}) with {num_reqs} dummy requests. Please try "
                    "lowering `max_num_seqs` or `gpu_memory_utilization` when "
                    "initializing the engine."
                ) from e
            else:
                raise e

    @torch.inference_mode()
    def _dummy_pooler_run(
        self,
        hidden_states: torch.Tensor,
    ) -> PoolerOutput:
        mm_config = self.vllm_config.model_config.multimodal_config
        if mm_config and mm_config.mm_encoder_only:
            # MM Encoder only model not need to run pooler.
            return torch.tensor([])

        # Find the task that has the largest output for subsequent steps
        supported_pooling_tasks = self.get_supported_pooling_tasks()

        if not supported_pooling_tasks:
            raise RuntimeError(
                f"Model {self.model_config.model} does not support "
                "any pooling tasks. See "
                "https://docs.vllm.ai/en/latest/models/pooling_models.html "
                "to learn more."
            )

        output_size = dict[PoolingTask, float]()
        for task in supported_pooling_tasks:
            # Run a full batch with each task to ensure none of them OOMs
            output = self._dummy_pooler_run_task(hidden_states, task)
            output_size[task] = sum(o.nbytes for o in output if o is not None)
            del output  # Allow GC

        max_task = max(output_size.items(), key=lambda x: x[1])[0]
        return self._dummy_pooler_run_task(hidden_states, max_task)

    def profile_run(self) -> None:
        profile_start = time.perf_counter()
        _sm70_profile_trace(
            "profile_run start max_num_tokens=%s max_num_seqs=%s",
            self.max_num_tokens,
            self.scheduler_config.max_num_seqs,
        )
        # Profile with multimodal encoder & encoder cache.
        if self.supports_mm_inputs:
            mm_config = self.model_config.multimodal_config
            if mm_config is not None and mm_config.skip_mm_profiling:
                logger.info(
                    "Skipping memory profiling for multimodal encoder and "
                    "encoder cache."
                )
            else:
                mm_budget = self.mm_budget
                assert mm_budget is not None

                if (encoder_budget := mm_budget.get_encoder_budget()) > 0:
                    if not mm_budget.mm_max_toks_per_item:
                        # All modality limits are 0 — embedding-only mode.
                        # Budget is non-zero for embedding storage, but
                        # there's no encoder to profile.
                        logger.info(
                            "Skipping encoder profiling for embedding-only "
                            "mode (all modality limits=0 with "
                            "enable_mm_embeds=True).",
                        )
                    else:
                        # NOTE: Currently model is profiled with a single
                        # non-text modality with the max possible input
                        # tokens even when it supports multiple.
                        dummy_modality = mm_budget.get_modality_with_max_tokens()
                        max_mm_items_per_batch = mm_budget.mm_max_items_per_batch[
                            dummy_modality
                        ]

                        logger.info_once(
                            "Encoder cache will be initialized with a "
                            "budget of %s tokens, and profiled with "
                            "%s %s items of the maximum feature size.",
                            encoder_budget,
                            max_mm_items_per_batch,
                            dummy_modality,
                        )

                        # Create dummy batch of multimodal inputs.
                        batched_dummy_mm_inputs = self._get_mm_dummy_batch(
                            dummy_modality,
                            max_mm_items_per_batch,
                        )

                        # Run multimodal encoder.
                        dummy_encoder_outputs = self.model.embed_multimodal(
                            **batched_dummy_mm_inputs
                        )

                        sanity_check_mm_encoder_outputs(
                            dummy_encoder_outputs,
                            expected_num_items=max_mm_items_per_batch,
                        )
                        for i, output in enumerate(dummy_encoder_outputs):
                            self.encoder_cache[f"tmp_{i}"] = output

        # Add `is_profile` here to pre-allocate communication buffers
        _sm70_profile_trace("profile_run dummy_run enter")
        hidden_states, last_hidden_states = self._dummy_run(
            self.max_num_tokens, is_profile=True
        )
        _sm70_profile_trace(
            "profile_run dummy_run exit hidden_type=%s last_hidden_shape=%s",
            type(hidden_states).__name__,
            (
                tuple(last_hidden_states.shape)
                if last_hidden_states is not None
                else None
            ),
        )
        if get_pp_group().is_last_rank:
            assert isinstance(hidden_states, torch.Tensor)
            assert last_hidden_states is not None
            if self.is_pooling_model:
                _sm70_profile_trace("profile_run pooler enter")
                output = self._dummy_pooler_run(hidden_states)
                _sm70_profile_trace("profile_run pooler exit")
            else:
                _sm70_profile_trace("profile_run sampler enter")
                output = self._dummy_sampler_run(last_hidden_states)
                _sm70_profile_trace("profile_run sampler exit")
        else:
            output = None
        _sm70_profile_trace("profile_run sync enter")
        self._sync_device()
        _sm70_profile_trace("profile_run sync exit")
        del hidden_states, output
        self.encoder_cache.clear()
        gc.collect()
        _sm70_profile_trace(
            "profile_run end elapsed_s=%.3f",
            time.perf_counter() - profile_start,
        )

    def _init_minimal_kv_cache_for_profiling(self) -> None:
        from vllm.v1.core.kv_cache_utils import (
            get_kv_cache_config_from_groups,
            get_kv_cache_groups,
        )

        kv_cache_spec = self.get_kv_cache_spec()
        kv_cache_groups = get_kv_cache_groups(self.vllm_config, kv_cache_spec)
        min_blocks = self.compilation_config.max_cudagraph_capture_size or 1

        # Temporarily change num_gpu_blocks_override to allocate a minimal KV cache
        saved_override = self.cache_config.num_gpu_blocks_override
        self.cache_config.num_gpu_blocks_override = min_blocks
        minimal_config = get_kv_cache_config_from_groups(
            self.vllm_config, kv_cache_groups, available_memory=0
        )
        self.cache_config.num_gpu_blocks_override = saved_override

        self.initialize_kv_cache(minimal_config, is_profiling=True)
        self.cache_config.num_gpu_blocks = minimal_config.num_blocks

        logger.debug("Initialized minimal KV cache for CUDA graph profiling")

    @staticmethod
    @contextmanager
    def _freeze_gc():
        gc.collect()
        should_freeze = not envs.VLLM_ENABLE_CUDAGRAPH_GC
        if should_freeze:
            gc.freeze()
        try:
            yield
        finally:
            if should_freeze:
                gc.unfreeze()
                gc.collect()

    def shutdown(self) -> None:
        """Release GPU tensors (model weights, KV caches, workspace) so that
        memory is reclaimable when running in the same process."""
        from vllm.model_executor.layers.rotary_embedding import _ROPE_DICT
        from vllm.v1.worker.workspace import reset_workspace_manager

        if self._ple_offload_connector is not None:
            self._ple_offload_connector.close()
            self._ple_offload_connector = None

        # Calls torch.accelerator.synchronize()
        self._cleanup_profiling_kv_cache()
        self.compilation_config.static_forward_context.clear()
        self.model = None  # type: ignore[assignment]
        _ROPE_DICT.clear()

        reset_workspace_manager()

    def _cleanup_profiling_kv_cache(self) -> None:
        torch.accelerator.synchronize()
        if hasattr(self, "kv_caches") and self.kv_caches:
            for i in range(len(self.kv_caches)):
                self.kv_caches[i] = None  # type: ignore
            self.kv_caches.clear()
        if hasattr(self, "cross_layers_kv_cache"):
            self.cross_layers_kv_cache = None
            self.cross_layers_attn_backend = None
        if hasattr(self, "attn_groups"):
            self.attn_groups.clear()
        if hasattr(self, "kv_cache_config"):
            delattr(self, "kv_cache_config")
        self.cache_config.num_gpu_blocks = None

        for layer in self.compilation_config.static_forward_context.values():
            if hasattr(layer, "kv_cache"):
                kv_cache = layer.kv_cache
                layer.kv_cache = (
                    torch.tensor([]) if isinstance(kv_cache, torch.Tensor) else []
                )
            # Clean up quantized KV cache scale views
            # (int8_per_token_head, fp8_per_token_head)
            if hasattr(layer, "impl"):
                if hasattr(layer.impl, "_k_scale_cache"):
                    layer.impl._k_scale_cache = None
                if hasattr(layer.impl, "_v_scale_cache"):
                    layer.impl._v_scale_cache = None

        gc.collect()
        torch.accelerator.empty_cache()

        logger.debug("Cleaned up profiling KV cache and CUDA graphs")

    @torch.inference_mode()
    def profile_cudagraph_memory(self) -> int:
        with set_current_vllm_config(self.vllm_config):
            self._init_minimal_kv_cache_for_profiling()

        saved_num_cudagraph_captured = compilation_counter.num_cudagraph_captured

        capture_descs = self.cudagraph_dispatcher.get_capture_descs()

        total_graphs = sum(len(descs) for _, descs in capture_descs)
        if total_graphs == 0:
            logger.debug("No CUDA graphs will be captured, skipping profiling")
            self._cleanup_profiling_kv_cache()
            return 0

        logger.info(
            "Profiling CUDA graph memory: %s",
            ", ".join(
                f"{mode.name}={len(descs)} (largest={descs[0].num_tokens})"
                for mode, descs in capture_descs
                if descs
            ),
        )

        # Use a temporary pool for profiling to avoid fragmentation in the main pool.
        profiling_pool = current_platform.graph_pool_handle()
        original_pools: dict[int, Any] = {}
        all_wrappers = list(CUDAGraphWrapper._all_instances) + list(
            BreakableCUDAGraphWrapper._all_instances
        )
        for instance in all_wrappers:
            original_pools[id(instance)] = instance.graph_pool
            instance.graph_pool = profiling_pool

        set_cudagraph_capturing_enabled(True)
        with self._freeze_gc(), graph_capture(device=self.device):
            shared_memory_estimate = {}
            per_graph_estimate = {}
            torch.accelerator.synchronize()
            torch.accelerator.empty_cache()

            for mode, descs in capture_descs:
                profile_descs = descs[:2]
                mem_samples: list[int] = []

                for i, desc in enumerate(profile_descs):
                    mem_before = torch.cuda.mem_get_info()[0]
                    self._warmup_and_capture(
                        desc,
                        cudagraph_runtime_mode=mode,
                        profile_seq_lens=(
                            (
                                desc.attention_context_bucket
                                if desc.attention_context_bucket is not None
                                else min(
                                    self.max_model_len,
                                    self.max_num_tokens // desc.num_tokens,
                                )
                            )
                            if mode == CUDAGraphMode.FULL and i == 0
                            else None
                        ),
                        batch_descriptor_override=desc,
                    )
                    torch.accelerator.synchronize()
                    free_after = torch.cuda.mem_get_info()[0]
                    mem_samples.append(mem_before - free_after)

                first_capture = mem_samples[0]
                # Use at least 1 MiB per graph for driver overhead
                per_graph = max(mem_samples[1] if len(mem_samples) > 1 else 0, 1 << 20)

                shared_memory_estimate[mode] = first_capture
                per_graph_estimate[mode] = per_graph * (len(descs) - 1)

                logger.debug(
                    "Estimated %s CUDA graph memory: "
                    "%.2f MiB first-capture + (%d-1) × %.2f MiB per-graph",
                    mode.name,
                    first_capture / (1 << 20),
                    len(descs),
                    per_graph / (1 << 20),
                )

        set_cudagraph_capturing_enabled(False)
        CUDAGraphWrapper.clear_all_graphs()
        BreakableCUDAGraphWrapper.clear_all_graphs()
        all_wrappers = list(CUDAGraphWrapper._all_instances) + list(
            BreakableCUDAGraphWrapper._all_instances
        )
        for instance in all_wrappers:
            if id(instance) in original_pools:
                instance.graph_pool = original_pools[id(instance)]
        for key_set in self.cudagraph_dispatcher.cudagraph_keys.values():
            key_set.clear()
        self.cudagraph_dispatcher.keys_initialized = False
        self.maybe_remove_all_loras(self.lora_config)
        self._cleanup_profiling_kv_cache()
        compilation_counter.num_cudagraph_captured = saved_num_cudagraph_captured

        # FULL and PIECEWISE graphs share the global pool at runtime and are
        # never replayed concurrently, so the pool overlays their memory.
        # Take the max to avoid double-counting the overlap.
        total_estimate = max(shared_memory_estimate.values()) + sum(
            per_graph_estimate.values()
        )
        logger.info(
            "Estimated CUDA graph memory: %.2f GiB total",
            total_estimate / (1 << 30),
        )

        return int(total_estimate)

    @instrument(span_name="Capture model")
    def capture_model(self) -> int:
        if self.compilation_config.cudagraph_mode == CUDAGraphMode.NONE:
            logger.warning(
                "Skipping CUDA graph capture. To turn on CUDA graph capture, "
                "ensure `cudagraph_mode` was not manually set to `NONE`"
            )
            return 0

        # Initialize encoder CUDA graph manager if enabled.
        # Use get_model() to unwrap CUDAGraphWrapper/UBatchWrapper,
        # because @runtime_checkable Protocol isinstance() checks do not
        # work through __getattr__ forwarding.
        if (
            self.compilation_config.cudagraph_mm_encoder
            and self.supports_mm_inputs
            and self.encoder_cudagraph_manager is None
        ):
            from vllm.model_executor.models.interfaces import (
                SupportsEncoderCudaGraph,
                supports_encoder_cudagraph,
            )
            from vllm.v1.worker.encoder_cudagraph import (
                EncoderCudaGraphManager,
            )

            raw_model = self.get_model()
            if supports_encoder_cudagraph(raw_model):
                self.encoder_cudagraph_manager = EncoderCudaGraphManager(
                    vllm_config=self.vllm_config,
                    device=self.device,
                    dtype=self.dtype,
                    model=cast(SupportsEncoderCudaGraph, raw_model),
                )
                logger.info("Initialized EncoderCudaGraphManager for vision encoder")

        compilation_counter.num_gpu_runner_capture_triggers += 1

        start_time = time.perf_counter()

        # Trigger CUDA graph capture for specific shapes.
        # Capture the large shapes first so that the smaller shapes
        # can reuse the memory pool allocated for the large shapes.
        set_cudagraph_capturing_enabled(True)
        with self._freeze_gc(), graph_capture(device=self.device):
            torch.accelerator.synchronize()
            torch.accelerator.empty_cache()
            start_free_gpu_memory = torch.cuda.mem_get_info()[0]

            for (
                runtime_mode,
                batch_descs,
            ) in self.cudagraph_dispatcher.get_capture_descs():
                self._capture_cudagraphs(
                    batch_descriptors=batch_descs,
                    cudagraph_runtime_mode=runtime_mode,
                )
                torch.accelerator.synchronize()

            self._capture_drafter_cudagraphs()

            # Capture encoder CUDA graphs if enabled
            if self.encoder_cudagraph_manager is not None:
                self.encoder_cudagraph_manager.capture()

            torch.accelerator.synchronize()
            end_free_gpu_memory = torch.cuda.mem_get_info()[0]

        # Disable cudagraph capturing globally, so any unexpected cudagraph
        # capturing will be detected and raise an error after here.
        # Note: We don't put it into graph_capture context manager because
        # we may do lazy capturing in future that still allows capturing
        # after here.
        set_cudagraph_capturing_enabled(False)

        torch.accelerator.synchronize()
        torch.accelerator.empty_cache()

        # Lock workspace to prevent resizing during execution.
        # Max workspace sizes should have been captured during warmup/profiling.
        lock_workspace()

        end_time = time.perf_counter()
        elapsed_time = end_time - start_time
        cuda_graph_size = start_free_gpu_memory - end_free_gpu_memory
        # This usually takes 5~20 seconds.
        logger.info_once(
            "Graph capturing finished in %.0f secs, took %.2f GiB",
            elapsed_time,
            cuda_graph_size / (1 << 30),
        )
        return cuda_graph_size

    def _warmup_and_capture(
        self,
        desc: BatchDescriptor,
        cudagraph_runtime_mode: CUDAGraphMode,
        profile_seq_lens: int | None = None,
        allow_microbatching: bool = False,
        num_warmups: int | None = None,
        batch_descriptor_override: BatchDescriptor | None = None,
    ):
        if num_warmups is None:
            num_warmups = self.compilation_config.cudagraph_num_of_warmups
        force_attention = cudagraph_runtime_mode == CUDAGraphMode.FULL
        for _ in range(num_warmups):
            self._dummy_run(
                desc.num_tokens,
                cudagraph_runtime_mode=CUDAGraphMode.NONE,
                force_attention=force_attention,
                uniform_decode=desc.uniform,
                allow_microbatching=allow_microbatching,
                skip_eplb=True,
                remove_lora=False,
                num_active_loras=desc.num_active_loras,
                profile_seq_lens=profile_seq_lens,
                batch_descriptor_override=batch_descriptor_override,
            )
        if (
            bool(graph_policy().compile_graph)
            and cudagraph_runtime_mode == CUDAGraphMode.FULL
            and current_platform.is_device_capability(70)
        ):
            logger.info_once(
                "Running SM70 Flash-V100 compile full-graph metadata warmup "
                "before CUDA graph capture."
            )
            self._dummy_run(
                desc.num_tokens,
                cudagraph_runtime_mode=CUDAGraphMode.NONE,
                force_attention=True,
                uniform_decode=desc.uniform,
                allow_microbatching=allow_microbatching,
                skip_eplb=True,
                remove_lora=False,
                is_graph_capturing=True,
                num_active_loras=desc.num_active_loras,
                profile_seq_lens=profile_seq_lens,
                batch_descriptor_override=batch_descriptor_override,
            )
            torch.accelerator.synchronize()
        _sync_sm70_before_compile_graph_capture(cudagraph_runtime_mode)
        self._dummy_run(
            desc.num_tokens,
            cudagraph_runtime_mode=cudagraph_runtime_mode,
            uniform_decode=desc.uniform,
            allow_microbatching=allow_microbatching,
            skip_eplb=True,
            remove_lora=False,
            num_active_loras=desc.num_active_loras,
            is_graph_capturing=True,
            profile_seq_lens=profile_seq_lens,
            batch_descriptor_override=batch_descriptor_override,
        )

    def _capture_cudagraphs(
        self,
        batch_descriptors: list[BatchDescriptor],
        cudagraph_runtime_mode: CUDAGraphMode,
    ):
        assert (
            cudagraph_runtime_mode != CUDAGraphMode.NONE
            and cudagraph_runtime_mode.is_valid_runtime_mode()
        ), f"Invalid cudagraph runtime mode: {cudagraph_runtime_mode}"

        if not batch_descriptors:
            return

        uniform_decode = batch_descriptors[0].uniform

        # Only rank 0 should print progress bar during capture
        if is_global_first_rank():
            batch_descriptors = tqdm(
                batch_descriptors,
                disable=not self.load_config.use_tqdm_on_load,
                desc="Capturing CUDA graphs ({}, {})".format(
                    "decode" if uniform_decode else "mixed prefill-decode",
                    cudagraph_runtime_mode.name,
                ),
            )

        # We skip EPLB here since we don't want to record dummy metrics
        for batch_desc in batch_descriptors:
            # We currently only capture ubatched graphs when its a FULL
            # cudagraph, a uniform decode batch, and the number of tokens
            # is above the threshold. Otherwise we just capture a non-ubatched
            # version of the graph
            allow_microbatching = (
                self.parallel_config.use_ubatching
                and cudagraph_runtime_mode == CUDAGraphMode.FULL
                and uniform_decode
                and check_ubatch_thresholds(
                    config=self.vllm_config.parallel_config,
                    num_tokens=batch_desc.num_tokens,
                    uniform_decode=uniform_decode,
                )
            )
            self._warmup_and_capture(
                batch_desc,
                cudagraph_runtime_mode=cudagraph_runtime_mode,
                allow_microbatching=allow_microbatching,
                profile_seq_lens=batch_desc.attention_context_bucket,
                batch_descriptor_override=batch_desc,
            )
            torch.accelerator.synchronize()
        self.maybe_remove_all_loras(self.lora_config)

    def _capture_drafter_cudagraphs(self) -> None:
        spec_config = self.speculative_config
        if (
            spec_config is None
            or spec_config.method != "mtp"
            or spec_config.enforce_eager
        ):
            return

        drafter = getattr(self, "drafter", None)
        if drafter is None or not isinstance(
            getattr(drafter, "model", None), CUDAGraphWrapper
        ):
            return

        dispatcher = getattr(drafter, "cudagraph_dispatcher", None)
        if dispatcher is None:
            return

        capture_descs = dispatcher.get_capture_descs()
        capture_descs = [
            (mode, descs) for mode, descs in capture_descs if mode == CUDAGraphMode.FULL
        ]
        if not capture_descs:
            logger.debug("No separate MTP drafter CUDA graphs will be captured")
            return

        logger.info(
            "Capturing MTP drafter CUDA graphs: %s",
            ", ".join(
                f"{mode.name}={len(descs)} (largest={descs[0].num_tokens})"
                for mode, descs in capture_descs
                if descs
            ),
        )

        num_warmups = self.compilation_config.cudagraph_num_of_warmups
        for runtime_mode, batch_descriptors in capture_descs:
            desc_iter = batch_descriptors
            if is_global_first_rank():
                desc_iter = tqdm(
                    batch_descriptors,
                    disable=not self.load_config.use_tqdm_on_load,
                    desc=f"Capturing MTP drafter CUDA graphs ({runtime_mode.name})",
                )

            for batch_desc in desc_iter:
                for _ in range(num_warmups):
                    drafter.dummy_run(
                        batch_desc.num_tokens,
                        use_cudagraphs=False,
                        is_graph_capturing=False,
                        spec_step_idx=batch_desc.graph_variant,
                    )
                drafter.dummy_run(
                    batch_desc.num_tokens,
                    use_cudagraphs=True,
                    is_graph_capturing=True,
                    spec_step_idx=batch_desc.graph_variant,
                )
                torch.accelerator.synchronize()

    def initialize_attn_backend(
        self,
        kv_cache_config: KVCacheConfig,
        is_profiling: bool = False,
    ) -> None:
        """
        Initialize the attention backends and attention metadata builders.
        """
        assert len(self.attn_groups) == 0, "Attention backends are already initialized"

        class AttentionGroupKey(NamedTuple):
            """Deduplication key for attention groups within a KV cache group.

            Splits on per-rank ``num_heads_q`` in addition to backend + spec
            so layers with different Q-head counts (e.g. a spec-decode draft
            with fewer attention heads than its target) get separate metadata
            builders. The builders' scratch (e.g. ``softmax_segm_*`` in
            ``triton_attn``, ``num_qo_heads`` in FlashInfer) is sized by
            ``num_heads_q`` and assumes uniformity within the group; see
            ``get_num_attention_heads_from_layers`` in
            ``vllm/v1/attention/backends/utils.py``.
            """

            attn_backend: type[AttentionBackend]
            kv_cache_spec: KVCacheSpec
            num_heads_q: int

        def get_attn_backends_for_group(
            kv_cache_group_spec: KVCacheGroupSpec,
        ) -> tuple[dict[AttentionGroupKey, list[str]], set[type[AttentionBackend]]]:
            layer_type = cast(type[Any], AttentionLayerBase)
            layers = get_layers_from_vllm_config(
                self.vllm_config, layer_type, kv_cache_group_spec.layer_names
            )
            attn_backends = {}
            attn_backend_layers = defaultdict(list)
            # Dedupe based on full class name; this is a bit safer than
            # using the class itself as the key because when we create dynamic
            # attention backend subclasses (e.g. ChunkedLocalAttention) unless
            # they are cached correctly, there will be different objects per
            # layer.
            for layer_name in kv_cache_group_spec.layer_names:
                attn_backend = layers[layer_name].get_attn_backend()

                if layer_name in self.kv_sharing_fast_prefill_eligible_layers:
                    attn_backend = create_fast_prefill_custom_backend(
                        "FastPrefill",
                        attn_backend,  # type: ignore[arg-type]
                    )

                full_cls_name = attn_backend.full_cls_name()
                layer_kv_cache_spec = kv_cache_group_spec.kv_cache_spec
                if isinstance(layer_kv_cache_spec, UniformTypeKVCacheSpecs):
                    layer_kv_cache_spec = layer_kv_cache_spec.kv_cache_specs[layer_name]
                # Non-Attention layer types (e.g. Mamba1, ShortConv) do not
                # expose ``num_heads``; fall back to 0 so they cluster as
                # before. Such layers never coexist with Attention in a
                # single KV cache group (different KVCacheSpec), so the
                # fallback can never spuriously merge them with attention
                # layers.
                num_heads_q = getattr(layers[layer_name], "num_heads", 0)
                key = (full_cls_name, layer_kv_cache_spec, num_heads_q)
                attn_backends[key] = AttentionGroupKey(
                    attn_backend, layer_kv_cache_spec, num_heads_q
                )
                attn_backend_layers[key].append(layer_name)
            return (
                {attn_backends[k]: v for k, v in attn_backend_layers.items()},
                set(group_key.attn_backend for group_key in attn_backends.values()),
            )

        def create_attn_groups(
            attn_backends_map: dict[AttentionGroupKey, list[str]],
            kv_cache_group_id: int,
        ) -> list[AttentionGroup]:
            attn_groups: list[AttentionGroup] = []
            for key, layer_names in attn_backends_map.items():
                attn_group = AttentionGroup(
                    key.attn_backend,
                    layer_names,
                    key.kv_cache_spec,
                    kv_cache_group_id,
                )

                attn_groups.append(attn_group)
            return attn_groups

        attention_backend_maps = []
        attention_backend_list = []
        for kv_cache_group_spec in kv_cache_config.kv_cache_groups:
            attn_backends = get_attn_backends_for_group(kv_cache_group_spec)
            attention_backend_maps.append(attn_backends[0])
            attention_backend_list.append(attn_backends[1])

        # Resolve cudagraph_mode before actually initialize metadata_builders
        self._check_and_update_cudagraph_mode(
            attention_backend_list,
            kv_cache_config.kv_cache_groups,
            is_profiling=is_profiling,
        )

        # Check if attention backend supports PCP&DCP and related features.
        check_attention_cp_compatibility(self.vllm_config)

        for i, attn_backend_map in enumerate(attention_backend_maps):
            self.attn_groups.append(create_attn_groups(attn_backend_map, i))

    def initialize_metadata_builders(
        self, kv_cache_config: KVCacheConfig, kernel_block_sizes: list[int]
    ) -> None:
        """
        Create the metadata builders for all KV cache groups and attn groups.
        """
        for kv_cache_group_id in range(len(kv_cache_config.kv_cache_groups)):
            for attn_group in self.attn_groups[kv_cache_group_id]:
                attn_group.create_metadata_builders(
                    self.vllm_config,
                    self.device,
                    kernel_block_sizes[kv_cache_group_id]
                    if kv_cache_group_id < len(kernel_block_sizes)
                    else None,
                    num_metadata_builders=1
                    if not self.parallel_config.use_ubatching
                    else self.parallel_config.num_ubatches,
                )
        # Calculate reorder batch threshold (if needed)
        # Note (tdoublep): do this *after* constructing builders,
        # because some of them change the threshold at init time.
        self.calculate_reorder_batch_threshold()

        # Initialize drafter attention backend
        if (
            self.speculative_config
            and get_pp_group().is_last_rank
            and (
                self.speculative_config.use_eagle()
                or self.speculative_config.uses_draft_model()
            )
        ):
            assert isinstance(
                self.drafter,
                EagleProposer | DFlashProposer | DraftModelProposer | Gemma4Proposer,
            )
            self.drafter.initialize_attn_backend(kv_cache_config, kernel_block_sizes)

    def _check_and_update_cudagraph_mode(
        self,
        attention_backends: list[set[type[AttentionBackend]]],
        kv_cache_groups: list[KVCacheGroupSpec],
        is_profiling: bool = False,
    ) -> None:
        """
        Resolve the cudagraph_mode when there are multiple attention
        groups with potential conflicting CUDA graph support.
        Then initialize the cudagraph_dispatcher based on the resolved
        cudagraph_mode.
        """
        min_cg_support = AttentionCGSupport.ALWAYS
        min_cg_attn_backend = None

        for attn_backend_set, kv_cache_group in zip(
            attention_backends, kv_cache_groups
        ):
            for attn_backend in attn_backend_set:
                builder_cls = attn_backend.get_builder_cls()

                cg_support = builder_cls.get_cudagraph_support(
                    self.vllm_config, kv_cache_group.kv_cache_spec
                )
                if cg_support.value < min_cg_support.value:
                    min_cg_support = cg_support
                    min_cg_attn_backend = attn_backend.__name__
        graph_query_len = self.uniform_decode_query_len
        if (
            self.model_config.hf_text_config.model_type == "deepseek_v41_text"
            and self.max_num_reqs == 1
            and self.compilation_config.cudagraph_mode == CUDAGraphMode.FULL
            and not self.compilation_config.pass_config.enable_sp
        ):
            # Exact single-request M1..6 graphs need no uniform-batch padding.
            # Rounding their capture sizes to six would also pad the native
            # M5 draft query, whose own graph reads five noncausal positions.
            graph_query_len = 1
        cudagraph_mode = self.compilation_config.resolve_cudagraph_mode_and_sizes(
            min_cg_support,
            min_cg_attn_backend,
            graph_query_len,
            self.parallel_config.tensor_parallel_size,
            self.kv_cache_config,
            self.max_num_reqs,
            is_profiling=is_profiling,
        )
        # Trigger cudagraph dispatching keys initialization after
        # resolved cudagraph mode.
        self.cudagraph_dispatcher.initialize_cudagraph_keys(
            cudagraph_mode, graph_query_len
        )

        # Initialize drafter's cudagraph dispatcher if using spec decode.
        if (
            self.speculative_config
            and get_pp_group().is_last_rank
            and (
                self.speculative_config.use_eagle()
                or self.speculative_config.uses_extract_hidden_states()
            )
        ):
            assert isinstance(
                self.drafter,
                EagleProposer
                | DFlashProposer
                | ExtractHiddenStatesProposer
                | Gemma4Proposer,
            )
            self.drafter.initialize_cudagraph_keys(cudagraph_mode)

    def calculate_reorder_batch_threshold(self) -> None:
        """
        Choose the minimum reorder batch threshold from all attention groups.
        Backends should be able to support lower threshold then what they request
        just may have a performance penalty due to that backend treating decodes
        as prefills.
        """
        min_none_high = lambda a, b: a if b is None else b if a is None else min(a, b)

        reorder_batch_thresholds: list[int | None] = [
            group.get_metadata_builder().reorder_batch_threshold
            for group in self._attn_group_iterator()
        ]
        # If there are no attention groups (attention-free model) or no backend
        # reports a threshold, leave reordering disabled.
        if len(reorder_batch_thresholds) == 0:
            self.reorder_batch_threshold = None
            return
        self.reorder_batch_threshold = reduce(min_none_high, reorder_batch_thresholds)  # type: ignore[assignment]

    def _set_mm_prefix_range_for_metadata(
        self,
        attn_metadata: Any,
        req_doc_ranges: dict[int, list[tuple[int, int]]],
    ) -> None:
        """Set mm_prefix_range for all attention metadata objects.

        This method handles both list and non-list attention metadata,
        computing mm_prefix_range_tensor once and sharing it across all
        metadata objects to avoid redundant host-to-device transfers.
        """
        from vllm.v1.attention.backends.triton_attn import (
            TritonAttentionMetadata,
        )

        # Get all metadata objects from either list or dict structure
        metadata_list = []
        if isinstance(attn_metadata, list):
            for ub_metadata in attn_metadata:
                metadata_list.extend(ub_metadata.values())
        else:
            metadata_list.extend(attn_metadata.values())

        # Set mm_prefix_range for all metadata and compute tensor once
        shared_tensor = None
        for metadata in metadata_list:
            metadata.mm_prefix_range = req_doc_ranges  # type: ignore[attr-defined]

            # Only compute tensor for TritonAttentionMetadata
            if isinstance(metadata, TritonAttentionMetadata):
                if shared_tensor is None:
                    shared_tensor = (
                        TritonAttentionMetadata.compute_mm_prefix_range_tensor(
                            req_doc_ranges,
                            metadata.seq_lens.shape[0],  # type: ignore[attr-defined]
                            metadata.seq_lens.device,  # type: ignore[attr-defined]
                        )
                    )
                metadata.mm_prefix_range_tensor = shared_tensor

    def may_reinitialize_input_batch(
        self, kv_cache_config: KVCacheConfig, kernel_block_sizes: list[int]
    ) -> None:
        """
        Re-initialize the input batch if the block sizes are different from
        what it was originally created with. This happens when the final
        block size (determined after model loading) differs from the
        placeholder used during __init__, or when there are multiple
        KV cache groups.

        Args:
            kv_cache_config: The KV cache configuration.
            kernel_block_sizes: The kernel block sizes for each KV cache group.
        """
        block_sizes = []
        max_num_blocks = []
        dcp_sharded = []
        max_model_len = max(self.max_model_len, self.max_encoder_len)
        for kv_cache_group in kv_cache_config.kv_cache_groups:
            if isinstance(kv_cache_group.kv_cache_spec, EncoderOnlyAttentionSpec):
                continue
            block_size = kv_cache_group.kv_cache_spec.block_size
            block_sizes.append(block_size)
            dcp_sharded.append(kv_cache_group.kv_cache_spec.dcp_sharded)
            if isinstance(kv_cache_group.kv_cache_spec, CircularBufferSpec):
                max_num_blocks_per_req = 1
            else:
                max_num_blocks_per_req = cdiv(
                    max_model_len,
                    kv_cache_group.kv_cache_spec.global_block_size(
                        self.dcp_world_size,
                        self.parallel_config.prefill_context_parallel_size,
                    ),
                )
            if isinstance(kv_cache_group.kv_cache_spec, MambaSpec):
                max_num_blocks_per_req = (
                    max_num_blocks_per_req
                    if self.cache_config.enable_prefix_caching
                    else 1
                ) + kv_cache_group.kv_cache_spec.num_speculative_blocks
            max_num_blocks.append(max_num_blocks_per_req)

        if (
            block_sizes != self._init_block_sizes
            or kernel_block_sizes != self._init_kernel_block_sizes
            or dcp_sharded != self._init_dcp_sharded
        ):
            self._init_block_sizes = block_sizes
            self._init_kernel_block_sizes = kernel_block_sizes
            self._init_dcp_sharded = dcp_sharded
            self.input_batch = InputBatch(
                runtime_policy=self.vllm_config.kernel_config.sm70_runtime,
                max_num_reqs=self.max_num_reqs,
                max_model_len=max_model_len,
                max_num_batched_tokens=self.max_num_tokens,
                device=self.device,
                pin_memory=self.pin_memory,
                vocab_size=self.model_config.get_vocab_size(),
                block_sizes=block_sizes,
                kernel_block_sizes=kernel_block_sizes,
                dcp_sharded=dcp_sharded,
                max_num_blocks_per_req=max_num_blocks,
                num_spec_tokens=self.num_spec_tokens,
                logitsprocs=self.input_batch.logitsprocs,
                logitsprocs_need_output_token_ids=self.input_batch.logitsprocs_need_output_token_ids,
                is_pooling_model=self.is_pooling_model,
                reasoning_config=self.vllm_config.reasoning_config,
            )

        assert self._init_block_sizes == block_sizes, (
            f"InputBatch block_sizes {self._init_block_sizes} != "
            f"kv_cache block_sizes {block_sizes}"
        )
        assert self._init_kernel_block_sizes == kernel_block_sizes, (
            f"InputBatch kernel_block_sizes {self._init_kernel_block_sizes} "
            f"!= kv_cache kernel_block_sizes {kernel_block_sizes}"
        )
        assert self._init_dcp_sharded == dcp_sharded

    def _allocate_kv_cache_tensors(
        self, kv_cache_config: KVCacheConfig
    ) -> dict[str, torch.Tensor]:
        """
        Initializes the KV cache buffer with the correct size. The buffer needs
        to be reshaped to the desired shape before being used by the models.

        Args:
            kv_cache_config: The KV cache config
        Returns:
            dict[str, torch.Tensor]: A map between layer names to their
            corresponding memory buffer for KV cache.
        """
        kv_cache_raw_tensors = allocate_host_kv_cache_pool(kv_cache_config, self.device)
        for kv_cache_tensor in kv_cache_config.kv_cache_tensors:
            if kv_cache_tensor.host_backed:
                continue
            tensor = torch.zeros(
                kv_cache_tensor.size, dtype=torch.int8, device=self.device
            )
            for layer_name in kv_cache_tensor.shared_by:
                kv_cache_raw_tensors[layer_name] = tensor

        layer_names = set()
        for group in kv_cache_config.kv_cache_groups:
            for layer_name in group.layer_names:
                if layer_name in self.runner_only_attn_layers:
                    continue
                layer_names.add(layer_name)
        assert layer_names == set(kv_cache_raw_tensors.keys()), (
            "Some layers are not correctly initialized"
        )
        return kv_cache_raw_tensors

    def _attn_group_iterator(self) -> Iterator[AttentionGroup]:
        return itertools.chain.from_iterable(self.attn_groups)

    def _kv_cache_spec_attn_group_iterator(self) -> Iterator[AttentionGroup]:
        if not self.kv_cache_config.kv_cache_groups:
            return
        for attn_groups in self.attn_groups:
            yield from attn_groups

    def _reshape_kv_cache_tensors(
        self,
        kv_cache_raw_tensors: dict[str, torch.Tensor],
        kernel_block_sizes: list[int],
    ) -> dict[str, torch.Tensor]:
        """
        Reshape the KV cache tensors to the desired shape and dtype.

        Args:
            kv_cache_raw_tensors: The KV cache buffer of each layer, with
                correct size but uninitialized shape.
            kernel_block_sizes: The kernel block sizes for each KV cache group.
        Returns:
            Dict[str, torch.Tensor]: A map between layer names to their
            corresponding memory buffer for KV cache.
        """
        kv_caches: dict[str, torch.Tensor] = {}
        has_attn, has_mamba = False, False
        for group in self._kv_cache_spec_attn_group_iterator():
            kv_cache_spec = group.kv_cache_spec
            attn_backend = group.backend
            if group.kv_cache_group_id == len(kernel_block_sizes):
                # There may be a last group for layers without kv cache.
                continue
            kernel_block_size = kernel_block_sizes[group.kv_cache_group_id]
            for layer_name in group.layer_names:
                if layer_name in self.runner_only_attn_layers:
                    continue
                raw_tensor = kv_cache_raw_tensors[layer_name]
                assert raw_tensor.numel() % kv_cache_spec.page_size_bytes == 0
                num_blocks = raw_tensor.numel() // kv_cache_spec.page_size_bytes
                if isinstance(kv_cache_spec, AttentionSpec):
                    has_attn = True
                    # Compressed MLA is split into physical pool pages instead
                    # of the scheduler's attention-kernel blocks.
                    if kv_cache_spec.storage_block_size != kv_cache_spec.block_size:
                        # QSA side caches consume physical block tables; paged
                        # MQA indexers consume smaller virtual pages. Match the
                        # metadata builder and the V2 cache layout in each case.
                        uses_physical_block_table = (
                            attn_backend.get_builder_cls().uses_physical_block_table
                        )
                        shape_block_size = (
                            kv_cache_spec.storage_block_size
                            if uses_physical_block_table
                            else compressed_kernel_block_size(kv_cache_spec)
                        )
                        kernel_num_blocks = num_blocks * (
                            kv_cache_spec.storage_block_size // shape_block_size
                        )
                    else:
                        num_blocks_per_kv_block = (
                            kv_cache_spec.block_size // kernel_block_size
                        )
                        kernel_num_blocks = num_blocks * num_blocks_per_kv_block
                        shape_block_size = kernel_block_size

                    kv_cache_shape = attn_backend.get_kv_cache_shape(
                        kernel_num_blocks,
                        shape_block_size,
                        kv_cache_spec.num_kv_heads,
                        kv_cache_spec.head_size,
                        cache_dtype_str=kv_cache_spec.layout_cache_dtype(
                            self.cache_config.cache_dtype
                        ),
                    )
                    dtype = kv_cache_spec.dtype
                    try:
                        kv_cache_stride_order = attn_backend.get_kv_cache_stride_order()
                        assert len(kv_cache_stride_order) == len(kv_cache_shape)
                    except (AttributeError, NotImplementedError):
                        kv_cache_stride_order = tuple(range(len(kv_cache_shape)))
                    # The allocation respects the backend-defined stride order
                    # to ensure the semantic remains consistent for each
                    # backend. We first obtain the generic kv cache shape and
                    # then permute it according to the stride order which could
                    # result in a non-contiguous tensor.
                    kv_cache_shape = tuple(
                        kv_cache_shape[i] for i in kv_cache_stride_order
                    )
                    # Maintain original KV shape view.
                    inv_order = [
                        kv_cache_stride_order.index(i)
                        for i in range(len(kv_cache_stride_order))
                    ]

                    raw_tensor = kv_cache_raw_tensors[layer_name].view(dtype)
                    if kv_cache_spec.page_size_padded is not None:
                        # Use strided view to handle page_size_bytes that
                        # include padding. This follows
                        # the same pattern as MambaSpec handling below.
                        # NOTE: This assumes kv_cache_shape[0] == num_blocks
                        # (i.e. the first physical dimension is the block
                        # index), which holds for MLA backends but NOT for
                        # standard attention backends whose shape starts with
                        # a K/V dimension of size 2.
                        dtype_size = get_dtype_size(dtype)
                        page_stride = kv_cache_spec.page_size_bytes // dtype_size
                        strides = list(torch.empty(kv_cache_shape).stride())
                        strides[inv_order[0]] = page_stride
                        kv_cache = torch.as_strided(
                            raw_tensor,
                            size=kv_cache_shape,
                            stride=tuple(strides),
                        )
                    else:
                        # No padding — safe to use a contiguous view.
                        kv_cache = raw_tensor.view(kv_cache_shape)
                    kv_caches[layer_name] = kv_cache.permute(*inv_order)

                elif isinstance(kv_cache_spec, MambaSpec):
                    has_mamba = True
                    raw_tensor = kv_cache_raw_tensors[layer_name]
                    state_tensors = []
                    storage_offset_bytes = 0
                    for shape, dtype in zip(kv_cache_spec.shapes, kv_cache_spec.dtypes):
                        dtype_size = get_dtype_size(dtype)
                        num_element_per_page = (
                            kv_cache_spec.page_size_bytes // dtype_size
                        )
                        target_shape = (num_blocks, *shape)
                        stride = torch.empty(target_shape).stride()
                        target_stride = (num_element_per_page, *stride[1:])
                        assert storage_offset_bytes % dtype_size == 0
                        tensor = torch.as_strided(
                            raw_tensor.view(dtype),
                            size=target_shape,
                            stride=target_stride,
                            storage_offset=storage_offset_bytes // dtype_size,
                        )
                        state_tensors.append(tensor)
                        storage_offset_bytes += stride[0] * dtype_size

                    kv_caches[layer_name] = state_tensors
                else:
                    raise NotImplementedError

        if has_attn and has_mamba:
            self._update_hybrid_attention_mamba_layout(kv_caches, kernel_block_sizes)

        return kv_caches

    def _update_hybrid_attention_mamba_layout(
        self, kv_caches: dict[str, torch.Tensor], kernel_block_sizes: list[int]
    ) -> None:
        """
        Update the layout of attention layers from (2, num_blocks, ...) to
        (num_blocks, 2, ...).

        Args:
            kv_caches: The KV cache buffer of each layer.
            kernel_block_sizes: The kernel block sizes for each KV cache group.
        """

        for group in self._kv_cache_spec_attn_group_iterator():
            kv_cache_spec = group.kv_cache_spec
            if not isinstance(kv_cache_spec, AttentionSpec):
                continue
            block_dim = group.backend.get_kv_cache_block_dim(
                kernel_block_sizes[group.kv_cache_group_id],
                kv_cache_spec.num_kv_heads,
                kv_cache_spec.head_size,
                cache_dtype_str=kv_cache_spec.layout_cache_dtype(
                    self.cache_config.cache_dtype
                ),
            )
            # block_dim: 0 means (num_blocks, 2, ...); 1 means (2, num_blocks, ...).
            if block_dim == 0:
                continue
            assert block_dim == 1
            for layer_name in group.layer_names:
                kv_cache = kv_caches[layer_name]
                hidden_size = kv_cache.shape[2:].numel()
                kv_cache.as_strided_(
                    size=kv_cache.shape,
                    stride=(hidden_size, 2 * hidden_size, *kv_cache.stride()[2:]),
                )

    def initialize_kv_cache_tensors(
        self, kv_cache_config: KVCacheConfig, kernel_block_sizes: list[int]
    ) -> dict[str, torch.Tensor]:
        """
        Initialize the memory buffer for KV cache.

        Args:
            kv_cache_config: The KV cache config
            kernel_block_sizes: The kernel block sizes for each KV cache group.

        Returns:
            Dict[str, torch.Tensor]: A map between layer names to their
            corresponding memory buffer for KV cache.
        """
        if any(t.packed_members for t in kv_cache_config.kv_cache_tensors):
            raise NotImplementedError(
                "Packed attention pages are laid out only by the v2 GPU model runner"
            )

        # Try creating KV caches optimized for kv-connector transfers
        cache_dtype = self.cache_config.cache_dtype
        if self.use_uniform_kv_cache(self.attn_groups, cache_dtype):
            kv_caches, cross_layers_kv_cache, attn_backend = (
                self.allocate_uniform_kv_caches(
                    kv_cache_config,
                    self.attn_groups,
                    cache_dtype,
                    self.device,
                    kernel_block_sizes,
                )
            )
            self.cross_layers_kv_cache = cross_layers_kv_cache
            self.cross_layers_attn_backend = attn_backend
        else:
            # Fallback to the general case
            # Initialize the memory buffer for KV cache
            kv_cache_raw_tensors = self._allocate_kv_cache_tensors(kv_cache_config)

            # Change the memory buffer to the desired shape
            kv_caches = self._reshape_kv_cache_tensors(
                kv_cache_raw_tensors, kernel_block_sizes
            )

        # Set up cross-layer KV cache sharing
        for layer_name, target_layer_name in self.shared_kv_cache_layers.items():
            logger.debug("%s reuses KV cache of %s", layer_name, target_layer_name)
            kv_caches[layer_name] = kv_caches[target_layer_name]

        num_attn_module = (
            2 if self.model_config.hf_config.model_type == "longcat_flash" else 1
        )
        bind_kv_cache(
            kv_caches,
            self.compilation_config.static_forward_context,
            self.kv_caches,
            num_attn_module,
        )
        return kv_caches

    def maybe_add_kv_sharing_layers_to_kv_cache_groups(
        self, kv_cache_config: KVCacheConfig
    ) -> None:
        """
        Add layers that re-use KV cache to KV cache group of its target layer.
        Mapping of KV cache tensors happens in `initialize_kv_cache_tensors()`
        """
        if not self.shared_kv_cache_layers:
            # No cross-layer KV sharing, return
            return

        add_kv_sharing_layers_to_kv_cache_groups(
            self.shared_kv_cache_layers,
            kv_cache_config.kv_cache_groups,
            self.runner_only_attn_layers,
        )

        if self.cache_config.kv_sharing_fast_prefill:
            # In You Only Cache Once (https://arxiv.org/abs/2405.05254) or other
            # similar KV sharing setups, only the layers that generate KV caches
            # are involved in the prefill phase, enabling prefill to early exit.
            attn_layers = get_layers_from_vllm_config(self.vllm_config, Attention)
            for layer_name in reversed(attn_layers):
                if layer_name in self.shared_kv_cache_layers:
                    self.kv_sharing_fast_prefill_eligible_layers.add(layer_name)
                else:
                    break

    def initialize_kv_cache(
        self,
        kv_cache_config: KVCacheConfig,
        is_profiling: bool = False,
    ) -> None:
        """
        Initialize KV cache based on `kv_cache_config`.
        Args:
            kv_cache_config: Configuration for the KV cache, including the KV
            cache size of each layer
        """
        kv_cache_config = deepcopy(kv_cache_config)
        self.kv_cache_config = kv_cache_config
        self._mamba_bufs = None
        self.may_add_encoder_only_layers_to_kv_cache_config()
        self.maybe_add_kv_sharing_layers_to_kv_cache_groups(kv_cache_config)
        self.initialize_attn_backend(kv_cache_config, is_profiling=is_profiling)
        initialize_mamba_ssu_backend(
            self.vllm_config.mamba_config, self.kv_cache_config
        )
        # The kernel block size for all KV cache groups. For example, if
        # kv_cache_manager uses block_size 256 for a given group, but the attention
        # backends for that group only supports block_size 64, we will return
        # kernel_block_size 64 and split the 256-token-block to 4 blocks with 64
        # tokens each.
        kernel_block_sizes = prepare_kernel_block_sizes(
            kv_cache_config, self.attn_groups
        )
        self._kernel_block_sizes = kernel_block_sizes

        # create metadata builders
        self.initialize_metadata_builders(kv_cache_config, kernel_block_sizes)

        # Reinitialize need to after initialize_attn_backend
        self.may_reinitialize_input_batch(kv_cache_config, kernel_block_sizes)
        kv_caches = self.initialize_kv_cache_tensors(
            kv_cache_config, kernel_block_sizes
        )

        if (
            self.speculative_config
            and self.speculative_config.uses_extract_hidden_states()
            and get_pp_group().is_last_rank
        ):
            assert isinstance(self.drafter, ExtractHiddenStatesProposer)
            # validate all draft model layers belong to the same kv cache
            # group
            self.drafter.validate_same_kv_cache_group(kv_cache_config)

        if has_kv_transfer_group() and not is_profiling:
            kv_transfer_group = get_kv_transfer_group()
            if self.cross_layers_kv_cache is not None:
                assert self.cross_layers_attn_backend is not None
                kv_transfer_group.register_cross_layers_kv_cache(
                    self.cross_layers_kv_cache, self.cross_layers_attn_backend
                )
            else:
                kv_transfer_group.register_kv_caches(kv_caches)
            kv_transfer_group.set_host_xfer_buffer_ops(copy_kv_blocks)

    def _get_attention_kv_cache_gid(self) -> int:
        """Find the KV cache group index for attention layers.

        Must match :attr:`RoutedExpertsManager.attn_gid` in the scheduler:
        both pick the first ``FullAttentionSpec`` group so hybrid models
        (Mamba / linear-attention layers that use other AttentionSpec
        subclasses) end up indexing the same slot layout on both sides.
        Falls back to 0 only for legacy single-group configs.
        """
        for gid, group in enumerate(self.kv_cache_config.kv_cache_groups):
            if isinstance(group.kv_cache_spec, FullAttentionSpec):
                return gid
        return 0

    def init_routed_experts_capturer(self):
        logger.info(
            "Initializing routed experts capturer, enable_return_routed_experts: %s",
            self.model_config.enable_return_routed_experts,
        )
        self.routed_experts_capturer = RoutedExpertsCapturer(
            max_num_batched_tokens=self.scheduler_config.max_num_batched_tokens,
            vllm_config=self.vllm_config,
        )
        self.routed_experts_attn_gid = self._get_attention_kv_cache_gid()
        self._bind_routed_experts_capturer(self.routed_experts_capturer)

        # Pinned CPU buffer for non-blocking D2H of ``routing_data`` on
        # the sync scheduling path. Shape / dtype mirror the device
        # capturer exactly so ``copy_`` is a straight memcpy.
        self.routed_experts_cpu = torch.empty(
            self.routed_experts_capturer.device_buffer.shape,
            dtype=self.routed_experts_capturer.device_buffer.dtype,
            device="cpu",
            pin_memory=self.pin_memory,
        )
        # ``slot_mapping`` dtype is fixed to int64 by
        # ``block_table.slot_mapping``; we mirror that here.
        max_tokens = self.scheduler_config.max_num_batched_tokens
        self.routed_experts_slot_mapping_cpu = torch.empty(
            (max_tokens,),
            dtype=torch.int64,
            device="cpu",
            pin_memory=self.pin_memory,
        )
        # Private device buffer so the shared ``block_table.slot_mapping``
        # can be overwritten by the next ``_prepare_inputs`` while the
        # D2H is still pending on the copy stream. Written in
        # ``_prepare_inputs``, read in ``_bookkeeping_sync`` (sync path)
        # or cloned into a snapshot (async path).
        self.routed_experts_slot_mapping_device = torch.empty(
            (max_tokens,),
            dtype=torch.int64,
            device=self.device,
        )
        self.routed_experts_initialized = True

    def _bind_routed_experts_capturer(self, capturer: RoutedExpertsCapturer) -> None:
        from vllm.model_executor.layers.fused_moe.layer import FusedMoE
        from vllm.model_executor.layers.fused_moe.router.base_router import (
            BaseRouter,
        )

        for module in self.compilation_config.static_forward_context.values():
            if isinstance(module, FusedMoE) and isinstance(module.router, BaseRouter):
                layer_id = module.layer_id

                def _capture_fn(topk_ids, _layer_id=layer_id, _capturer=capturer):
                    _capturer.capture(_layer_id, topk_ids)

                module.router.set_capture_fn(_capture_fn)

    def may_add_encoder_only_layers_to_kv_cache_config(self) -> None:
        """
        Add encoder-only layers to the KV cache config.
        """
        block_size = self.vllm_config.cache_config.block_size
        encoder_only_attn_specs: dict[AttentionSpec, list[str]] = defaultdict(list)
        attn_layers = get_layers_from_vllm_config(self.vllm_config, Attention)
        for layer_name, attn_module in attn_layers.items():
            if attn_module.attn_type == AttentionType.ENCODER_ONLY:
                attn_spec: AttentionSpec = EncoderOnlyAttentionSpec(
                    block_size=block_size,
                    num_kv_heads=attn_module.num_kv_heads,
                    head_size=attn_module.head_size,
                    dtype=self.kv_cache_dtype,
                )
                encoder_only_attn_specs[attn_spec].append(layer_name)
                self.runner_only_attn_layers.add(layer_name)
        if len(encoder_only_attn_specs) > 0:
            assert len(encoder_only_attn_specs) == 1, (
                "Only support one encoder-only attention spec now"
            )
            spec, layer_names = encoder_only_attn_specs.popitem()
            self.kv_cache_config.kv_cache_groups.append(
                KVCacheGroupSpec(layer_names=layer_names, kv_cache_spec=spec)
            )

    def get_kv_cache_spec(self) -> dict[str, KVCacheSpec]:
        """
        Generates the KVCacheSpec by parsing the kv cache format from each
        Attention module in the static forward context.
        Returns:
            KVCacheSpec: A dictionary mapping layer names to their KV cache
            format. Layers that do not need KV cache are not included.
        """
        if has_ec_transfer() and not get_ec_transfer().is_consumer:
            return {}
        kv_cache_spec: dict[str, KVCacheSpec] = {}
        layer_type = cast(type[Any], AttentionLayerBase)
        attn_layers = get_layers_from_vllm_config(self.vllm_config, layer_type)
        for layer_name, attn_module in attn_layers.items():
            if isinstance(attn_module, Attention) and (
                kv_tgt_layer := attn_module.kv_sharing_target_layer_name
            ):
                # The layer doesn't need its own KV cache and will use that of
                # the target layer. We skip creating a KVCacheSpec for it, so
                # that KV cache management logic will act as this layer does
                # not exist, and doesn't allocate KV cache for the layer. This
                # enables the memory saving of cross-layer kv sharing, allowing
                # a given amount of memory to accommodate longer context lengths
                # or enable more requests to be processed simultaneously.
                self.shared_kv_cache_layers[layer_name] = kv_tgt_layer
                continue
            # Skip modules that don't need KV cache (eg encoder-only attention)
            if spec := attn_module.get_kv_cache_spec(self.vllm_config):
                kv_cache_spec[layer_name] = spec

        return kv_cache_spec

    def _to_list(self, sampled_token_ids: torch.Tensor) -> list[list[int]]:
        # This is a short term mitigation for issue mentioned in
        # https://github.com/vllm-project/vllm/issues/22754.
        # `tolist` would trigger a cuda wise stream sync, which
        # would block other copy ops from other cuda streams.
        # A cuda event sync would avoid such a situation. Since
        # this is in the critical path of every single model
        # forward loop, this has caused perf issue for a disagg
        # setup.
        pinned = self.sampled_token_ids_pinned_cpu[: sampled_token_ids.shape[0]]
        pinned.copy_(sampled_token_ids, non_blocking=True)
        self.transfer_event.record()
        self._event_tracer.synchronize(
            self.transfer_event,
            "GPUModelRunner.transfer_event.synchronize",
        )
        return pinned.tolist()

    def get_encoder_timing_stats(self) -> dict[str, dict[str, float | int]]:
        """
        Get encoder timing stats for all requests and clear the registry.

        Returns:
            Dictionary mapping request_id to stats dict.
        """
        with self._encoder_timing_lock:
            stats = {
                req_id: stats_obj.to_dict()
                for req_id, stats_obj in self.encoder_timing_registry.items()
            }
            self.encoder_timing_registry.clear()
            return stats

    @contextmanager
    def timed_encoder_operation(
        self,
        should_time: bool,
        group_lora_refs: list[tuple[str, Any]],
        current_item_idx: int,
        num_items: int,
    ):
        """
        Context manager to time encoder forward operations.

        Args:
            should_time: Whether timing is enabled
            group_lora_refs: Full list of (request_id, pos_info) tuples
            current_item_idx: Starting index for this group
            num_items: Number of items in this group
        """
        if not should_time:
            yield
            return

        group_refs = group_lora_refs[current_item_idx : current_item_idx + num_items]
        group_request_ids = {req_id for req_id, _ in group_refs}

        torch.accelerator.synchronize()
        start_time = time.perf_counter()

        try:
            yield
        finally:
            torch.accelerator.synchronize()
            elapsed = time.perf_counter() - start_time

            per_request_time = elapsed / max(len(group_request_ids), 1)

            with self._encoder_timing_lock:
                for req_id in group_request_ids:
                    if req_id not in self.encoder_timing_registry:
                        self.encoder_timing_registry[req_id] = EncoderTimingStats()

                    stats = self.encoder_timing_registry[req_id]
                    stats.encoder_forward_secs += per_request_time
                    stats.num_encoder_calls += 1


@dataclass
class EncoderTimingStats:
    """Per-request timing statistics for encoder forward pass."""

    encoder_forward_secs: float = 0.0
    """Time spent in vision encoder forward pass (seconds)."""

    num_encoder_calls: int = 0
    """Number of times encoder was called for this request."""

    def to_dict(self) -> dict[str, float | int]:
        return {
            "encoder_forward_secs": self.encoder_forward_secs,
            "num_encoder_calls": self.num_encoder_calls,
        }
